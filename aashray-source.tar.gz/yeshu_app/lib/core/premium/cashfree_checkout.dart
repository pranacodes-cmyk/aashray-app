import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpayment/cfupi.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpayment/cfupipayment.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpaymentgateway/cfpaymentgatewayservice.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfsession/cfsession.dart';
import 'package:flutter_cashfree_pg_sdk/utils/cfenums.dart';
import 'plans.dart';

sealed class CheckoutResult {
  const CheckoutResult();
}

class CheckoutVerified extends CheckoutResult {
  const CheckoutVerified(this.paymentId);
  final String paymentId;
}

class CheckoutFailed extends CheckoutResult {
  const CheckoutFailed(this.message);
  final String message;
}

class CheckoutNotConfigured extends CheckoutResult {
  const CheckoutNotConfigured();
}

/// The SDK never grants access. The app's own backend must create an order
/// and independently verify a PAID order before producing CheckoutVerified.
class CashfreeOrder {
  const CashfreeOrder({
    required this.orderId,
    required this.sessionId,
    required this.live,
  });
  final String orderId;
  final String sessionId;
  final bool live;
}

abstract interface class CashfreeOrderBackend {
  Future<CashfreeOrder> createOrder(Plan plan);
  Future<CheckoutResult> verifyOrder(String orderId, Plan plan);
}

class CashfreeCheckout {
  CashfreeCheckout._();
  static final instance = CashfreeCheckout._();
  CashfreeOrderBackend? backend;
  Completer<CheckoutResult>? _pending;
  Future<CheckoutResult> pay(Plan plan) async {
    final api = backend;
    if (api == null || kIsWeb) return const CheckoutNotConfigured();
    final pending = _pending;
    if (pending != null) return pending.future;
    final completer = Completer<CheckoutResult>();
    _pending = completer;
    void finish(CheckoutResult result) {
      if (!completer.isCompleted) completer.complete(result);
    }

    try {
      final order = await api.createOrder(plan);
      final gateway = CFPaymentGatewayService();
      gateway.setCallback(
        (id) async {
          if (id != order.orderId) {
            finish(const CheckoutFailed('Payment could not be verified.'));
            return;
          }
          try {
            finish(await api.verifyOrder(id, plan));
          } catch (_) {
            finish(
              const CheckoutFailed(
                'Verification is pending. Please check again before paying twice.',
              ),
            );
          }
        },
        (error, _) {
          finish(
            const CheckoutFailed(
              'Payment was not completed. You can try again.',
            ),
          );
        },
      );
      final session =
          CFSessionBuilder()
              .setEnvironment(
                order.live ? CFEnvironment.PRODUCTION : CFEnvironment.SANDBOX,
              )
              .setOrderId(order.orderId)
              .setPaymentSessionId(order.sessionId)
              .build();
      // UPI-specific Element API: native installed-app selection, not a WebView checkout.
      final upi =
          CFUPIBuilder().setChannel(CFUPIChannel.INTENT_WITH_UI).build();
      gateway.doPayment(
        CFUPIPaymentBuilder().setSession(session).setUPI(upi).build(),
      );
      return await completer.future.timeout(
        const Duration(minutes: 10),
        onTimeout:
            () => const CheckoutFailed(
              'Payment confirmation is pending. Please do not pay again yet.',
            ),
      );
    } catch (_) {
      return const CheckoutFailed('Could not open UPI. Please try again.');
    } finally {
      _pending = null;
    }
  }
}
