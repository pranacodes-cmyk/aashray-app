import 'package:flutter/foundation.dart';

import '../native/wallpaper_bridge.dart';
import '../prefs.dart';
import 'plans.dart';

/// Device-local Premium entitlement. Razorpay success extends it; the app
/// gate listens to it. (Server-side verification arrives with the UPI flow.)
class PremiumStore extends ChangeNotifier {
  PremiumStore._();

  static final instance = PremiumStore._();

  static const _kExpiry = 'premium_expires_ms';
  static const _kPlan = 'premium_plan';
  static const _kPayment = 'premium_payment_id';

  DateTime? _expiry;
  String? _planId;
  String? _paymentId;

  DateTime? get expiry => _expiry;
  Plan? get plan => planById(_planId);
  String? get paymentId => _paymentId;
  bool get isActive => isEntitled(_expiry, DateTime.now());
  int get daysRemaining => daysLeft(_expiry, DateTime.now());

  void load() {
    final ms = Prefs.getInt(_kExpiry);
    _expiry = ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
    _planId = Prefs.getString(_kPlan);
    _paymentId = Prefs.getString(_kPayment);
    WallpaperBridge.dailyVerseSetPremium(isActive);
  }

  Future<void> grant(Plan plan, {required String paymentId}) async {
    final now = DateTime.now();
    _expiry = extendExpiry(currentExpiry: _expiry, plan: plan, now: now);
    _planId = plan.id;
    _paymentId = paymentId;
    await Prefs.setInt(_kExpiry, _expiry!.millisecondsSinceEpoch);
    await Prefs.setString(_kPlan, plan.id);
    await Prefs.setString(_kPayment, paymentId);
    WallpaperBridge.dailyVerseSetPremium(true);
    notifyListeners();
  }

  /// Server-verified Cashfree access. A null [until] clears only previous
  /// server access (lapsed/cancelled); the internal test unlock is untouched.
  Future<void> applyServer(DateTime? until, String? subscriptionId) async {
    if (until == null) {
      if (_planId != 'server') return;
      _expiry = null;
      await Prefs.setInt(_kExpiry, 0);
    } else {
      _expiry = until;
      _planId = 'server';
      _paymentId = subscriptionId;
      await Prefs.setInt(_kExpiry, until.millisecondsSinceEpoch);
      await Prefs.setString(_kPlan, 'server');
      if (subscriptionId != null) await Prefs.setString(_kPayment, subscriptionId);
    }
    WallpaperBridge.dailyVerseSetPremium(isActive);
    notifyListeners();
  }

  /// Internal test builds only (see AppConfig.allowTestUnlock).
  Future<void> grantTestDay() async {
    _expiry = DateTime.now().add(const Duration(days: 1));
    _planId = 'test';
    _paymentId = 'test_unlock';
    await Prefs.setInt(_kExpiry, _expiry!.millisecondsSinceEpoch);
    await Prefs.setString(_kPlan, 'test');
    await Prefs.setString(_kPayment, 'test_unlock');
    WallpaperBridge.dailyVerseSetPremium(true);
    notifyListeners();
  }

  /// Re-evaluates expiry (called on app resume) so a lapsed plan locks again.
  void refresh() {
    final active = isActive;
    WallpaperBridge.dailyVerseSetPremium(active);
    notifyListeners();
  }
}
