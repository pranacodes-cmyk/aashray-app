/// Pure Premium plan + entitlement rules (no Flutter, no I/O) so prices,
/// savings and expiry maths are covered by `test/plans_test.dart`.
library;

class Plan {
  const Plan({
    required this.id,
    required this.title,
    required this.priceInr,
    required this.periodDays,
    required this.periodLabel,
  });

  final String id;
  final String title;

  /// Whole rupees.
  final int priceInr;
  final int periodDays;

  /// "month" / "year".
  final String periodLabel;

  /// Razorpay amounts are in paise.
  int get amountPaise => priceInr * 100;

  /// Effective monthly price, rounded to the nearest rupee
  /// (yearly ₹999 → ₹83).
  int get perMonthInr =>
      periodDays >= 365
          ? (priceInr / 12).round()
          : (priceInr * 30 / periodDays).round();
}

const kMonthlyPlan = Plan(
  id: 'monthly',
  title: 'Monthly',
  priceInr: 199,
  periodDays: 30,
  periodLabel: 'month',
);

const kYearlyPlan = Plan(
  id: 'yearly',
  title: 'Yearly',
  priceInr: 999,
  periodDays: 365,
  periodLabel: 'year',
);

const kPlans = <Plan>[kYearlyPlan, kMonthlyPlan];

Plan? planById(String? id) {
  for (final p in kPlans) {
    if (p.id == id) return p;
  }
  return null;
}

/// How much cheaper [yearly] is than paying [monthly] for twelve months,
/// as a whole percentage (₹999 vs 12 × ₹199 → 58).
int yearlySavingsPercent(Plan monthly, Plan yearly) {
  final fullYear = monthly.priceInr * 12;
  if (fullYear <= 0) return 0;
  return ((1 - yearly.priceInr / fullYear) * 100).floor();
}

/// New expiry after paying for [plan] at [now]. Time left on an active plan
/// is never lost: the new period starts when the current one ends.
DateTime extendExpiry({
  required DateTime? currentExpiry,
  required Plan plan,
  required DateTime now,
}) {
  final start =
      (currentExpiry != null && currentExpiry.isAfter(now))
          ? currentExpiry
          : now;
  return start.add(Duration(days: plan.periodDays));
}

/// Premium is active strictly before the expiry instant.
bool isEntitled(DateTime? expiry, DateTime now) =>
    expiry != null && now.isBefore(expiry);

/// Whole days left (rounded up), 0 when expired.
int daysLeft(DateTime? expiry, DateTime now) {
  if (!isEntitled(expiry, now)) return 0;
  final ms = expiry!.difference(now).inMilliseconds;
  return (ms / Duration.millisecondsPerDay).ceil();
}
