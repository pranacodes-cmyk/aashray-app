import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpayment/cfsubscriptioncheckoutpayment.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpaymentgateway/cfpaymentgatewayservice.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfsession/cfsubssession.dart';
import 'package:flutter_cashfree_pg_sdk/utils/cfenums.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../meta/meta_events.dart';
import '../prefs.dart';
import 'premium_store.dart';
import 'subscription_rules.dart';

sealed class SubResult {
  const SubResult();
}

class SubActive extends SubResult {
  const SubActive();
}

class SubFailed extends SubResult {
  const SubFailed(this.message);
  final String message;
}

/// ₹2 trial → ₹399/month Cashfree UPI AutoPay. The app only opens checkout;
/// Premium is granted solely from the server's Cashfree-verified status.
class SubscriptionService {
  SubscriptionService._();
  static final instance = SubscriptionService._();

  static const _fnUrl = 'https://wwwoyfvnzapsramqvxyg.supabase.co/functions/v1/aashray-subscribe';
  static const _anonKey = 'sb_publishable_HgjCCmmOAahGSgOspW0Sag_Sw8Gta8f';
  static const _kDevice = 'aashray_device_id';
  static const _kSub = 'aashray_subscription_id';

  bool _busy = false;

  String get deviceId {
    var id = Prefs.getString(_kDevice);
    if (id == null || !isValidDeviceId(id)) {
      final r = Random.secure();
      id = 'd_${List.generate(24, (_) => r.nextInt(36).toRadixString(36)).join()}';
      Prefs.setString(_kDevice, id);
    }
    return id;
  }

  Future<Map<String, dynamic>> _post(Map<String, dynamic> body) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final req = await client.postUrl(Uri.parse(_fnUrl));
      req.headers
        ..contentType = ContentType.json
        ..set('apikey', _anonKey)
        ..set('authorization', 'Bearer $_anonKey');
      req.add(utf8.encode(jsonEncode(body)));
      final res = await req.close().timeout(const Duration(seconds: 20));
      final text = await res.transform(utf8.decoder).join();
      final json = (jsonDecode(text) as Map).cast<String, dynamic>();
      if (res.statusCode >= 400) throw HttpException(json['error']?.toString() ?? 'HTTP ${res.statusCode}');
      return json;
    } finally {
      client.close(force: true);
    }
  }

  /// Asks the server; grants/clears server-backed Premium. Never touches
  /// the internal test unlock. Returns true when premium.
  Future<bool> syncStatus({String? subscriptionId}) async {
    if (kIsWeb) return false;
    try {
      final reply = await _post({'action': 'status', 'deviceId': deviceId, 'subscriptionId': subscriptionId ?? Prefs.getString(_kSub)});
      final until = serverAccessUntil(reply, DateTime.now());
      await PremiumStore.instance.applyServer(until, reply['subscriptionId']?.toString());
      return until != null;
    } catch (_) {
      return false; // offline: keep the last verified local state.
    }
  }

  Future<SubResult> startTrial() async {
    if (kIsWeb) return const SubFailed('Payments work in the Android app.');
    if (_busy) return const SubFailed('Checkout is already open.');
    _busy = true;
    try {
      MetaEvents.checkoutStarted();
      final info = await PackageInfo.fromPlatform();
      final created = await _post({
        'action': 'create',
        'deviceId': deviceId,
        'eventId': 'checkout_${DateTime.now().millisecondsSinceEpoch}',
        'advertiserId': await MetaEvents.advertiserId(),
        'anonId': await MetaEvents.anonymousId(),
        'appVersion': info.version,
        'osVersion': Platform.operatingSystemVersion,
        'deviceModel': 'Android',
      });
      final subId = created['subscriptionId'] as String;
      final sessionId = created['sessionId'] as String?;
      if (sessionId == null || sessionId.isEmpty) return const SubFailed('Could not open UPI AutoPay. Please try again.');
      await Prefs.setString(_kSub, subId);

      final done = Completer<void>();
      final gateway = CFPaymentGatewayService();
      gateway.setCallback((_) { if (!done.isCompleted) done.complete(); }, (_, _) { if (!done.isCompleted) done.complete(); });
      final session = CFSubscriptionSessionBuilder()
          .setEnvironment(created['live'] == false ? CFEnvironment.SANDBOX : CFEnvironment.PRODUCTION)
          .setSubscriptionId(subId)
          .setSubscriptionSessionId(sessionId)
          .build();
      MetaEvents.upiOpened();
      gateway.doPayment(CFSubscriptionPaymentBuilder().setSession(session).build());
      await done.future.timeout(const Duration(minutes: 10), onTimeout: () {});

      // SDK callbacks never grant access: poll the server (webhook / Cashfree).
      for (var i = 0; i < 10; i++) {
        if (await syncStatus(subscriptionId: subId)) return const SubActive();
        await Future<void>.delayed(const Duration(seconds: 3));
      }
      MetaEvents.checkoutFailed('not_verified');
      return const SubFailed('Payment not confirmed yet. If money was debited, reopen the app in a minute — do not pay again.');
    } on HttpException catch (e) {
      MetaEvents.checkoutFailed('create_failed');
      return SubFailed(e.message);
    } catch (_) {
      MetaEvents.checkoutFailed('error');
      return const SubFailed('Could not open UPI AutoPay. Please try again.');
    } finally {
      _busy = false;
    }
  }
}
