import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpayment/cfsubscriptioncheckoutpayment.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpayment/subs/cfsubsupi.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpayment/subs/cfsubsupipayment.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfupi/cfupiutils.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpaymentgateway/cfpaymentgatewayservice.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfsession/cfsubssession.dart';
import 'package:flutter_cashfree_pg_sdk/utils/cfenums.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../meta/meta_events.dart';
import '../prefs.dart';
import 'premium_store.dart';
import 'subscription_rules.dart';

sealed class SubResult {
  const SubResult();
}

class SubActive extends SubResult {
  const SubActive();
}

class SubFailed extends SubResult {
  const SubFailed(this.message);
  final String message;
}

/// ₹2 trial → ₹399/month Cashfree UPI AutoPay. The app only opens checkout;
/// Premium is granted solely from the server's Cashfree-verified status.
class UpiApp {
  const UpiApp(this.name, this.package, this.icon);
  final String name;
  final String package;
  final Uint8List? icon;
}

/// Turns server/Cashfree errors into calm, honest copy for the paywall.
String friendlyPaymentError(String raw) {
  final r = raw.toLowerCase();
  if (r.contains('profile is inactive') || r.contains('not activated') || r.contains('inactive')) {
    return 'UPI AutoPay is being activated for Aashray. Please try again a little later.';
  }
  if (r.contains('too many')) return raw;
  return 'Could not start UPI AutoPay. Please try again.';
}

class SubscriptionService {
  SubscriptionService._();
  static final instance = SubscriptionService._();

  static const _fnUrl = 'https://wwwoyfvnzapsramqvxyg.supabase.co/functions/v1/aashray-subscribe';
  static const _anonKey = 'sb_publishable_HgjCCmmOAahGSgOspW0Sag_Sw8Gta8f';
  static const _kDevice = 'aashray_device_id';
  static const _kSub = 'aashray_subscription_id';

  bool _busy = false;
  static const _kUpi = 'aashray_upi_pkg';

  String? get savedUpiPackage => Prefs.getString(_kUpi);
  Future<void> saveUpiPackage(String pkg) => Prefs.setString(_kUpi, pkg);

  /// Installed UPI apps (name, package, icon) via the Cashfree SDK.
  Future<List<UpiApp>> upiApps() async {
    if (kIsWeb) return const [];
    try {
      final raw = await CFUPIUtils().getUPIApps().timeout(const Duration(seconds: 4)) ?? const [];
      final out = <UpiApp>[];
      for (final item in raw) {
        if (item is! Map) continue;
        final pkg = (item['id'] ?? item['package'] ?? item['packageName'])?.toString();
        if (pkg == null || pkg.isEmpty) continue;
        final name = (item['displayName'] ?? item['name'] ?? pkg).toString();
        Uint8List? icon;
        final ic = item['icon']?.toString();
        if (ic != null && ic.isNotEmpty) {
          try { icon = base64Decode(ic.contains(',') ? ic.split(',').last : ic); } catch (_) {}
        }
        out.add(UpiApp(name, pkg, icon));
      }
      return out;
    } catch (_) {
      return const [];
    }
  }

  String get deviceId {
    var id = Prefs.getString(_kDevice);
    if (id == null || !isValidDeviceId(id)) {
      final r = Random.secure();
      id = 'd_${List.generate(24, (_) => r.nextInt(36).toRadixString(36)).join()}';
      Prefs.setString(_kDevice, id);
    }
    return id;
  }

  Future<Map<String, dynamic>> _post(Map<String, dynamic> body) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final req = await client.postUrl(Uri.parse(_fnUrl));
      req.headers
        ..contentType = ContentType.json
        ..set('apikey', _anonKey)
        ..set('authorization', 'Bearer $_anonKey');
      req.add(utf8.encode(jsonEncode(body)));
      final res = await req.close().timeout(const Duration(seconds: 20));
      final text = await res.transform(utf8.decoder).join();
      final json = (jsonDecode(text) as Map).cast<String, dynamic>();
      if (res.statusCode >= 400) throw HttpException(json['error']?.toString() ?? 'HTTP ${res.statusCode}');
      return json;
    } finally {
      client.close(force: true);
    }
  }

  /// Asks the server; grants/clears server-backed Premium. Never touches
  /// the internal test unlock. Returns true when premium.
  Future<bool> syncStatus({String? subscriptionId}) async {
    if (kIsWeb) return false;
    try {
      final reply = await _post({'action': 'status', 'deviceId': deviceId, 'subscriptionId': subscriptionId ?? Prefs.getString(_kSub)});
      final until = serverAccessUntil(reply, DateTime.now());
      await PremiumStore.instance.applyServer(until, reply['subscriptionId']?.toString());
      return until != null;
    } catch (_) {
      return false; // offline: keep the last verified local state.
    }
  }

  Future<SubResult> startTrial({String? upiPackage}) async {
    if (kIsWeb) return const SubFailed('Payments work in the Android app.');
    if (_busy) return const SubFailed('Checkout is already open.');
    _busy = true;
    try {
      MetaEvents.checkoutStarted();
      final info = await PackageInfo.fromPlatform();
      final created = await _post({
        'action': 'create',
        'deviceId': deviceId,
        'eventId': 'checkout_${DateTime.now().millisecondsSinceEpoch}',
        'advertiserId': await MetaEvents.advertiserId(),
        'anonId': await MetaEvents.anonymousId(),
        'appVersion': info.version,
        'osVersion': Platform.operatingSystemVersion,
        'deviceModel': 'Android',
      });
      final subId = created['subscriptionId'] as String;
      final sessionId = created['sessionId'] as String?;
      if (sessionId == null || sessionId.isEmpty) return const SubFailed('Could not open UPI AutoPay. Please try again.');
      await Prefs.setString(_kSub, subId);

      final done = Completer<void>();
      final gateway = CFPaymentGatewayService();
      gateway.setCallback((_) { if (!done.isCompleted) done.complete(); }, (_, _) { if (!done.isCompleted) done.complete(); });
      final session = CFSubscriptionSessionBuilder()
          .setEnvironment(created['live'] == false ? CFEnvironment.SANDBOX : CFEnvironment.PRODUCTION)
          .setSubscriptionId(subId)
          .setSubscriptionSessionId(sessionId)
          .build();
      MetaEvents.upiOpened();
      if (upiPackage != null && upiPackage.isNotEmpty) {
        // Direct UPI intent into the chosen app (PhonePe, GPay, Paytm …).
        final upi = CFSubsUPIBuilder().setChannel(CFSubsUPIChannel.INTENT).setUPIID(upiPackage).build();
        gateway.doPayment(CFSubsUPIPaymentBuilder().setSession(session).setUPI(upi).build());
      } else {
        gateway.doPayment(CFSubscriptionPaymentBuilder().setSession(session).build());
      }
      await done.future.timeout(const Duration(minutes: 10), onTimeout: () {});

      // SDK callbacks never grant access: poll the server (webhook / Cashfree).
      for (var i = 0; i < 10; i++) {
        if (await syncStatus(subscriptionId: subId)) return const SubActive();
        await Future<void>.delayed(const Duration(seconds: 3));
      }
      MetaEvents.checkoutFailed('not_verified');
      return const SubFailed('Payment not confirmed yet. If money was debited, reopen the app in a minute — do not pay again.');
    } on HttpException catch (e) {
      MetaEvents.checkoutFailed('create_failed');
      return SubFailed(friendlyPaymentError(e.message));
    } catch (_) {
      MetaEvents.checkoutFailed('error');
      return const SubFailed('Could not open UPI AutoPay. Please try again.');
    } finally {
      _busy = false;
    }
  }
}
