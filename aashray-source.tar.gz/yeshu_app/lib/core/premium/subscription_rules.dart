/// Pure rules for server-verified Premium (no I/O) — covered by tests.
library;

const kTrialAmountInr = 2;
const kTrialDays = 1;
const kMonthlyInr = 399;

/// Access granted by the server's status reply, or null when not premium.
/// Only an explicit `premium: true` with a future accessUntil counts.
DateTime? serverAccessUntil(Map<String, dynamic> reply, DateTime now) {
  if (reply['premium'] != true) return null;
  final raw = reply['accessUntil'];
  if (raw is! String) return null;
  final until = DateTime.tryParse(raw);
  if (until == null || !until.isAfter(now)) return null;
  return until;
}

/// Device ids accepted by the server.
bool isValidDeviceId(String v) => RegExp(r'^[A-Za-z0-9_-]{8,80}$').hasMatch(v);
