import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import '../audio_download_stub.dart'
    if (dart.library.js_interop) '../audio_download_web.dart';

enum RingtoneTarget { ringtone, notification, alarm }

enum RingtoneOutcome { ok, needsPermission, storageDenied, savedNotSet, error }

/// Android ringtone setter, gallery saves and direct WhatsApp sharing.
class MediaBridge {
  const MediaBridge._();

  static const _channel = MethodChannel('com.aashray.faith/media');

  static Future<RingtoneOutcome> saveRingtone({
    required String asset,
    required String title,
  }) async {
    try {
      if (kIsWeb) {
        final data = await rootBundle.load(asset);
        downloadAudio(
          data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
          'Aashray - $title.mp3',
        );
        return RingtoneOutcome.ok;
      }
      final result = await _channel.invokeMethod<String>('saveRingtone', {
        'asset': asset,
        'title': title,
      });
      return result == 'ok'
          ? RingtoneOutcome.ok
          : result == 'storage_denied'
          ? RingtoneOutcome.storageDenied
          : RingtoneOutcome.error;
    } catch (_) {
      return RingtoneOutcome.error;
    }
  }

  static Future<bool> canWriteSettings() async {
    try {
      return await _channel.invokeMethod<bool>('canWriteSettings') ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openWriteSettings() async {
    try {
      return await _channel.invokeMethod<bool>('openWriteSettings') ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<RingtoneOutcome> setRingtone({
    required String asset,
    required String title,
    required RingtoneTarget target,
  }) async {
    try {
      final r = await _channel.invokeMethod<String>('setRingtone', {
        'asset': asset,
        'title': title,
        'type': target.name,
      });
      return switch (r) {
        'ok' => RingtoneOutcome.ok,
        'needs_permission' => RingtoneOutcome.needsPermission,
        'storage_denied' => RingtoneOutcome.storageDenied,
        'saved_not_set' => RingtoneOutcome.savedNotSet,
        _ => RingtoneOutcome.error,
      };
    } catch (_) {
      return RingtoneOutcome.error;
    }
  }

  /// Copies a local image file into Pictures/Aashray.
  static Future<bool> saveImage(String path, String name) async {
    try {
      return await _channel.invokeMethod<bool>('saveImage', {
            'path': path,
            'name': name,
          }) ??
          false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> hasWhatsApp() async {
    try {
      return await _channel.invokeMethod<bool>('hasWhatsApp') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Opens WhatsApp's share screen with the image. False when WhatsApp is
  /// not installed — callers fall back to the normal share sheet.
  static Future<bool> shareToWhatsApp(String path, {String? text}) async {
    try {
      return await _channel.invokeMethod<bool>('shareToWhatsApp', {
            'path': path,
            'text': text,
          }) ??
          false;
    } catch (_) {
      return false;
    }
  }
}
