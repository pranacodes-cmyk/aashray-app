import 'package:flutter/services.dart';

/// Android wallpaper bridge (static, live video and the daily verse service).
/// Every call fails soft: a missing platform returns false/null.
class WallpaperBridge {
  const WallpaperBridge._();

  static const _channel = MethodChannel('com.aashray.faith/wallpaper');

  /// target: 'home' | 'lock' | 'both'
  static Future<bool> setStatic(
    String imageUrl, {
    String target = 'both',
  }) async {
    try {
      return await _channel.invokeMethod<bool>('setStatic', {
            'url': imageUrl,
            'target': target,
          }) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Downloads the video once and opens Android's live wallpaper preview.
  static Future<bool> setLive(
    String videoUrl,
    String id, {
    int? width,
    int? height,
  }) async {
    try {
      return await _channel.invokeMethod<bool>('setLive', {
            'url': videoUrl,
            'videoId': id,
            if (width != null && width > 0) 'videoWidth': width,
            if (height != null && height > 0) 'videoHeight': height,
          }) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Opens the system picker for the daily verse wallpaper service.
  static Future<bool> openDailyPicker() async {
    try {
      return await _channel.invokeMethod<bool>(
            'setDailyVerse',
            const <String, Object?>{},
          ) ??
          false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> dailyIsActive() async {
    try {
      final r = await _channel.invokeMethod<Object?>('dailyVerseIsActive');
      if (r is bool) return r;
      if (r is Map) return r['active'] == true;
      return false;
    } catch (_) {
      return false;
    }
  }

  /// Caches the daily backgrounds on the phone so the wallpaper changes at
  /// midnight without internet. Returns {success, ready, available}.
  static Future<Map<Object?, Object?>?> dailyPrefetch({
    bool force = false,
  }) async {
    try {
      return await _channel.invokeMethod<Map<Object?, Object?>>(
        'dailyVersePrefetch',
        {'force': force, 'single': false},
      );
    } catch (_) {
      return null;
    }
  }

  static Future<Map<Object?, Object?>?> dailyCacheStatus() async {
    try {
      return await _channel.invokeMethod<Map<Object?, Object?>>(
        'dailyVerseCacheStatus',
      );
    } catch (_) {
      return null;
    }
  }

  static Future<void> dailyVerseSetPremium(bool premium) async {
    try {
      await _channel.invokeMethod('dailyVerseSetPremium', {'premium': premium});
      if (premium) await _channel.invokeMethod('dailyVerseMarkUnlocked');
    } catch (_) {}
  }
}
