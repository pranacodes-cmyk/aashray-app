import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'config.dart';
import 'native/media_bridge.dart';

/// Image capture, saving and sharing used by Status, Daily Wallpaper and
/// the wallpaper viewer.
class ShareHelper {
  const ShareHelper._();

  static String get appLine =>
      'Get ${AppConfig.appName} for Bible, wallpapers & status: ${AppConfig.playStoreUrl}';

  /// Renders the widget under [key] (a RepaintBoundary) to a PNG file whose
  /// long side is about [targetLongSide] pixels.
  static Future<File?> capture(
    GlobalKey key, {
    String name = 'aashray',
    double targetLongSide = 1920,
  }) async {
    try {
      final obj = key.currentContext?.findRenderObject();
      if (obj is! RenderRepaintBoundary) return null;
      final size = obj.size;
      final longSide = size.longestSide <= 0 ? 1 : size.longestSide;
      final image = await obj.toImage(pixelRatio: targetLongSide / longSide);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (bytes == null) return null;
      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/$name-${DateTime.now().millisecondsSinceEpoch}.png',
      );
      await file.writeAsBytes(bytes.buffer.asUint8List(), flush: true);
      return file;
    } catch (_) {
      return null;
    }
  }

  /// Downloads (or reuses the cached copy of) a network image.
  static Future<File?> download(String url) async {
    try {
      return await DefaultCacheManager().getSingleFile(url);
    } catch (_) {
      return null;
    }
  }

  static Future<void> shareFile(File file, {String? text}) async {
    await SharePlus.instance.share(
      ShareParams(files: [XFile(file.path)], text: text),
    );
  }

  static Future<void> shareText(String text) async {
    await SharePlus.instance.share(ShareParams(text: text));
  }

  /// WhatsApp first; the normal share sheet when WhatsApp is missing.
  static Future<void> toWhatsApp(File file, {String? text}) async {
    final ok = await MediaBridge.shareToWhatsApp(file.path, text: text);
    if (!ok) await shareFile(file, text: text);
  }

  static Future<bool> saveToGallery(File file, String name) =>
      MediaBridge.saveImage(file.path, name);
}
