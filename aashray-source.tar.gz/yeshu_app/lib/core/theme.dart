import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Standalone light palette.
class AppColors {
  const AppColors._();

  static const bg = Color(0xFFFAFBFD);
  static const paper = Color(0xFFFFFFFF);
  static const paperDeep = Color(0xFFECF0F5);
  static const line = Color(0xFFE0E5ED);
  static const ink = Color(0xFF0F141F);
  static const inkSoft = Color(0xFF222939);
  static const muted = Color(0xFF525B6F);
  static const primary = Color(0xFF946B13);
  static const onPrimary = Color(0xFFFFFFFF);
  static const primarySoft = Color(0xFFFCF3DC);
  static const accent = Color(0xFF2060DF);
  static const accentSoft = Color(0xFFEAF0FC);
  static const shadow = Color(0x100F141F);
  static const gold = primary;
  static const goldSoft = primarySoft;
  static const green = Color(0xFF247653);
  static const greenSoft = Color(0xFFE9F5ED);
  static const rose = Color(0xFFAC4262);
  static const roseSoft = Color(0xFFFBEFF3);
  static const teal = Color(0xFF267B85);
  static const tealSoft = Color(0xFFE9F5F7);
  static const danger = Color(0xFFD92222);
  static const imageGold = Color(0xFFF4C65D);
  static const imageSoft = Color(0xFFE8E9ED);
  static const imageInk = Color(0xFFFFFFFF);
  static const scrim = Color(0xFF000000);
  // Book reader: warm printed-paper palette.
  static const bookPaper = Color(0xFFFBF5E9);
  static const bookPaperEdge = Color(0xFFEFE4CF);
  static const bookDesk = Color(0xFF3A2C1E);
  static const bookInk = Color(0xFF2B2117);
  static const bookRed = Color(0xFF9A2B22);
}

class AppTheme {
  const AppTheme._();

  static const serif = 'Lora';

  static const overlay = SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    statusBarBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.bg,
    systemNavigationBarIconBrightness: Brightness.dark,
  );

  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.accent,
      brightness: Brightness.light,
    ).copyWith(
      primary: AppColors.primary,
      onPrimary: AppColors.onPrimary,
      secondary: AppColors.accent,
      surface: AppColors.bg,
      onSurface: AppColors.ink,
      outline: AppColors.line,
      error: AppColors.danger,
    );
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.bg,
      fontFamily: 'Manrope',
      splashFactory: InkSparkle.splashFactory,
    );
    return base.copyWith(
      textTheme: base.textTheme.apply(
        bodyColor: AppColors.ink,
        displayColor: AppColors.ink,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.bg,
        foregroundColor: AppColors.ink,
        elevation: 0,
        scrolledUnderElevation: 0.5,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
        systemOverlayStyle: overlay,
        titleTextStyle: TextStyle(
          color: AppColors.ink,
          fontFamily: 'Manrope',
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: 0,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.bg,
        surfaceTintColor: Colors.transparent,
        indicatorColor: AppColors.primarySoft,
        height: 68,
        labelTextStyle: WidgetStateProperty.resolveWith(
          (s) => TextStyle(
            fontSize: 12,
            fontWeight:
                s.contains(WidgetState.selected)
                    ? FontWeight.w700
                    : FontWeight.w500,
            color:
                s.contains(WidgetState.selected)
                    ? AppColors.primary
                    : AppColors.muted,
          ),
        ),
        iconTheme: WidgetStateProperty.resolveWith(
          (s) => IconThemeData(
            color:
                s.contains(WidgetState.selected)
                    ? AppColors.primary
                    : AppColors.muted,
          ),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.accent,
          foregroundColor: AppColors.onPrimary,
          minimumSize: const Size(64, 52),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.ink,
          minimumSize: const Size(64, 50),
          side: const BorderSide(color: AppColors.line, width: 1.2),
          textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
          backgroundColor: AppColors.paperDeep,
          foregroundColor: AppColors.muted,
          selectedBackgroundColor: AppColors.paper,
          selectedForegroundColor: AppColors.ink,
          side: BorderSide.none,
          textStyle: const TextStyle(
            fontFamily: 'Manrope',
            fontSize: 13,
            fontWeight: FontWeight.w700,
          ),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
      chipTheme: base.chipTheme.copyWith(
        backgroundColor: AppColors.paper,
        selectedColor: AppColors.ink,
        side: BorderSide.none,
        labelStyle: const TextStyle(
          fontSize: 13.5,
          fontWeight: FontWeight.w600,
          color: AppColors.inkSoft,
        ),
        secondaryLabelStyle: const TextStyle(
          fontSize: 13.5,
          fontWeight: FontWeight.w700,
          color: AppColors.onPrimary,
        ),
        shape: const StadiumBorder(),
        showCheckmark: false,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.paperDeep,
        contentTextStyle: const TextStyle(
          color: AppColors.ink,
          fontSize: 14.5,
          fontWeight: FontWeight.w500,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.bg,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
      ),
      dialogTheme: const DialogThemeData(
        backgroundColor: AppColors.bg,
        surfaceTintColor: Colors.transparent,
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.line,
        thickness: 1,
        space: 1,
      ),
    );
  }
}
