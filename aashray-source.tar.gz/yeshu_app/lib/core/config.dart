/// App-wide constants. Cashfree private credentials belong only on the server.
class AppConfig {
  const AppConfig._();

  static const appName = 'Aashray';
  static const fullName = 'Aashray: Bible, Wallpapers & Status';
  static const tagline = 'Bible · Wallpapers · Status · Ringtones';
  static const androidPackage = 'com.aashray.faith';
  static const playStoreUrl =
      'https://play.google.com/store/apps/details?id=$androidPackage';

  /// Only for internal test builds (`--dart-define=ALLOW_TEST_UNLOCK=true`):
  /// shows a "Test unlock" link on the paywall. Never set for store builds.
  static const allowTestUnlock = bool.fromEnvironment('ALLOW_TEST_UNLOCK');

  /// Public media bucket (wallpapers, live videos, Peace audio, daily
  /// backgrounds). Read-only.
  static const mediaBase =
      'https://pub-d9ad13d080884ba18697f09f5aa3b7e9.r2.dev';
}
