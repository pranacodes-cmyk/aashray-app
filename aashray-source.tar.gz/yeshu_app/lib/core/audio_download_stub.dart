import 'dart:typed_data';

void downloadAudio(Uint8List bytes, String filename) {}
