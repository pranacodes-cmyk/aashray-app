import 'dart:typed_data';

void downloadStatus(Uint8List bytes, String filename) {}
