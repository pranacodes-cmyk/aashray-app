import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'native/media_bridge.dart';
import 'status_download_stub.dart'
    if (dart.library.js_interop) 'status_download_web.dart';

class StatusExport {
  static Future<Uint8List?> capture(GlobalKey key) async {
    final boundary = key.currentContext?.findRenderObject();
    if (boundary is! RenderRepaintBoundary) return null;
    final image = await boundary.toImage(
      pixelRatio: 1080 / boundary.size.width,
    );
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    return data?.buffer.asUint8List();
  }

  static Future<bool> save(Uint8List bytes) async {
    if (kIsWeb) {
      downloadStatus(bytes, 'aashray-blessing.png');
      return true;
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/aashray-blessing.png');
    await file.writeAsBytes(bytes);
    return MediaBridge.saveImage(
      file.path,
      'Aashray blessing ${DateTime.now().millisecondsSinceEpoch}',
    );
  }

  static Future<void> share(Uint8List bytes, {bool whatsapp = false}) async {
    if (whatsapp && !kIsWeb) {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/aashray-blessing.png');
      await file.writeAsBytes(bytes);
      if (await MediaBridge.shareToWhatsApp(file.path)) return;
    }
    await SharePlus.instance.share(
      ShareParams(
        files: [XFile.fromData(bytes, mimeType: 'image/png')],
        fileNameOverrides: ['aashray-blessing.png'],
        title: 'A blessing for you',
      ),
    );
  }
}
