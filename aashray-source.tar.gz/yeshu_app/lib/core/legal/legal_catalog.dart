import 'dart:convert';
import 'package:flutter/services.dart';

enum LegalKind { terms, privacy, refunds, delivery, contact }

class LegalCatalog {
  LegalCatalog._();
  static Future<Map<String, dynamic>>? _pending;
  static Future<Map<String, dynamic>> load() => _pending ??= _read();
  static Future<Map<String, dynamic>> _read() async {
    try {
      return jsonDecode(await rootBundle.loadString('assets/data/legal.json'))
          as Map<String, dynamic>;
    } catch (_) {
      _pending = null;
      rethrow;
    }
  }

  static String title(LegalKind kind) => switch (kind) {
    LegalKind.terms => 'Terms & Conditions',
    LegalKind.privacy => 'Privacy Policy',
    LegalKind.refunds => 'Refund & Cancellation',
    LegalKind.delivery => 'Digital Delivery Policy',
    LegalKind.contact => 'Contact & Support',
  };
}
