import 'dart:convert';
import 'package:flutter/services.dart';

class StatusTemplate {
  const StatusTemplate({
    required this.id,
    required this.wallpaperId,
    required this.background,
    required this.text,
    required this.reference,
    required this.greeting,
    required this.categoryId,
  });
  final String id,
      wallpaperId,
      background,
      text,
      reference,
      greeting,
      categoryId;
  factory StatusTemplate.fromJson(Map<String, dynamic> j) => StatusTemplate(
    id: j['id'] as String,
    wallpaperId: j['wallpaperId'] as String,
    background: j['background'] as String,
    text: j['text'] as String,
    reference: j['reference'] as String,
    greeting: j['greeting'] as String,
    categoryId: j['categoryId'] as String,
  );
}

class StatusTemplates {
  static List<StatusTemplate> featured = const [];
  static Future<void> load() async {
    final raw =
        jsonDecode(
              await rootBundle.loadString('assets/data/status_templates.json'),
            )
            as List;
    featured =
        raw
            .map((j) => StatusTemplate.fromJson(j as Map<String, dynamic>))
            .toList();
  }
}
