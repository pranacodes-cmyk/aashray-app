import 'dart:convert';
import 'package:archive/archive.dart';

/// Some same-origin hosts transparently decompress .json.gz responses.
List<List<String>> decodeBibleBook(List<int> bytes) {
  final compressed = bytes.length >= 2 && bytes[0] == 0x1f && bytes[1] == 0x8b;
  final decoded = compressed ? const GZipDecoder().decodeBytes(bytes) : bytes;
  return [
    for (final chapter in jsonDecode(utf8.decode(decoded)) as List)
      [for (final verse in chapter as List) (verse as String).trim()],
  ];
}
