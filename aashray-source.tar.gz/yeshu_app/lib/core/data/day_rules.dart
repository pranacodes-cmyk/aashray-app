/// Pure "what belongs to today" rules shared by Home, Daily Wallpaper, Status
/// and Peace. The daily wallpaper's Android service uses the same maths, so the
/// in-app preview always matches the applied wallpaper. Tested in
/// `test/day_rules_test.dart`.
library;

/// 1-based day of year (Jan 1 = 1), same as java.util.Calendar.DAY_OF_YEAR.
int dayOfYear(DateTime d) {
  final start = DateTime.utc(d.year, 1, 1);
  final day = DateTime.utc(d.year, d.month, d.day);
  return day.difference(start).inDays + 1;
}

/// Verse list index for a date: (dayOfYear - 1) mod count.
int verseIndexFor(DateTime d, int count) =>
    count <= 0 ? 0 : (dayOfYear(d) - 1) % count;

/// Daily background index: dayOfYear mod count (Jan 1 → second background),
/// matching the native service's `(day % 20) + 1` file name.
int backgroundIndexFor(DateTime d, int count) =>
    count <= 0 ? 0 : dayOfYear(d) % count;

/// Greeting for the local hour.
String greetingFor(int hour) {
  final h = hour % 24;
  if (h >= 4 && h < 12) return 'Good morning';
  if (h >= 12 && h < 17) return 'Good afternoon';
  if (h >= 17 && h < 21) return 'Good evening';
  return 'Good night';
}

/// Prayer moment for the local hour: morning 04–11, afternoon 12–16,
/// evening 17–20, night 21–03.
String prayerSlotFor(int hour) {
  final h = hour % 24;
  if (h >= 4 && h < 12) return 'morning';
  if (h >= 12 && h < 17) return 'afternoon';
  if (h >= 17 && h < 21) return 'evening';
  return 'night';
}

/// ISO weekday whose prayers belong to [now]; before 4 AM it is still
/// "last night".
int prayerWeekdayFor(DateTime now) {
  final d = now.hour < 4 ? now.subtract(const Duration(hours: 4)) : now;
  return d.weekday;
}

const kMonthNames = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

String longDate(DateTime d) =>
    '${kMonthNames[d.month - 1]} ${d.day}, ${d.year}';
