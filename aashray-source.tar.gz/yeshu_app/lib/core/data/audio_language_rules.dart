/// Hindi is the default; only an explicit English choice selects English.
String audioLanguageFor(String? saved) => saved == 'en' ? 'en' : 'hi';

Map<String, dynamic> audioVersionFor(Map<String, dynamic> track, String lang) {
  if (lang == 'en') return track;
  final variants = track['i18n'];
  final hindi = variants is Map ? variants['hi'] : null;
  if (hindi is! Map || hindi['audio'] is! String || (hindi['audio'] as String).isEmpty) {
    throw StateError('Hindi recording unavailable for ${track['id']}');
  }
  return {...track, ...Map<String, dynamic>.from(hindi)};
}