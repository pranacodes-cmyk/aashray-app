import 'dart:convert';

import 'package:flutter/services.dart';

import 'day_rules.dart';

class WallpaperCategory {
  const WallpaperCategory(this.slug, this.name);
  final String slug;
  final String name;
}

class StaticWallpaper {
  const StaticWallpaper({
    required this.id,
    required this.title,
    required this.image,
    this.category,
  });
  final String id;
  final String title;
  final String image;
  final String? category;
}

class LiveWallpaper {
  const LiveWallpaper({
    required this.id,
    required this.title,
    required this.video,
    this.preview,
    required this.category,
  });
  final String id;
  final String title;
  final String video;
  final String? preview;
  final String category;

  String get posterAsset => 'assets/live_posters/$id.webp';
}

class Verse {
  const Verse(this.text, this.reference);
  final String text;
  final String reference;
}

class StatusItem {
  const StatusItem({
    required this.id,
    required this.text,
    required this.reference,
    required this.categoryId,
  });
  final String id;
  final String text;
  final String reference;
  final String categoryId;
}

class StatusCategory {
  const StatusCategory({
    required this.id,
    required this.name,
    required this.greeting,
    required this.items,
  });
  final String id;
  final String name;
  final String greeting;
  final List<StatusItem> items;
}

class Ringtone {
  const Ringtone({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.asset,
    required this.seconds,
  });
  final String id;
  final String title;
  final String subtitle;
  final String asset;
  final int seconds;
}

/// Everything bundled under assets/data, loaded once at startup.
class Catalog {
  Catalog._();

  static List<WallpaperCategory> categories = const [];
  static List<StaticWallpaper> wallpapers = const [];
  static List<LiveWallpaper> live = const [];
  static List<Verse> verses = const [];
  static List<String> backgrounds = const [];
  static List<StatusCategory> status = const [];
  static List<Ringtone> ringtones = const [];
  static Set<String> _posters = const {};

  static Future<void> load() async {
    // Typed futures started together and awaited by name: a mixed-type
    // positional Future.wait list crashed release Android startup with a
    // RangeError on results[5].
    final wallpapersJson = rootBundle.loadString('assets/data/wallpapers.json');
    final versesJson = rootBundle.loadString('assets/data/verses.json');
    final backgroundsJson = rootBundle.loadString(
      'assets/data/verse_backgrounds.json',
    );
    final statusJson = rootBundle.loadString('assets/data/status.json');
    final ringtonesJson = rootBundle.loadString('assets/data/ringtones.json');
    final wp = jsonDecode(await wallpapersJson) as Map<String, dynamic>;
    categories = [
      for (final c in wp['categories'] as List)
        WallpaperCategory(c['slug'] as String, c['name'] as String),
    ];
    wallpapers = [
      for (final w in wp['wallpapers'] as List)
        StaticWallpaper(
          id: w['id'] as String,
          title: _clean(w['title'] as String? ?? ''),
          image: w['image'] as String,
          category: w['category'] as String?,
        ),
    ];
    // Poster lookup is cosmetic; a manifest problem must never block startup.
    try {
      final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
      _posters =
          manifest
              .listAssets()
              .where((a) => a.startsWith('assets/live_posters/'))
              .toSet();
    } catch (_) {
      _posters = const {};
    }
    live = [
      for (final w in wp['live'] as List)
        LiveWallpaper(
          id: w['id'] as String,
          title: _clean(w['title'] as String? ?? ''),
          video: w['video'] as String,
          preview: w['preview'] as String?,
          category: w['category'] as String? ?? '',
        ),
    ];
    verses = [
      for (final v in jsonDecode(await versesJson) as List)
        Verse(v['text'] as String, v['reference'] as String),
    ];
    backgrounds = [
      for (final b in jsonDecode(await backgroundsJson) as List)
        b['url'] as String,
    ];
    status = [
      for (final c in jsonDecode(await statusJson) as List)
        StatusCategory(
          id: c['id'] as String,
          name: c['name'] as String,
          greeting: c['greeting'] as String,
          items: [
            for (final i in c['items'] as List)
              StatusItem(
                id: i['id'] as String,
                text: i['text'] as String,
                reference: i['reference'] as String,
                categoryId: c['id'] as String,
              ),
          ],
        ),
    ];
    ringtones = [
      for (final r in jsonDecode(await ringtonesJson) as List)
        Ringtone(
          id: r['id'] as String,
          title: r['title'] as String,
          subtitle: r['subtitle'] as String,
          asset: r['asset'] as String,
          seconds: (r['seconds'] as num).toInt(),
        ),
    ];
  }

  static bool hasPoster(LiveWallpaper w) => _posters.contains(w.posterAsset);

  static Verse verseFor(DateTime d) =>
      verses.isEmpty
          ? const Verse(
            'The Lord is my shepherd; I shall not want.',
            'Psalm 23:1',
          )
          : verses[verseIndexFor(d, verses.length)];

  static String? backgroundFor(DateTime d) =>
      backgrounds.isEmpty
          ? null
          : backgrounds[backgroundIndexFor(d, backgrounds.length)];

  /// Status cards rotate through the calm daily backgrounds.
  static String statusBackground(int index) =>
      backgrounds.isEmpty ? '' : backgrounds[index % backgrounds.length];

  static String categoryName(String? slug) {
    for (final c in categories) {
      if (c.slug == slug) return c.name;
    }
    return 'Wallpapers';
  }

  // "Viral 07 Jesus Jesus Light" → "Jesus Light"
  static final _slugPrefix = RegExp(r'^[A-Za-z]+ \d{1,3}\s+');
  static String _clean(String title) {
    final cleaned = title.replaceFirst(_slugPrefix, '');
    final seen = <String>{};
    final out = <String>[];
    for (final w in cleaned.split(RegExp(r'\s+'))) {
      if (seen.add(w.toLowerCase())) out.add(w);
    }
    return out.isEmpty ? title : out.join(' ');
  }
}
