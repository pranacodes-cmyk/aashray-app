import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
/// Web resolves a read-only original image through Aashray's same-origin CDN
/// snapshot. Native retains the original catalog URL; no upstream writes.
class WebMedia {
  static Map<String, String> _urls = {};
  static Future<void> load() async {
    if (!kIsWeb) return;
    try { _urls = (jsonDecode(await rootBundle.loadString('assets/data/web_media.json')) as Map<String, dynamic>).cast<String, String>(); } catch (_) { _urls = {}; }
  }
  static String resolve(String url) => kIsWeb ? (_urls[url] ?? url) : url;
}
