import 'bible_repo.dart';

typedef ReadingPosition = ({int bookId, int chapter});

ReadingPosition initialReadingPosition(
  List<BibleBook> books,
  int? savedBook,
  int? savedChapter,
) {
  for (final book in books) {
    if (book.id == savedBook &&
        savedChapter != null &&
        savedChapter >= 1 &&
        savedChapter <= book.chapters) {
      return (bookId: book.id, chapter: savedChapter);
    }
  }
  return (bookId: books.isEmpty ? 0 : books.first.id, chapter: 1);
}

ReadingPosition? nextReadingPosition(
  List<BibleBook> books,
  int bookId,
  int chapter,
) {
  final index = books.indexWhere((book) => book.id == bookId);
  if (index < 0) return null;
  if (chapter < books[index].chapters)
    return (bookId: bookId, chapter: chapter + 1);
  if (index + 1 >= books.length) return null;
  return (bookId: books[index + 1].id, chapter: 1);
}
