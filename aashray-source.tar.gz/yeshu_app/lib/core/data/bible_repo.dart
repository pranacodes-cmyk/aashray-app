import 'dart:convert';
import 'bible_decode.dart';
import 'package:flutter/services.dart';

class BibleBook {
  const BibleBook({
    required this.id,
    required this.name,
    required this.chapters,
  });
  final int id;
  final String name;
  final int chapters;

  /// Genesis–Malachi are 0–38 in the canonical order.
  bool get isOldTestament => id < 39;
}

/// Bundled King James Version (public domain). Books are gzip JSON files:
/// `[[verse, verse, …] per chapter]`.
class BibleRepo {
  BibleRepo._();

  static final instance = BibleRepo._();

  List<BibleBook> books = const [];
  final Map<int, List<List<String>>> _cache = {};
  final Map<int, Future<List<List<String>>>> _inflight = {};

  Future<void> loadIndex() async {
    if (books.isNotEmpty) return;
    final raw =
        jsonDecode(await rootBundle.loadString('assets/bible/en/index.json'))
            as Map<String, dynamic>;
    books = [
      for (final b in raw['books'] as List)
        BibleBook(
          id: b['canonicalId'] as int,
          name: b['name'] as String,
          chapters: b['chapters'] as int,
        ),
    ];
  }

  BibleBook? book(int id) {
    for (final b in books) {
      if (b.id == id) return b;
    }
    return null;
  }

  Future<List<List<String>>> _book(int id) {
    final cached = _cache[id];
    if (cached != null) return Future.value(cached);
    final running = _inflight[id];
    if (running != null) return running;
    final future = () async {
      final data = await rootBundle.load('assets/bible/en/$id.json.gz');
      final parsed = decodeBibleBook(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      );
      _cache[id] = parsed;
      return parsed;
    }();
    _inflight[id] = future;
    future.whenComplete(() {
      _inflight.remove(id);
    });
    return future;
  }

  /// Verses of chapter [chapter] (1-based).
  Future<List<String>> chapter(int bookId, int chapter) async {
    final b = await _book(bookId);
    if (chapter < 1 || chapter > b.length) return const [];
    return b[chapter - 1];
  }
}
