import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';

import '../config.dart';
import '../prefs.dart';
import 'audio_language_rules.dart';
import 'day_rules.dart';

class PeaceTrack {
  const PeaceTrack({
    required this.id,
    required this.kind,
    required this.title,
    required this.description,
    required this.scripture,
    required this.duration,
    required this.audioPath,
    required this.coverPath,
    required this.thumbPath,
    this.slot,
    this.weekday,
    this.language = 'en',
  });

  final String id;

  /// prayer | meditation | story
  final String kind;
  final String title;
  final String description;
  final String scripture;
  final int duration;
  final String audioPath;
  final String coverPath;
  final String thumbPath;
  final String? slot;
  final int? weekday;
  final String language;

  String get audioUrl => '${AppConfig.mediaBase}/$audioPath';
  String get coverUrl => '${AppConfig.mediaBase}/$coverPath';
  String get thumbUrl =>
      '${AppConfig.mediaBase}/${thumbPath.isEmpty ? coverPath : thumbPath}';

  String get kindLabel => switch (kind) {
    'prayer' => 'Prayer',
    'meditation' => 'Meditation',
    _ => 'Bedtime story',
  };

  String get minutesLabel => '${(duration / 60).ceil()} min';
}

/// Hindi/English Peace library (prayers for four moments of each day, meditations,
/// bedtime Bible stories), streamed from the public media bucket.
class PeaceCatalog {
  PeaceCatalog._();

  static List<PeaceTrack> tracks = const [];
  static String attribution = '';
  static final language = ValueNotifier<String>('hi');
  static List<Map<String, dynamic>> _records = [];
  static Map<String, dynamic> _credits = {};

  static Future<void> selectLanguage(String selected) async {
    final next = audioLanguageFor(selected);
    if (next == language.value) return;
    await Prefs.setString('audio_language', next);
    _resolve(next);
    language.value = next;
  }

  static PeaceTrack localized(PeaceTrack track) =>
      tracks.firstWhere((t) => t.id == track.id, orElse: () => track);

  static Future<void> load() async {
    final raw =
        jsonDecode(
              await rootBundle.loadString('assets/data/peace_catalog.json'),
            )
            as Map<String, dynamic>;
    _credits = Map<String, dynamic>.from(raw['attributions'] as Map? ?? {});
    _records = [for (final t in raw['tracks'] as List) Map<String, dynamic>.from(t as Map)];
    final selected = audioLanguageFor(Prefs.getString('audio_language'));
    _resolve(selected);
    language.value = selected;
  }

  static void _resolve(String selected) {
    attribution = _credits[selected] as String? ?? '';
    tracks = [
      for (final record in _records)
        for (final t in [audioVersionFor(record, selected)])
        PeaceTrack(
          id: t['id'] as String,
          kind: t['kind'] as String,
          title: t['title'] as String,
          description: t['description'] as String? ?? '',
          scripture: t['scripture'] as String? ?? '',
          duration: (t['duration'] as num?)?.toInt() ?? 0,
          audioPath: t['audio'] as String,
          coverPath: t['cover'] as String? ?? '',
          thumbPath: t['thumb'] as String? ?? '',
          slot: t['slot'] as String?,
          weekday: (t['weekday'] as num?)?.toInt(),
          language: selected,
        ),
    ];
  }

  static List<PeaceTrack> byKind(String kind) =>
      tracks.where((t) => t.kind == kind).toList();

  /// The four prayers (morning → night) that belong to today.
  static List<PeaceTrack> prayersFor(DateTime now) {
    final wd = prayerWeekdayFor(now);
    const order = ['morning', 'afternoon', 'evening', 'night'];
    final list =
        tracks.where((t) => t.kind == 'prayer' && t.weekday == wd).toList()
          ..sort(
            (a, b) => order
                .indexOf(a.slot ?? '')
                .compareTo(order.indexOf(b.slot ?? '')),
          );
    return list;
  }

  /// The prayer for this moment of the day, if any.
  static PeaceTrack? currentPrayer(DateTime now) {
    final slot = prayerSlotFor(now.hour);
    for (final t in prayersFor(now)) {
      if (t.slot == slot) return t;
    }
    final today = prayersFor(now);
    return today.isEmpty ? null : today.first;
  }
}
