import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';

import '../data/catalog.dart';
import '../data/peace_catalog.dart';
import '../prefs.dart';

/// What the single shared player is holding right now.
class NowPlaying {
  const NowPlaying.peace(PeaceTrack this.track) : ringtone = null;
  const NowPlaying.ringtone(Ringtone this.ringtone) : track = null;

  final PeaceTrack? track;
  final Ringtone? ringtone;

  String get id => track?.id ?? 'ring-${ringtone!.id}';
  bool get isPeace => track != null;
  String get title => track?.title ?? ringtone!.title;
  String get subtitle =>
      track != null
          ? '${track!.kindLabel} · ${track!.minutesLabel}'
          : ringtone!.subtitle;
}

/// One player for the whole app (Peace prayers + ringtone previews), so two
/// sounds never play at once. Peace keeps playing with the screen off and
/// resumes where the listener stopped.
class AudioHub extends ChangeNotifier {
  AudioHub._() {
    _player.playerStateStream.listen(
      _onState,
      onError: (Object e, StackTrace _) => _fail(),
    );
    _player.positionStream.listen(_onPosition);
  }

  static final instance = AudioHub._();

  final AudioPlayer _player = AudioPlayer();
  NowPlaying? _current;
  bool _loading = false;
  String? _error;
  int _lastSavedSecond = -1;

  AudioPlayer get player => _player;
  NowPlaying? get current => _current;
  bool get playing =>
      _player.playing && _player.processingState != ProcessingState.completed;
  bool get loading => _loading;
  String? get error => _error;

  bool isCurrent(String id) => _current?.id == id;

  static String _posKey(String id) => 'peace_pos_$id';

  /// Saved resume point: only after 20 s and not within the last 45 s.
  static int resumeSecondsFor(PeaceTrack t) {
    final saved = Prefs.getInt(_posKey(t.id)) ?? 0;
    if (saved < 20 || t.duration <= 0) return 0;
    if (saved >= t.duration - 45) return 0;
    return saved;
  }

  Future<void> changeLanguage(String selected) async {
    if (_loading || selected == PeaceCatalog.language.value) return;
    final previous = _current?.track;
    final wasPlaying = playing;
    if (previous != null) await stop();
    await PeaceCatalog.selectLanguage(selected);
    if (previous != null) await playPeace(PeaceCatalog.localized(previous), autoplay: wasPlaying);
  }

  Future<void> playPeace(PeaceTrack track, {bool autoplay = true}) async {
    final t = PeaceCatalog.localized(track);
    if (isCurrent(t.id) && _current?.track?.language == t.language) {
      if (!playing) await _player.play();
      return;
    }
    await _load(
      NowPlaying.peace(t),
      AudioSource.uri(
        Uri.parse(t.audioUrl),
        tag: MediaItem(
          id: t.id,
          title: t.title,
          artist: t.kindLabel,
          album: 'Aashray · Prayers',
          artUri: Uri.parse(t.coverUrl),
          duration: Duration(seconds: t.duration),
        ),
      ),
      start: Duration(seconds: resumeSecondsFor(t)),
      autoplay: autoplay,
    );
  }

  Future<void> playRingtone(Ringtone r) async {
    final now = NowPlaying.ringtone(r);
    if (isCurrent(now.id)) {
      if (playing) {
        await _player.pause();
      } else {
        if (_player.processingState == ProcessingState.completed)
          await _player.seek(Duration.zero);
        await _player.play();
      }
      return;
    }
    await _load(
      now,
      AudioSource.asset(
        r.asset,
        tag: MediaItem(
          id: now.id,
          title: r.title,
          artist: 'Aashray ringtone',
          album: 'Aashray · Ringtones',
        ),
      ),
    );
  }

  Future<void> _load(
    NowPlaying item,
    AudioSource source, {
    Duration start = Duration.zero,
    bool autoplay = true,
  }) async {
    _saveProgress(force: true);
    _current = item;
    _loading = true;
    _error = null;
    _lastSavedSecond = -1;
    notifyListeners();
    try {
      await _player.stop();
      await _player.setAudioSource(source, initialPosition: start);
      _loading = false;
      notifyListeners();
      if (autoplay) unawaited(_player.play());
    } catch (_) {
      _fail();
    }
  }

  void _fail() {
    _loading = false;
    _error =
        _current?.isPeace == true
            ? 'Could not play this prayer. Please check your internet and try again.'
            : 'Could not play this sound.';
    notifyListeners();
  }

  Future<void> toggle() async {
    if (_current == null) return;
    if (playing) {
      await _player.pause();
      _saveProgress(force: true);
    } else {
      if (_player.processingState == ProcessingState.completed)
        await _player.seek(Duration.zero);
      await _player.play();
    }
  }

  Future<void> seekBy(int seconds) async {
    final d = _player.duration ?? Duration.zero;
    var p = _player.position + Duration(seconds: seconds);
    if (p < Duration.zero) p = Duration.zero;
    if (d > Duration.zero && p > d) p = d;
    await _player.seek(p);
  }

  Future<void> seek(Duration d) => _player.seek(d);

  Future<void> stop() async {
    _saveProgress(force: true);
    await _player.stop();
    _current = null;
    _loading = false;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  bool? _wasPlaying;
  ProcessingState? _wasState;

  void _onState(PlayerState s) {
    if (s.processingState == ProcessingState.completed) {
      final t = _current?.track;
      if (t != null) Prefs.remove(_posKey(t.id));
    }
    if (_wasPlaying == s.playing && _wasState == s.processingState) return;
    _wasPlaying = s.playing;
    _wasState = s.processingState;
    notifyListeners();
  }

  void _onPosition(Duration p) {
    if (p.inSeconds - _lastSavedSecond >= 10) _saveProgress();
  }

  void _saveProgress({bool force = false}) {
    final t = _current?.track;
    if (t == null) return;
    if (_player.processingState == ProcessingState.completed) return;
    final s = _player.position.inSeconds;
    if (!force && s == _lastSavedSecond) return;
    _lastSavedSecond = s;
    if (s > 0) Prefs.setInt(_posKey(t.id), s);
  }
}
