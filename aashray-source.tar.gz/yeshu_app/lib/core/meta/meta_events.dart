import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Meta app events through the native Facebook core SDK (Android only).
///
/// The SDK itself logs install / app open (activate). The app only logs
/// funnel steps here. Money events (StartTrial / Purchase) are NEVER logged
/// from the app — the Cashfree webhook on the server is their single sender,
/// so Meta never double-counts a payment.
class MetaEvents {
  MetaEvents._();
  static const _ch = MethodChannel('aashray/meta');

  /// Events the app is allowed to send. Anything else is dropped.
  static const allowed = <String>{
    'fb_mobile_content_view',
    'fb_mobile_initiated_checkout',
    'fb_mobile_add_payment_info',
    'fb_mobile_tutorial_completion',
    'CheckoutFailed',
  };

  static bool isAllowed(String name) => allowed.contains(name);

  static Future<void> log(String name, {double? value, Map<String, String> params = const {}}) async {
    if (kIsWeb || !isAllowed(name)) return;
    try {
      await _ch.invokeMethod('log', {'name': name, 'value': value, 'params': {'fb_currency': 'INR', ...params}});
    } catch (_) {}
  }

  static Future<String?> anonymousId() async {
    if (kIsWeb) return null;
    try {
      return await _ch.invokeMethod<String>('anonId');
    } catch (_) {
      return null;
    }
  }

  static Future<String?> advertiserId() async {
    if (kIsWeb) return null;
    try {
      return await _ch.invokeMethod<String>('advertiserId').timeout(const Duration(seconds: 3));
    } catch (_) {
      return null;
    }
  }

  static void paywallView() => log('fb_mobile_content_view', params: {'fb_content_type': 'paywall', 'fb_content_id': 'aashray_premium'});
  static void checkoutStarted() => log('fb_mobile_initiated_checkout', value: 2, params: {'fb_content_id': 'aashray_premium', 'fb_num_items': '1'});
  static void upiOpened() => log('fb_mobile_add_payment_info', params: {'fb_payment_info_available': '1'});
  static void checkoutFailed(String reason) => log('CheckoutFailed', params: {'reason': reason});
}
