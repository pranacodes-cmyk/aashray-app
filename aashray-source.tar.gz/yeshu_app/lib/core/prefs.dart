import 'package:shared_preferences/shared_preferences.dart';

/// Thin synchronous wrapper around SharedPreferences, loaded once at startup.
class Prefs {
  Prefs._();

  static SharedPreferences? _p;

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
  }

  static SharedPreferences get _sp {
    final p = _p;
    if (p == null) throw StateError('Prefs.init() was not awaited');
    return p;
  }

  static String? getString(String k) => _sp.getString(k);
  static int? getInt(String k) => _sp.getInt(k);
  static double? getDouble(String k) => _sp.getDouble(k);
  static bool getBool(String k, {bool fallback = false}) =>
      _sp.getBool(k) ?? fallback;
  static List<String> getList(String k) => _sp.getStringList(k) ?? const [];

  static Future<void> setString(String k, String v) => _sp.setString(k, v);
  static Future<void> setInt(String k, int v) => _sp.setInt(k, v);
  static Future<void> setDouble(String k, double v) => _sp.setDouble(k, v);
  static Future<void> setBool(String k, bool v) => _sp.setBool(k, v);
  static Future<void> setList(String k, List<String> v) =>
      _sp.setStringList(k, v);
  static Future<void> remove(String k) => _sp.remove(k);
}
