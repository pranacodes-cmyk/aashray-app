import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'prefs.dart';

/// How the paywall's Skip behaves (server controlled).
/// off    – no Skip; hard paywall.
/// soft   – Skip shows Home; any tap opens the paywall again.
/// review – Skip opens the full app (store reviewers / testers).
enum SkipMode { off, soft, review }

SkipMode parseSkipMode(Object? v) => switch (v) {
  'soft' => SkipMode.soft,
  'review' => SkipMode.review,
  _ => SkipMode.off,
};

/// Server-driven copy, prices and switches. Bundled defaults keep the app
/// instant and offline; the last fetched value is cached and used next start,
/// and a fresh fetch (after first paint) updates listeners live.
class RemoteConfig extends ChangeNotifier {
  RemoteConfig._();
  static final instance = RemoteConfig._();

  static const _kCache = 'aashray_remote_config_v1';
  static const _url =
      'https://wwwoyfvnzapsramqvxyg.supabase.co/rest/v1/aashray_app_config?id=eq.live&select=config';
  static const _anonKey = 'sb_publishable_HgjCCmmOAahGSgOspW0Sag_Sw8Gta8f';

  Map<String, dynamic> _c = const {};

  @visibleForTesting
  void debugSet(Map<String, dynamic> c) => _c = c;

  /// Instant: cached server value (or bundled defaults). No network.
  void loadCached() {
    final raw = Prefs.getString(_kCache);
    if (raw == null) return;
    try { _c = (jsonDecode(raw) as Map).cast<String, dynamic>(); } catch (_) {}
  }

  /// Background refresh; never blocks startup.
  Future<void> refresh() async {
    if (kIsWeb) return;
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 6);
    try {
      final req = await client.getUrl(Uri.parse(_url));
      req.headers..set('apikey', _anonKey)..set('authorization', 'Bearer $_anonKey');
      final res = await req.close().timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final rows = jsonDecode(await res.transform(utf8.decoder).join());
      if (rows is! List || rows.isEmpty) return;
      final cfg = (rows.first as Map)['config'];
      if (cfg is! Map) return;
      _c = cfg.cast<String, dynamic>();
      await Prefs.setString(_kCache, jsonEncode(_c));
      notifyListeners();
    } catch (_) {
      // Keep cached/bundled values.
    } finally {
      client.close(force: true);
    }
  }

  Map<String, dynamic> get _p => (_c['paywall'] is Map) ? (_c['paywall'] as Map).cast<String, dynamic>() : const {};

  int _int(Object? v, int d, int lo, int hi) => v is num && v >= lo && v <= hi ? v.round() : d;
  String _str(Object? v, String d) => v is String && v.trim().isNotEmpty ? v : d;
  String _fill(String s) => s.replaceAll('{trial}', '$trialPrice').replaceAll('{monthly}', '$monthlyPrice');

  SkipMode get skipMode => parseSkipMode(_c['skip_mode']);
  int get trialPrice => _int(_c['trial_price_inr'], 2, 1, 999);
  int get trialDays => _int(_c['trial_days'], 1, 1, 30);
  int get monthlyPrice => _int(_c['monthly_price_inr'], 399, 1, 9999);

  String get headline => _str(_p['headline'], 'A little closer to Him, every day.');
  String get cta => _fill(_str(_p['cta'], 'Start ₹{trial} trial'));
  bool get showMonthlyPrice => _p['show_monthly_price'] != false;
  String get finePrint {
    final custom = _p['fine_print'];
    if (!showMonthlyPrice) {
      // Hidden price: never show a custom line that mentions it.
      return custom is String && custom.trim().isNotEmpty && !custom.contains('{monthly}')
          ? _fill(custom) : '100% secure · Cancel anytime';
    }
    return _fill(_str(custom, '100% secure · then ₹{monthly}/month · Cancel anytime'));
  }
  bool get showVideo => _p['show_video'] != false;
  String get skipLabel => _str(_p['skip_label'], 'Skip');
  Color? get primaryColor => parseHexColor(_p['primary_color']);
}

/// "#RRGGBB" / "RRGGBB" → Color, else null.
Color? parseHexColor(Object? v) {
  if (v is! String) return null;
  final h = v.replaceAll('#', '').trim();
  if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(h)) return null;
  return Color(0xFF000000 | int.parse(h, radix: 16));
}
