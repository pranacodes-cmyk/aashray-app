import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio_background/just_audio_background.dart';

import 'core/config.dart';
import 'core/data/bible_repo.dart';
import 'core/data/catalog.dart';
import 'core/data/status_templates.dart';
import 'core/data/web_media.dart';
import 'core/data/peace_catalog.dart';
import 'core/premium/premium_store.dart';
import 'core/prefs.dart';
import 'core/theme.dart';
import 'screens/paywall/paywall_screen.dart';
import 'screens/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(AppTheme.overlay);
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const AashrayApp());
}

class AashrayApp extends StatelessWidget {
  const AashrayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.fullName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: const StartupGate(),
    );
  }
}

/// Loads settings + bundled content once. A failure shows Retry instead of
/// pretending to be a fresh install (so a paid user is never shown as free).
class StartupGate extends StatefulWidget {
  const StartupGate({super.key});

  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  late Future<void> _boot = _start();
  static bool _audioReady = false;

  Future<void> _start() async {
    await Prefs.init().timeout(const Duration(seconds: 10));
    await Future.wait([
      Catalog.load(),
      StatusTemplates.load(),
      WebMedia.load(),
      PeaceCatalog.load(),
      BibleRepo.instance.loadIndex(),
    ]).timeout(const Duration(seconds: 15));
    if (!_audioReady) {
      try {
        await JustAudioBackground.init(
          androidNotificationChannelId: 'com.aashray.faith.audio',
          androidNotificationChannelName: 'Prayers',
          androidNotificationOngoing: true,
          androidNotificationIcon: 'mipmap/ic_launcher',
        ).timeout(const Duration(seconds: 6));
        _audioReady = true;
      } catch (_) {
        // Audio is optional for startup; the rest of the app still opens.
      }
    }
    PremiumStore.instance.load();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _boot,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done)
          return const _Splash();
        if (snap.hasError) {
          return _StartupError(onRetry: () => setState(() => _boot = _start()));
        }
        return const RootGate();
      },
    );
  }
}

/// Hard paywall: without an active plan only the paywall is shown.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) PremiumStore.instance.refresh();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: PremiumStore.instance,
      builder: (context, _) {
        final active = PremiumStore.instance.isActive;
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 420),
          child:
              active
                  ? const HomeShell(key: ValueKey('shell'))
                  : const PaywallScreen(key: ValueKey('paywall')),
        );
      },
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              'assets/branding/aashray-logo.png',
              width: 72,
              height: 88,
            ),
            const SizedBox(height: 24),
            const Text(
              AppConfig.appName,
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 30,
                fontWeight: FontWeight.w700,
                color: AppColors.ink,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Faith. Peace. Together.',
              style: TextStyle(fontSize: 12, color: AppColors.muted),
            ),
          ],
        ),
      ),
    );
  }
}

class _StartupError extends StatelessWidget {
  const _StartupError({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.refresh_rounded,
                size: 44,
                color: AppColors.primary,
              ),
              const SizedBox(height: 14),
              const Text(
                'Something went wrong while opening the app.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              FilledButton(onPressed: onRetry, child: const Text('Try again')),
            ],
          ),
        ),
      ),
    );
  }
}
