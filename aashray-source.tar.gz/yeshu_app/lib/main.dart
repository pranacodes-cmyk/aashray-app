import 'core/premium/subscription_service.dart';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio_background/just_audio_background.dart';

import 'core/config.dart';
import 'core/data/bible_repo.dart';
import 'core/data/catalog.dart';
import 'core/data/status_templates.dart';
import 'core/data/web_media.dart';
import 'core/data/peace_catalog.dart';
import 'core/premium/premium_store.dart';
import 'core/prefs.dart';
import 'core/remote_config.dart';
import 'package:flutter/gestures.dart';
import 'core/theme.dart';
import 'widgets/common.dart';
import 'screens/paywall/paywall_screen.dart';
import 'screens/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(AppTheme.overlay);
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const AashrayApp());
}

class AashrayApp extends StatelessWidget {
  const AashrayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.fullName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: const StartupGate(),
      // Edge-to-edge Android: keep every screen (mini player, status
      // actions, buttons) above the system navigation buttons.
      builder:
          (context, child) => ColoredBox(
            color: AppColors.bg,
            child: SafeArea(
              top: false,
              left: false,
              right: false,
              child: child ?? const SizedBox.shrink(),
            ),
          ),
    );
  }
}

/// Loads settings + bundled content once. A failure shows Retry instead of
/// pretending to be a fresh install (so a paid user is never shown as free).
class StartupGate extends StatefulWidget {
  const StartupGate({super.key});

  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  late Future<void> _boot = _start();
  static bool _audioReady = false;

  Future<void> _start() async {
    try {
      await _load();
    } catch (e, st) {
      // Release logcat keeps this so native startup failures are diagnosable.
      debugPrint('AASHRAY_STARTUP_ERROR $e\n$st');
      rethrow;
    }
  }

  Future<void> _load() async {
    await Prefs.init().timeout(const Duration(seconds: 10));
    await Future.wait([
      Catalog.load(),
      StatusTemplates.load(),
      WebMedia.load(),
      PeaceCatalog.load(),
      BibleRepo.instance.loadIndex(),
    ]).timeout(const Duration(seconds: 15));
    if (!_audioReady) {
      try {
        await JustAudioBackground.init(
          androidNotificationChannelId: 'com.aashray.faith.audio',
          androidNotificationChannelName: 'Prayers',
          androidNotificationOngoing: true,
          androidNotificationIcon: 'mipmap/ic_launcher',
        ).timeout(const Duration(seconds: 6));
        _audioReady = true;
      } catch (_) {
        // Audio is optional for startup; the rest of the app still opens.
      }
    }
    PremiumStore.instance.load();
    RemoteConfig.instance.loadCached();
    // Fresh server config after paint; updates paywall/skip live.
    Future<void>.delayed(const Duration(milliseconds: 800), RemoteConfig.instance.refresh);
    // Server-verified Cashfree status, after paint (never blocks startup).
    Future<void>.delayed(const Duration(seconds: 2), () => SubscriptionService.instance.syncStatus());
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _boot,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done)
          return const _Splash();
        if (snap.hasError) {
          return _StartupError(onRetry: () => setState(() => _boot = _start()));
        }
        return const RootGate();
      },
    );
  }
}

/// Hard paywall: without an active plan only the paywall is shown.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> with WidgetsBindingObserver {
  bool _softSkipped = false;

  void _skip() {
    final mode = RemoteConfig.instance.skipMode;
    if (mode == SkipMode.review) {
      PremiumStore.instance.setReviewUnlock(true);
    } else if (mode == SkipMode.soft) {
      setState(() => _softSkipped = true);
    }
  }

  void _openPaywall(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      fullscreenDialog: true, builder: (_) => const PaywallScreen()));
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      PremiumStore.instance.refresh();
      SubscriptionService.instance.syncStatus();
      RemoteConfig.instance.refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([PremiumStore.instance, RemoteConfig.instance]),
      builder: (context, _) {
        final mode = RemoteConfig.instance.skipMode;
        // Server switched review mode off: drop the reviewer unlock.
        if (mode != SkipMode.review && PremiumStore.instance.reviewUnlocked) {
          WidgetsBinding.instance.addPostFrameCallback((_) => PremiumStore.instance.setReviewUnlock(false));
        }
        final active = PremiumStore.instance.isActive;
        final Widget child;
        if (active) {
          child = const HomeShell(key: ValueKey('shell'));
        } else if (_softSkipped && mode == SkipMode.soft) {
          child = LockedShell(key: const ValueKey('locked'), onLockedTap: () => _openPaywall(context));
        } else {
          child = ExitGuard(
            key: const ValueKey('paywall'),
            child: PaywallScreen(onSkip: mode == SkipMode.off ? null : _skip),
          );
        }
        return AnimatedSwitcher(duration: const Duration(milliseconds: 420), child: child);
      },
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              'assets/branding/aashray-logo.png',
              width: 72,
              height: 88,
            ),
            const SizedBox(height: 24),
            const Text(
              AppConfig.appName,
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 30,
                fontWeight: FontWeight.w700,
                color: AppColors.ink,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Faith. Peace. Together.',
              style: TextStyle(fontSize: 12, color: AppColors.muted),
            ),
          ],
        ),
      ),
    );
  }
}

class _StartupError extends StatelessWidget {
  const _StartupError({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.refresh_rounded,
                size: 44,
                color: AppColors.primary,
              ),
              const SizedBox(height: 14),
              const Text(
                'Something went wrong while opening the app.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              FilledButton(onPressed: onRetry, child: const Text('Try again')),
            ],
          ),
        ),
      ),
    );
  }
}


/// Home is visible and scrollable, but any tap (cards, tabs, buttons) opens
/// the paywall instead. A tap that turns into a scroll is left alone.
class LockedShell extends StatelessWidget {
  const LockedShell({super.key, required this.onLockedTap});
  final VoidCallback onLockedTap;

  @override
  Widget build(BuildContext context) => RawGestureDetector(
    behavior: HitTestBehavior.translucent,
    gestures: {
      _LockTap: GestureRecognizerFactoryWithHandlers<_LockTap>(
        () => _LockTap(), (r) => r.onTap = onLockedTap),
    },
    child: const HomeShell(),
  );
}

/// Claims a tap on pointer-up before child buttons win the arena; yields to
/// scrolling once the finger moves past touch slop.
class _LockTap extends OneSequenceGestureRecognizer {
  VoidCallback? onTap;
  Offset? _down;

  @override
  void addAllowedPointer(PointerDownEvent event) {
    super.addAllowedPointer(event);
    _down = event.position;
  }

  @override
  void handleEvent(PointerEvent event) {
    if (event is PointerMoveEvent && _down != null && (event.position - _down!).distance > kTouchSlop) {
      resolve(GestureDisposition.rejected);
      stopTrackingPointer(event.pointer);
    } else if (event is PointerUpEvent) {
      resolve(GestureDisposition.accepted);
      stopTrackingPointer(event.pointer);
      onTap?.call();
    } else if (event is PointerCancelEvent) {
      resolve(GestureDisposition.rejected);
      stopTrackingPointer(event.pointer);
    }
  }

  @override
  void rejectGesture(int pointer) {
    // A scroll/drag won: never fire the paywall tap.
    stopTrackingPointer(pointer);
  }

  @override
  void didStopTrackingLastPointer(int pointer) => _down = null;

  @override
  String get debugDescription => 'lockTap';
}
