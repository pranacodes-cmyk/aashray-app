import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Shared personal signature for both preview and exported blessing pictures.
class BlessingSignature extends StatelessWidget {
  const BlessingSignature({super.key, required this.name, this.photo});
  final String name;
  final Uint8List? photo;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      final w = c.maxWidth;
      final bytes = photo;
      return ColoredBox(
        color: AppColors.paper,
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: w * .07,
            vertical: w * .045,
          ),
          child: Row(
            children: [
              if (bytes != null) ...[
                Container(
                  width: w * .22,
                  height: w * .22,
                  padding: EdgeInsets.all(w * .007),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.gold,
                  ),
                  child: ClipOval(
                    child: Image.memory(bytes, fit: BoxFit.cover),
                  ),
                ),
                SizedBox(width: w * .045),
              ] else ...[
                Icon(
                  Icons.favorite_outline,
                  size: w * .09,
                  color: AppColors.gold,
                ),
                SizedBox(width: w * .04),
              ],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'With love & prayers',
                      style: TextStyle(
                        fontSize: w * .034,
                        color: AppColors.muted,
                      ),
                    ),
                    SizedBox(height: w * .014),
                    Text(
                      name.trim().isEmpty ? 'God bless you' : name.trim(),
                      maxLines: 2,
                      style: TextStyle(
                        fontFamily: AppTheme.serif,
                        fontSize: w * .064,
                        height: 1.12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
