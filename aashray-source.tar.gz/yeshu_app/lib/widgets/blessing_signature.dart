import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Personal signature drawn directly on the blessing picture (no separate
/// strip), shared by preview and export so both look identical.
class BlessingSignature extends StatelessWidget {
  const BlessingSignature({super.key, required this.name, this.photo});
  final String name;
  final Uint8List? photo;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      final w = c.maxWidth;
      final bytes = photo;
      final shown = name.trim().isEmpty ? 'God bless you' : name.trim();
      const shadow = [
        Shadow(color: Color(0xCC000000), blurRadius: 10, offset: Offset(0, 1)),
      ];
      return DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppColors.scrim.withValues(alpha: 0),
              AppColors.scrim.withValues(alpha: .55),
            ],
          ),
        ),
        child: Padding(
          padding: EdgeInsets.fromLTRB(w * .08, w * .1, w * .08, w * .07),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (bytes != null) ...[
                Container(
                  width: w * .2,
                  height: w * .2,
                  padding: EdgeInsets.all(w * .008),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [AppColors.imageGold, Color(0xFFB8862B)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.scrim.withValues(alpha: .45),
                        blurRadius: w * .03,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.memory(bytes, fit: BoxFit.cover),
                  ),
                ),
                SizedBox(width: w * .04),
              ],
              Flexible(
                child: Column(
                  crossAxisAlignment:
                      bytes != null
                          ? CrossAxisAlignment.start
                          : CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'With love & prayers',
                      style: TextStyle(
                        fontFamily: AppTheme.serif,
                        fontStyle: FontStyle.italic,
                        fontSize: w * .036,
                        color: AppColors.imageGold,
                        shadows: shadow,
                      ),
                    ),
                    SizedBox(height: w * .01),
                    Text(
                      shown,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign:
                          bytes != null ? TextAlign.start : TextAlign.center,
                      style: TextStyle(
                        fontFamily: AppTheme.serif,
                        fontSize: w * .062,
                        height: 1.1,
                        fontWeight: FontWeight.w700,
                        color: AppColors.imageInk,
                        shadows: shadow,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
