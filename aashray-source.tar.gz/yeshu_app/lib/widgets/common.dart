import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import '../core/data/web_media.dart';

void toast(BuildContext context, String message, {bool error = false}) {
  final m = ScaffoldMessenger.maybeOf(context);
  if (m == null) return;
  m.hideCurrentSnackBar();
  m.showSnackBar(
    SnackBar(
      content: Text(message),
      backgroundColor: error ? AppColors.danger : AppColors.paperDeep,
      duration: const Duration(milliseconds: 2600),
    ),
  );
}

void tapHaptic() => HapticFeedback.selectionClick();

/// Network image with a soft paper placeholder and a calm error state.
class NetImage extends StatelessWidget {
  const NetImage(
    this.url, {
    super.key,
    this.fit = BoxFit.cover,
    this.memWidth,
    this.radius = 0,
  });

  final String url;
  final BoxFit fit;
  final int? memWidth;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final img =
        url.isEmpty
            ? const _Placeholder(error: true)
            : CachedNetworkImage(
              imageUrl: WebMedia.resolve(url),
              fit: fit,
              memCacheWidth: memWidth,
              fadeInDuration: const Duration(milliseconds: 160),
              placeholder: (_, _) => const _Placeholder(),
              errorWidget: (_, _, _) => const _Placeholder(error: true),
            );
    if (radius <= 0) return img;
    return ClipRRect(borderRadius: BorderRadius.circular(radius), child: img);
  }
}

class _Placeholder extends StatelessWidget {
  const _Placeholder({this.error = false});
  final bool error;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: AppColors.paper,
      child: Center(
        child: Icon(
          error ? Icons.image_not_supported_outlined : Icons.image_outlined,
          color: AppColors.line,
          size: 28,
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(
    this.title, {
    super.key,
    this.action,
    this.onAction,
    this.padding,
  });

  final String title;
  final String? action;
  final VoidCallback? onAction;
  final EdgeInsets? padding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? const EdgeInsets.fromLTRB(20, 26, 12, 12),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w800,
                letterSpacing: 0,
                color: AppColors.ink,
              ),
            ),
          ),
          if (action != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(foregroundColor: AppColors.primary),
              child: Text(
                action!,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
        ],
      ),
    );
  }
}

/// Small cross mark used in headers and the paywall.
class CrossMark extends StatelessWidget {
  const CrossMark({super.key, this.size = 22, this.color = AppColors.gold});
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size * 0.7, size),
      painter: _CrossPainter(color),
    );
  }
}

class _CrossPainter extends CustomPainter {
  _CrossPainter(this.color);
  final Color color;

  @override
  void paint(Canvas canvas, Size s) {
    final p =
        Paint()
          ..color = color
          ..strokeWidth = s.width * 0.2
          ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(s.width / 2, s.height * 0.08),
      Offset(s.width / 2, s.height * 0.92),
      p,
    );
    canvas.drawLine(
      Offset(s.width * 0.1, s.height * 0.33),
      Offset(s.width * 0.9, s.height * 0.33),
      p,
    );
  }

  @override
  bool shouldRepaint(_CrossPainter old) => old.color != color;
}

/// Round icon button with a soft background, used on viewers and cards.
class SoftIconButton extends StatelessWidget {
  const SoftIconButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.label,
    this.dark = false,
    this.size = 48,
  });

  final IconData icon;
  final VoidCallback? onTap;
  final String? label;
  final bool dark;
  final double size;

  @override
  Widget build(BuildContext context) {
    final bg = dark ? AppColors.scrim.withValues(alpha: 0.38) : AppColors.paper;
    final fg = dark ? AppColors.imageInk : AppColors.ink;
    final button = Material(
      color: bg,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: size,
          height: size,
          child: Icon(icon, color: fg, size: size * 0.46),
        ),
      ),
    );
    if (label == null) return button;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        button,
        const SizedBox(height: 6),
        Text(
          label!,
          style: TextStyle(
            color: fg,
            fontSize: 12.5,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

/// Editorial heading shared by pushed library screens.
class PageIntro extends StatelessWidget {
  const PageIntro({
    super.key,
    required this.title,
    required this.detail,
    this.icon,
  });
  final String title;
  final String detail;
  final IconData? icon;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 6, 20, 18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontFamily: 'Manrope',
            fontSize: 22,
            fontWeight: FontWeight.w800,
            height: 1.2,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          detail,
          style: const TextStyle(
            color: AppColors.muted,
            fontSize: 13,
            height: 1.6,
          ),
        ),
      ],
    ),
  );
}

/// Keeps reading and library content comfortably sized on wide displays.
class ContentWidth extends StatelessWidget {
  const ContentWidth({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Center(
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 600),
      child: child,
    ),
  );
}

/// Bottom sheet row with an icon in a tinted circle.
class SheetOption extends StatelessWidget {
  const SheetOption({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    required this.onTap,
    this.tint = AppColors.primary,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;
  final Color tint;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 4),
      leading: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: tint.withValues(alpha: 0.1),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: tint),
      ),
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
      ),
      subtitle:
          subtitle == null
              ? null
              : Text(subtitle!, style: const TextStyle(color: AppColors.muted)),
    );
  }
}

/// Full-screen blocking progress used while a wallpaper is being applied.
Future<T> withBusy<T>(
  BuildContext context,
  String message,
  Future<T> Function() task,
) async {
  final nav = Navigator.of(context, rootNavigator: true);
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder:
        (_) => PopScope(
          canPop: false,
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 22, 24, 22),
              child: Row(
                children: [
                  const SizedBox(
                    width: 26,
                    height: 26,
                    child: CircularProgressIndicator(strokeWidth: 2.6),
                  ),
                  const SizedBox(width: 18),
                  Expanded(
                    child: Text(
                      message,
                      style: const TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
  );
  try {
    return await task();
  } finally {
    if (nav.canPop()) nav.pop();
  }
}

/// Asks before leaving the app; returns true when the user chose Exit.
Future<bool> confirmExit(BuildContext context) async {
  final leave = await showModalBottomSheet<bool>(
    context: context,
    backgroundColor: Colors.transparent,
    builder:
        (c) => SafeArea(
          child: Container(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            padding: const EdgeInsets.fromLTRB(22, 14, 22, 18),
            decoration: BoxDecoration(
              color: AppColors.paper,
              borderRadius: BorderRadius.circular(26),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 38,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.line,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(height: 20),
                ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.asset(
                    'assets/branding/aashray-logo.png',
                    width: 64,
                    height: 64,
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Leaving so soon?',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 6),
                const Text(
                  '"The Lord bless you and keep you." — Numbers 6:24\nCome back tomorrow for a new verse.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.muted, height: 1.45),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton(
                    onPressed: () => Navigator.pop(c, false),
                    child: const Text(
                      'Stay',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: TextButton(
                    onPressed: () => Navigator.pop(c, true),
                    child: const Text(
                      'Exit app',
                      style: TextStyle(color: AppColors.muted),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
  );
  return leave == true;
}

/// Root-level back handling: never closes the app without asking.
class ExitGuard extends StatelessWidget {
  const ExitGuard({super.key, required this.child, this.onBack});
  final Widget child;

  /// Return true when the back press was handled (e.g. switched tab).
  final bool Function()? onBack;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (onBack?.call() == true) return;
        if (await confirmExit(context)) SystemNavigator.pop();
      },
      child: child,
    );
  }
}
