import 'package:flutter/material.dart';
import '../core/audio/audio_hub.dart';
import '../core/data/peace_catalog.dart';

class AudioLanguageSwitch extends StatelessWidget {
  const AudioLanguageSwitch({super.key});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
    valueListenable: PeaceCatalog.language,
    builder: (context, selected, _) => SegmentedButton<String>(
      segments: const [
        ButtonSegment(value: 'hi', label: Text('हिन्दी'), icon: Icon(Icons.language)),
        ButtonSegment(value: 'en', label: Text('English')),
      ],
      selected: {selected},
      showSelectedIcon: false,
      onSelectionChanged: (values) => AudioHub.instance.changeLanguage(values.first),
    ),
  );
}