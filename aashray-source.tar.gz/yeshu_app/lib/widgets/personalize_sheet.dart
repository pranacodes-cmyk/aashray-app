import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../core/theme.dart';
import 'common.dart';

class PersonalizeSheet extends StatefulWidget {
  const PersonalizeSheet({super.key, required this.name, this.photo});
  final String name;
  final Uint8List? photo;
  @override
  State<PersonalizeSheet> createState() => _PersonalizeSheetState();
}

class _PersonalizeSheetState extends State<PersonalizeSheet> {
  late final _name = TextEditingController(text: widget.name);
  final _focus = FocusNode();
  late Uint8List? _photo = widget.photo;
  @override
  void dispose() {
    _name.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _apply() =>
      Navigator.pop(context, (name: _name.text.trim(), photo: _photo));
  Future<void> _pick() async {
    _focus.unfocus();
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 600,
        maxHeight: 600,
        imageQuality: 85,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (mounted) setState(() => _photo = bytes);
    } catch (_) {
      if (mounted)
        toast(context, 'Could not open this photo. Please try another.');
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(
        24,
        4,
        24,
        MediaQuery.viewInsetsOf(context).bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Make it yours',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _name,
            focusNode: _focus,
            autofocus: true,
            keyboardType: TextInputType.name,
            textInputAction: TextInputAction.done,
            textCapitalization: TextCapitalization.words,
            maxLength: 30,
            onTap: () => _focus.requestFocus(),
            onSubmitted: (_) => _apply(),
            scrollPadding: const EdgeInsets.all(32),
            decoration: const InputDecoration(
              labelText: 'Your name',
              hintText: 'e.g. Mohit',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              if (_photo case final photo?) ...[
                ClipOval(
                  child: Image.memory(
                    photo,
                    width: 48,
                    height: 48,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(width: 12),
              ],
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pick,
                  icon: const Icon(Icons.add_a_photo_outlined, size: 18),
                  label: Text(
                    _photo == null ? 'Add your photo' : 'Change photo',
                  ),
                ),
              ),
              if (_photo != null)
                IconButton(
                  tooltip: 'Remove photo',
                  onPressed: () => setState(() => _photo = null),
                  icon: const Icon(Icons.close_rounded),
                ),
            ],
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _apply,
            child: const Text('Apply to blessing'),
          ),
        ],
      ),
    ),
  );
}
