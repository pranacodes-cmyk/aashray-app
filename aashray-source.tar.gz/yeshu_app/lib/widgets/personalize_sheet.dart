import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_picker/image_picker.dart';
import '../core/theme.dart';
import 'common.dart';

class PersonalizeSheet extends StatefulWidget {
  const PersonalizeSheet({super.key, required this.name, this.photo});
  final String name;
  final Uint8List? photo;
  @override
  State<PersonalizeSheet> createState() => _PersonalizeSheetState();
}

class _PersonalizeSheetState extends State<PersonalizeSheet> {
  static const _cropSize = 220.0;
  late final _name = TextEditingController(text: widget.name);
  final _focus = FocusNode();
  final _cropKey = GlobalKey();
  final _zoom = TransformationController();

  /// Already-cropped photo from an earlier edit (kept unless changed).
  late Uint8List? _photo = widget.photo;

  /// Freshly picked full photo the user is positioning; cropped on apply.
  Uint8List? _source;
  Size _srcSize = const Size(1, 1);

  @override
  void dispose() {
    _name.dispose();
    _focus.dispose();
    _zoom.dispose();
    super.dispose();
  }

  Future<Uint8List?> _crop() async {
    final box =
        _cropKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (box == null) return null;
    final image = await box.toImage(pixelRatio: 600 / _cropSize);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    return data?.buffer.asUint8List();
  }

  Future<void> _apply() async {
    var photo = _photo;
    if (_source != null) photo = await _crop() ?? _source;
    if (mounted) Navigator.pop(context, (name: _name.text.trim(), photo: photo));
  }

  Future<void> _pick() async {
    _focus.unfocus();
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 1400,
        maxHeight: 1400,
        imageQuality: 90,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      final img = await decodeImageFromList(bytes);
      final size = Size(img.width.toDouble(), img.height.toDouble());
      img.dispose();
      if (mounted) {
        setState(() {
          _source = bytes;
          _srcSize = size;
        });
        _setZoom(1);
      }
    } catch (_) {
      if (mounted) {
        toast(context, 'Could not open this photo. Please try another.');
      }
    }
  }

  void _setZoom(double s) {
    // Zoom around the centre of the circle.
    final child = _childSize;
    const c = _cropSize / 2;
    // Scene point currently under the circle centre stays centred.
    final inv = Matrix4.inverted(_zoom.value);
    final focus = MatrixUtils.transformPoint(inv, const Offset(c, c));
    final f = _zoom.value.getMaxScaleOnAxis() == 1 && s == 1
        ? Offset(child.width / 2, child.height / 2)
        : focus;
    var dx = c - f.dx * s, dy = c - f.dy * s;
    dx = dx.clamp(_cropSize - child.width * s, 0.0);
    dy = dy.clamp(_cropSize - child.height * s, 0.0);
    _zoom.value =
        Matrix4.identity()
          ..translateByDouble(dx, dy, 0, 1)
          ..scaleByDouble(s, s, 1, 1);
    setState(() {});
  }

  /// Photo laid out at its own shape, just covering the circle, so it can be
  /// dragged up/down (portrait) or left/right (landscape).
  Size get _childSize {
    final a = _srcSize.width / _srcSize.height;
    return a >= 1
        ? Size(_cropSize * a, _cropSize)
        : Size(_cropSize, _cropSize / a);
  }

  Widget _cropEditor(Uint8List src) => Column(
    children: [
      Center(
        child: Container(
          width: _cropSize + 8,
          height: _cropSize + 8,
          padding: const EdgeInsets.all(4),
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.gold,
          ),
          child: ClipOval(
            child: RepaintBoundary(
              key: _cropKey,
              child: SizedBox(
                width: _cropSize,
                height: _cropSize,
                child: InteractiveViewer(
                  transformationController: _zoom,
                  constrained: false,
                  minScale: 1,
                  maxScale: 5,
                  clipBehavior: Clip.hardEdge,
                  onInteractionEnd: (_) => setState(() {}),
                  child: Image.memory(
                    src,
                    width: _childSize.width,
                    height: _childSize.height,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      const SizedBox(height: 10),
      const Text(
        'Drag up, down or sideways · pinch or slide to resize',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 12, color: AppColors.muted),
      ),
      Row(
        children: [
          const Icon(Icons.photo_size_select_small, color: AppColors.muted),
          Expanded(
            child: Slider(
              min: 1,
              max: 5,
              value: _zoom.value.getMaxScaleOnAxis().clamp(1, 5),
              onChanged: _setZoom,
            ),
          ),
          const Icon(Icons.photo_size_select_large, color: AppColors.muted),
        ],
      ),
    ],
  );

  @override
  Widget build(BuildContext context) {
    final src = _source;
    final photo = _photo;
    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
          24,
          4,
          24,
          MediaQuery.viewInsetsOf(context).bottom + 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Make it yours',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _name,
              focusNode: _focus,
              autofocus: src == null,
              keyboardType: TextInputType.name,
              textInputAction: TextInputAction.done,
              textCapitalization: TextCapitalization.words,
              maxLength: 30,
              onTap: () => _focus.requestFocus(),
              onSubmitted: (_) => _apply(),
              scrollPadding: const EdgeInsets.all(32),
              decoration: const InputDecoration(
                labelText: 'Your name',
                hintText: 'e.g. Grace',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            if (src != null) ...[_cropEditor(src), const SizedBox(height: 8)],
            Row(
              children: [
                if (src == null && photo != null) ...[
                  ClipOval(
                    child: Image.memory(
                      photo,
                      width: 48,
                      height: 48,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 12),
                ],
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _pick,
                    icon: const Icon(Icons.add_a_photo_outlined, size: 18),
                    label: Text(
                      src == null && _photo == null
                          ? 'Add your photo'
                          : 'Change photo',
                    ),
                  ),
                ),
                if (src != null || _photo != null)
                  IconButton(
                    tooltip: 'Remove photo',
                    onPressed:
                        () => setState(() {
                          _photo = null;
                          _source = null;
                        }),
                    icon: const Icon(Icons.close_rounded),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _apply,
              child: const Text('Apply to blessing'),
            ),
          ],
        ),
      ),
    );
  }
}
