import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/legal/legal_catalog.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';

export '../../core/legal/legal_catalog.dart' show LegalKind;

class LegalScreen extends StatefulWidget {
  const LegalScreen({super.key, required this.kind});
  final LegalKind kind;
  @override
  State<LegalScreen> createState() => _LegalScreenState();
}

class _LegalScreenState extends State<LegalScreen> {
  late Future<Map<String, dynamic>> _content;
  @override
  void initState() {
    super.initState();
    _content = LegalCatalog.load();
  }

  Future<void> _contact() async {
    final opened = await launchUrl(
      Uri(
        scheme: 'mailto',
        path: 'pranacodes@gmail.com',
        queryParameters: {'subject': 'Aashray support'},
      ),
    );
    if (!opened && mounted) {
      await Clipboard.setData(
        const ClipboardData(text: 'pranacodes@gmail.com'),
      );
      if (mounted) toast(context, 'Support email copied');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(LegalCatalog.title(widget.kind))),
      body: ContentWidth(
        child: FutureBuilder<Map<String, dynamic>>(
          future: _content,
          builder: (context, snap) {
            if (snap.hasError) {
              return Center(
                child: TextButton.icon(
                  icon: const Icon(Icons.refresh),
                  label: const Text('Retry'),
                  onPressed:
                      () => setState(() => _content = LegalCatalog.load()),
                ),
              );
            }
            final catalog = snap.data;
            if (catalog == null)
              return const Center(child: CircularProgressIndicator());
            final documents =
                (catalog['documents'] as List).cast<Map<String, dynamic>>();
            final document = documents.firstWhere(
              (d) => d['id'] == widget.kind.name,
            );
            final sections =
                (document['sections'] as List).cast<Map<String, dynamic>>();
            return ListView(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 40),
              children: [
                Text(
                  document['summary'] as String,
                  style: const TextStyle(fontSize: 18, height: 1.5),
                ),
                const SizedBox(height: 10),
                Text(
                  'PranaCodes · Updated ${catalog['updated']}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12),
                ),
                const SizedBox(height: 20),
                for (final section in sections) ...[
                  const Divider(),
                  const SizedBox(height: 18),
                  Text(
                    section['title'] as String,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  SelectableText(
                    section['body'] as String,
                    style: const TextStyle(
                      fontSize: 14,
                      height: 1.7,
                      color: AppColors.inkSoft,
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
                TextButton.icon(
                  onPressed: _contact,
                  icon: const Icon(Icons.mail_outline),
                  label: const Text('Email PranaCodes'),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final kind in LegalKind.values)
                      if (kind != widget.kind)
                        TextButton(
                          onPressed:
                              () => Navigator.push(
                                context,
                                MaterialPageRoute<void>(
                                  builder: (_) => LegalScreen(kind: kind),
                                ),
                              ),
                          child: Text(LegalCatalog.title(kind)),
                        ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
