import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../../core/config.dart';
import '../../core/premium/plans.dart';
import '../../core/premium/premium_store.dart';
import '../../core/premium/cashfree_checkout.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import 'legal_screen.dart';

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key});
  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen>
    with WidgetsBindingObserver {
  VideoPlayerController? _video;
  bool _videoReady = false;
  Plan _plan = kYearlyPlan;
  bool _paying = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !MediaQuery.of(context).disableAnimations) _initVideo();
    });
  }

  Future<void> _initVideo() async {
    final c = VideoPlayerController.asset(
      'assets/paywall/father.mp4',
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );
    _video = c;
    try {
      await c.initialize();
      if (!mounted) return;
      await c.setVolume(0);
      await c.setLooping(true);
      await c.play();
      if (mounted) setState(() => _videoReady = true);
    } catch (_) {
      /* The bundled poster remains visible. */
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _videoReady) {
      _video?.play();
    } else {
      _video?.pause();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _video?.dispose();
    super.dispose();
  }

  Future<void> _pay() async {
    if (_paying) return;
    // TESTING ONLY: tap unlocks Premium until Cashfree is integrated.
    await PremiumStore.instance.grantTestDay();
    return;
    // ignore: dead_code
    setState(() => _paying = true);
    final result = await CashfreeCheckout.instance.pay(_plan);
    if (!mounted) return;
    setState(() => _paying = false);
    switch (result) {
      case CheckoutVerified(:final paymentId):
        await PremiumStore.instance.grant(_plan, paymentId: paymentId);
      case CheckoutFailed(:final message):
        toast(context, message, error: true);
      case CheckoutNotConfigured():
        toast(
          context,
          'Cashfree payments are being set up. No payment has been taken.',
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final video = _video;
    final top = MediaQuery.paddingOf(context).top;
    return Scaffold(
      body: ContentWidth(
        child: Column(
          children: [
            Expanded(
              child: CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(
                    child: SizedBox(
                      height: 252 + top,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.asset(
                            'assets/paywall/father_poster.jpg',
                            fit: BoxFit.cover,
                            alignment: const Alignment(0, -.6),
                          ),
                          if (_videoReady && video != null)
                            FittedBox(
                              fit: BoxFit.cover,
                              alignment: const Alignment(0, -.6),
                              clipBehavior: Clip.hardEdge,
                              child: SizedBox(
                                width: video.value.size.width,
                                height: video.value.size.height,
                                child: VideoPlayer(video),
                              ),
                            ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  AppColors.scrim.withValues(alpha: .18),
                                  AppColors.scrim.withValues(alpha: 0),
                                  AppColors.scrim.withValues(alpha: .7),
                                ],
                                stops: const [0, .45, 1],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 24,
                            right: 24,
                            bottom: 20,
                            child: const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Faith. Every day.',
                                  style: TextStyle(
                                    fontFamily: AppTheme.serif,
                                    fontSize: 29,
                                    height: 1.2,
                                    color: AppColors.imageInk,
                                  ),
                                ),
                                SizedBox(height: 8),
                                Text(
                                  'A little closer to Him.',
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: AppColors.imageSoft,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: top + 20,
                            left: 24,
                            right: 24,
                            child: Row(
                              children: [
                                Image.asset(
                                  'assets/images/app_icon.png',
                                  width: 32,
                                  height: 32,
                                ),
                                const SizedBox(width: 10),
                                const Text(
                                  'Aashray',
                                  style: TextStyle(
                                    fontFamily: AppTheme.serif,
                                    fontSize: 23,
                                    color: AppColors.imageInk,
                                  ),
                                ),
                                const Spacer(),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppColors.paper.withValues(
                                      alpha: .9,
                                    ),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: const Text(
                                    'PREMIUM',
                                    style: TextStyle(
                                      color: AppColors.primary,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                    sliver: SliverList.list(
                      children: [
                        const Text(
                          'Welcome to Aashray',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'The Word. His peace. Your daily blessings.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppColors.muted,
                            fontSize: 12,
                            height: 1.65,
                          ),
                        ),
                        const SizedBox(height: 18),
                        const Row(
                          children: [
                            _Benefit(Icons.menu_book_outlined, 'Holy Bible'),
                            _Benefit(Icons.wallpaper_outlined, 'Wallpapers'),
                            _Benefit(Icons.headphones_outlined, 'Hindi audio'),
                            _Benefit(Icons.ios_share_outlined, 'Blessings'),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                          decoration: BoxDecoration(
                            color: AppColors.paper,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: AppColors.primary, width: 1.6),
                          ),
                          child: const Column(
                            children: [
                              Text('₹2 Trial',
                                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        Wrap(
                          alignment: WrapAlignment.center,
                          children: [
                            TextButton(
                              onPressed:
                                  () => Navigator.push(
                                    context,
                                    MaterialPageRoute<void>(
                                      builder:
                                          (_) => const LegalScreen(
                                            kind: LegalKind.terms,
                                          ),
                                    ),
                                  ),
                              child: const Text(
                                'Terms',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: AppColors.muted,
                                ),
                              ),
                            ),
                            const Text(
                              '·',
                              style: TextStyle(color: AppColors.muted),
                            ),
                            TextButton(
                              onPressed:
                                  () => Navigator.push(
                                    context,
                                    MaterialPageRoute<void>(
                                      builder:
                                          (_) => const LegalScreen(
                                            kind: LegalKind.privacy,
                                          ),
                                    ),
                                  ),
                              child: const Text(
                                'Privacy',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: AppColors.muted,
                                ),
                              ),
                            ),
                            for (final entry in const [
                              (LegalKind.refunds, 'Refunds'),
                              (LegalKind.contact, 'Help'),
                            ])
                              TextButton(
                                onPressed:
                                    () => Navigator.push(
                                      context,
                                      MaterialPageRoute<void>(
                                        builder:
                                            (_) => LegalScreen(kind: entry.$1),
                                      ),
                                    ),
                                child: Text(
                                  entry.$2,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: AppColors.muted,
                                  ),
                                ),
                              ),
                            if (AppConfig.allowTestUnlock)
                              TextButton(
                                onPressed:
                                    () => PremiumStore.instance.grantTestDay(),
                                child: const Text(
                                  'Preview app',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: AppColors.primary,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(
                24,
                14,
                24,
                MediaQuery.paddingOf(context).bottom + 16,
              ),
              decoration: const BoxDecoration(
                color: AppColors.paper,
                border: Border(top: BorderSide(color: AppColors.line)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton(
                      onPressed: _paying ? null : _pay,
                      child:
                          _paying
                              ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  color: AppColors.onPrimary,
                                  strokeWidth: 2,
                                ),
                              )
                              : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Start ₹2 trial',
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  const Icon(
                                    Icons.arrow_forward_rounded,
                                    size: 19,
                                  ),
                                ],
                              ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.lock_outline_rounded,
                        size: 12,
                        color: AppColors.muted,
                      ),
                      SizedBox(width: 5),
                      Text(
                        'Secure UPI via Cashfree · Ad-free',
                        style: TextStyle(fontSize: 10, color: AppColors.muted),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Benefit extends StatelessWidget {
  const _Benefit(this.icon, this.label);
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Expanded(
    child: Column(
      children: [
        Icon(icon, color: AppColors.gold, size: 23),
        const SizedBox(height: 9),
        Text(
          label,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 11,
            color: AppColors.inkSoft,
            height: 1.4,
          ),
        ),
      ],
    ),
  );
}

class _PlanOption extends StatelessWidget {
  const _PlanOption({
    required this.plan,
    required this.selected,
    required this.caption,
    required this.onTap,
    this.badge,
  });
  final Plan plan;
  final bool selected;
  final String caption;
  final VoidCallback onTap;
  final String? badge;
  @override
  Widget build(BuildContext context) {
    final tag = badge;
    return Material(
      color: selected ? AppColors.accentSoft : AppColors.paper,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: selected ? AppColors.accent : AppColors.line,
            ),
          ),
          child: Row(
            children: [
              Icon(
                selected ? Icons.radio_button_checked : Icons.radio_button_off,
                color: selected ? AppColors.accent : AppColors.muted,
                size: 21,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          plan.title,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        if (tag != null) ...[
                          const SizedBox(width: 8),
                          Text(
                            tag,
                            style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              color: AppColors.gold,
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      caption,
                      style: const TextStyle(
                        fontSize: 11,
                        color: AppColors.muted,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                '₹${plan.priceInr}',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
