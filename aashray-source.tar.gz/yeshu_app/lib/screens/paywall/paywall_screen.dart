import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import '../../core/config.dart';
import '../../core/meta/meta_events.dart';
import '../../core/premium/premium_store.dart';
import '../../core/premium/subscription_rules.dart';
import '../../core/premium/subscription_service.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import 'legal_screen.dart';

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key});
  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen> with WidgetsBindingObserver {
  VideoPlayerController? _video;
  String? _poster;
  bool _ready = false;
  bool _muted = true;
  bool _paying = false;
  bool _resumePlayback = true;
  String? _paymentError;
  static const _mediaOrigin = 'https://velora-wallpaper-gallery.lovable.app';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    MetaEvents.paywallView();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _initVideo();
    });
  }

  Future<void> _initVideo() async {
    try {
      final poster = jsonDecode(await rootBundle.loadString('assets/media/faith-showcase.jpg.asset.json')) as Map<String, dynamic>;
      final asset = jsonDecode(await rootBundle.loadString('assets/media/faith-showcase.mp4.asset.json')) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() => _poster = '$_mediaOrigin${poster['url']}');
      if (MediaQuery.of(context).disableAnimations) return;
      final c = VideoPlayerController.networkUrl(Uri.parse('$_mediaOrigin${asset['url']}'),
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true));
      _video = c;
      await c.initialize();
      if (!mounted) return;
      await c.setVolume(0);
      await c.setLooping(true);
      await c.play();
      if (mounted) setState(() => _ready = true);
    } catch (_) {
      // Keep the poster and checkout available if streaming is unavailable.
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _video;
    if (c == null) return;
    if (state == AppLifecycleState.resumed && _resumePlayback && _ready) {
      c.play();
    } else {
      if (state == AppLifecycleState.inactive) _resumePlayback = c.value.isPlaying;
      c.pause();
    }
  }

  Future<void> _toggleSound() async {
    final c = _video;
    if (c == null || !_ready) return;
    await c.setVolume(_muted ? 1 : 0);
    if (!c.value.isPlaying) await c.play();
    if (mounted) setState(() => _muted = !_muted);
  }

  Future<void> _pay() async {
    if (_paying) return;
    setState(() => _paying = true);
    final result = await SubscriptionService.instance.startTrial();
    if (!mounted) return;
    setState(() => _paying = false);
    if (result is SubFailed) {
      _paymentError = result.message;
      setState(() {});
    }
  }

  Future<void> _testUnlock() async {
    await PremiumStore.instance.grantTestDay();
  }

  Future<void> _legal(LegalKind kind) async {
    final c = _video;
    final wasPlaying = c?.value.isPlaying ?? false;
    await c?.pause();
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: kind)));
    if (mounted && wasPlaying) await c?.play();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _video?.dispose();
    super.dispose();
  }

  Widget _miniButton({required IconData icon, required String tooltip, VoidCallback? onTap}) => Material(
    color: AppColors.scrim.withValues(alpha: .42),
    shape: const CircleBorder(),
    child: InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: Tooltip(message: tooltip, child: SizedBox(width: 32, height: 32,
        child: Icon(icon, size: 16, color: AppColors.imageInk))),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.sizeOf(context).height;
    final videoH = (h * .40).clamp(220.0, 400.0);
    final v = _video;
    return Scaffold(
      body: SafeArea(
        child: ContentWidth(
          child: Column(children: [
            Expanded(child: ListView(
              padding: const EdgeInsets.fromLTRB(22, 10, 22, 12),
              children: [
                Row(children: [
                  Image.asset('assets/branding/aashray-logo.png', width: 22, height: 27),
                  const SizedBox(width: 9),
                  const Text('Aashray', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.2)),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(color: AppColors.goldSoft, borderRadius: BorderRadius.circular(20)),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.workspace_premium_rounded, size: 14, color: AppColors.gold),
                      SizedBox(width: 4),
                      Text('PREMIUM', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: 1, color: AppColors.gold)),
                    ]),
                  ),
                ]),
                const SizedBox(height: 16),
                Center(child: Container(
                  height: videoH,
                  width: videoH * 9 / 16,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: AppColors.gold.withValues(alpha: .35), width: 1.2),
                    boxShadow: const [BoxShadow(color: AppColors.shadow, blurRadius: 28, offset: Offset(0, 12))],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(21),
                    child: Stack(fit: StackFit.expand, children: [
                      const ColoredBox(color: AppColors.paperDeep),
                      if (_poster != null) Image.network(_poster ?? '', fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => Image.asset('assets/paywall/father_poster.jpg', fit: BoxFit.cover))
                      else Image.asset('assets/paywall/father_poster.jpg', fit: BoxFit.cover),
                      if (_ready && v != null) FittedBox(fit: BoxFit.cover, child: SizedBox(
                        width: v.value.size.width, height: v.value.size.height, child: VideoPlayer(v))),
                      if (_ready && v != null) Positioned(left: 8, bottom: 8,
                        child: ValueListenableBuilder<VideoPlayerValue>(
                          valueListenable: v,
                          builder: (context, value, _) => _miniButton(
                            icon: value.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                            tooltip: value.isPlaying ? 'Pause video' : 'Play video',
                            onTap: () {
                              _resumePlayback = !value.isPlaying;
                              value.isPlaying ? v.pause() : v.play();
                            },
                          ),
                        )),
                      Positioned(right: 8, bottom: 8, child: _miniButton(
                        icon: _muted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                        tooltip: _muted ? 'Listen to the message' : 'Mute video',
                        onTap: _ready ? _toggleSound : null,
                      )),
                    ]),
                  ),
                )),
                const SizedBox(height: 20),
                const Text('A little closer to Him,\nevery day.', textAlign: TextAlign.center,
                  style: TextStyle(fontFamily: AppTheme.serif, fontSize: 24, height: 1.25, color: AppColors.ink)),
                const SizedBox(height: 6),
                const Text('A new verse each morning. His peace each night.', textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.5)),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
                  decoration: BoxDecoration(
                    color: AppColors.paper,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.line),
                  ),
                  child: const Column(children: [
                    _Benefit(Icons.wallpaper_rounded, 'Daily verse wallpaper', 'Changes on its own every morning'),
                    _Benefit(Icons.headphones_rounded, 'Prayers & night stories', 'Prabhu ki gathayein for peaceful sleep'),
                    _Benefit(Icons.menu_book_rounded, 'Holy Bible, beautifully readable', 'Scroll mode or real book pages'),
                    _Benefit(Icons.ios_share_rounded, 'Status & ringtones', 'With your name and photo'),
                  ]),
                ),
                const SizedBox(height: 8),
                Wrap(alignment: WrapAlignment.center, children: [
                  for (final entry in const [(LegalKind.terms, 'Terms'), (LegalKind.privacy, 'Privacy'), (LegalKind.refunds, 'Refunds'), (LegalKind.contact, 'Help')])
                    TextButton(
                      style: TextButton.styleFrom(minimumSize: const Size(0, 32), padding: const EdgeInsets.symmetric(horizontal: 8)),
                      onPressed: () => _legal(entry.$1),
                      child: Text(entry.$2, style: const TextStyle(fontSize: 11, color: AppColors.muted))),
                ]),
              ],
            )),
            Container(
              padding: const EdgeInsets.fromLTRB(22, 12, 22, 8),
              decoration: const BoxDecoration(
                color: AppColors.paper,
                border: Border(top: BorderSide(color: AppColors.line)),
              ),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                if (_paymentError != null) Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(_paymentError ?? '', textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 11.5, color: AppColors.danger, height: 1.4)),
                ),
                SizedBox(width: double.infinity, height: 52, child: FilledButton(
                  style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                  onPressed: _paying ? null : _pay,
                  child: _paying
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: AppColors.onPrimary, strokeWidth: 2))
                    : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text('Start ₹2 trial', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                      SizedBox(width: 10), Icon(Icons.arrow_forward_rounded, size: 19),
                    ]),
                )),
                const SizedBox(height: 8),
                const Text('₹$kTrialAmountInr for $kTrialDays day, then ₹$kMonthlyInr/month via UPI AutoPay. Cancel anytime in your UPI app.',
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 10.5, color: AppColors.muted, height: 1.4)),
                if (AppConfig.allowTestUnlock) TextButton(
                  style: TextButton.styleFrom(minimumSize: const Size(0, 30)),
                  onPressed: _testUnlock,
                  child: const Text('Test unlock (internal build)', style: TextStyle(fontSize: 11, color: AppColors.muted))),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Benefit extends StatelessWidget {
  const _Benefit(this.icon, this.title, this.sub);
  final IconData icon;
  final String title;
  final String sub;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Row(children: [
      Container(
        width: 34, height: 34,
        decoration: BoxDecoration(color: AppColors.goldSoft, borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, size: 18, color: AppColors.gold),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.ink)),
        const SizedBox(height: 1),
        Text(sub, style: const TextStyle(fontSize: 11.5, color: AppColors.muted, height: 1.3)),
      ])),
      const Icon(Icons.check_circle_rounded, size: 17, color: AppColors.green),
    ]),
  );
}
