import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import '../../core/config.dart';
import '../../core/meta/meta_events.dart';
import '../../core/premium/premium_store.dart';
import '../../core/remote_config.dart';
import '../../core/premium/subscription_service.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import 'legal_screen.dart';

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key, this.onSkip});
  /// Shown as "Skip" on the root paywall when the server allows it.
  final VoidCallback? onSkip;
  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen> with WidgetsBindingObserver {
  VideoPlayerController? _video;
  String? _poster;
  bool _ready = false;
  bool _muted = false;
  bool _paying = false;
  bool _resumePlayback = true;
  String? _paymentError;
  bool _controls = true;
  Timer? _hideTimer;
  List<UpiApp> _apps = const [];
  UpiApp? _app;
  static const _mediaOrigin = 'https://velora-wallpaper-gallery.lovable.app';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    MetaEvents.paywallView();
    PremiumStore.instance.addListener(_onPremium);
    RemoteConfig.instance.addListener(_onConfig);
    _loadApps();
    _scheduleHide();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _initVideo();
    });
  }

  Future<void> _initVideo() async {
    try {
      final poster = jsonDecode(await rootBundle.loadString('assets/media/faith-showcase.jpg.asset.json')) as Map<String, dynamic>;
      final asset = jsonDecode(await rootBundle.loadString('assets/media/faith-showcase.mp4.asset.json')) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() => _poster = '$_mediaOrigin${poster['url']}');
      if (MediaQuery.of(context).disableAnimations || !RemoteConfig.instance.showVideo) return;
      final c = VideoPlayerController.networkUrl(Uri.parse('$_mediaOrigin${asset['url']}'),
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: false));
      _video = c;
      await c.initialize();
      if (!mounted) return;
      // Father's message plays with sound by default; user can mute.
      await c.setVolume(1);
      await c.setLooping(true);
      await c.play();
      if (mounted) setState(() => _ready = true);
    } catch (_) {
      // Keep the poster and checkout available if streaming is unavailable.
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _video;
    if (c == null) return;
    if (state == AppLifecycleState.resumed && _resumePlayback && _ready) {
      c.play();
    } else {
      if (state == AppLifecycleState.inactive) _resumePlayback = c.value.isPlaying;
      c.pause();
    }
  }

  Future<void> _toggleSound() async {
    final c = _video;
    if (c == null || !_ready) return;
    await c.setVolume(_muted ? 1 : 0);
    if (!c.value.isPlaying) await c.play();
    if (mounted) setState(() => _muted = !_muted);
  }

  Future<void> _loadApps() async {
    final apps = await SubscriptionService.instance.upiApps();
    if (!mounted || apps.isEmpty) return;
    final saved = SubscriptionService.instance.savedUpiPackage;
    const preferred = ['com.phonepe.app', 'com.google.android.apps.nbu.paisa.user', 'net.one97.paytm'];
    UpiApp pick = apps.first;
    for (final a in apps) { if (a.package == saved) { pick = a; break; } }
    if (saved == null) {
      for (final pkg in preferred) {
        final m = apps.where((a) => a.package == pkg);
        if (m.isNotEmpty) { pick = m.first; break; }
      }
    }
    setState(() { _apps = apps; _app = pick; });
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(milliseconds: 1800), () {
      if (mounted) setState(() => _controls = false);
    });
  }

  void _showControls() {
    setState(() => _controls = true);
    _scheduleHide();
  }

  Future<void> _switchApp() async {
    final picked = await showModalBottomSheet<UpiApp>(
      context: context,
      showDragHandle: true,
      backgroundColor: AppColors.paper,
      builder: (ctx) => SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(padding: EdgeInsets.fromLTRB(4, 0, 4, 10),
            child: Text('Pay with', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
          for (final a in _apps) ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: _UpiIcon(a),
            title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w600)),
            trailing: a.package == _app?.package ? const Icon(Icons.check_circle_rounded, color: AppColors.green) : null,
            onTap: () => Navigator.pop(ctx, a),
          ),
        ]),
      )),
    );
    if (picked == null || !mounted) return;
    await SubscriptionService.instance.saveUpiPackage(picked.package);
    setState(() => _app = picked);
  }

  Future<void> _pay() async {
    if (_paying) return;
    setState(() { _paying = true; _paymentError = null; });
    final result = await SubscriptionService.instance.startTrial(upiPackage: _app?.package);
    if (!mounted) return;
    setState(() => _paying = false);
    if (result is SubFailed) {
      _paymentError = result.message;
      setState(() {});
    }
  }

  Future<void> _testUnlock() async {
    await PremiumStore.instance.grantTestDay();
  }

  Future<void> _legal(LegalKind kind) async {
    final c = _video;
    final wasPlaying = c?.value.isPlaying ?? false;
    await c?.pause();
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: kind)));
    if (mounted && wasPlaying) await c?.play();
  }

  void _onConfig() { if (mounted) setState(() {}); }

  // A pushed paywall closes itself once Premium unlocks.
  void _onPremium() {
    if (!mounted || !PremiumStore.instance.isActive) return;
    final nav = Navigator.of(context);
    if (ModalRoute.of(context)?.isCurrent == true && nav.canPop()) nav.pop();
  }

  @override
  void dispose() {
    PremiumStore.instance.removeListener(_onPremium);
    RemoteConfig.instance.removeListener(_onConfig);
    WidgetsBinding.instance.removeObserver(this);
    _hideTimer?.cancel();
    _video?.dispose();
    super.dispose();
  }

  Widget _miniButton({required IconData icon, required String tooltip, VoidCallback? onTap}) => Material(
    color: AppColors.scrim.withValues(alpha: .38),
    shape: const CircleBorder(),
    child: InkWell(
      customBorder: const CircleBorder(),
      onTap: () { onTap?.call(); _scheduleHide(); },
      child: Tooltip(message: tooltip, child: SizedBox(width: 28, height: 28,
        child: Icon(icon, size: 14, color: AppColors.imageInk))),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.sizeOf(context).height;
    final videoH = (h * .40).clamp(220.0, 400.0);
    final v = _video;
    final cfg = RemoteConfig.instance;
    final primary = cfg.primaryColor;
    return Scaffold(
      body: SafeArea(
        child: ContentWidth(
          child: Column(children: [
            Expanded(child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
              children: [
                Row(children: [
                  Image.asset('assets/branding/aashray-logo.png', width: 20, height: 25),
                  const SizedBox(width: 8),
                  const Text('Aashray', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, letterSpacing: -.2)),
                  const Spacer(),
                  if (Navigator.of(context).canPop())
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      tooltip: 'Close',
                      onPressed: () => Navigator.of(context).maybePop(),
                      icon: const Icon(Icons.close_rounded, size: 22, color: AppColors.muted))
                  else if (widget.onSkip != null)
                    TextButton(
                      style: TextButton.styleFrom(minimumSize: const Size(0, 32), padding: const EdgeInsets.symmetric(horizontal: 10)),
                      onPressed: _paying ? null : widget.onSkip,
                      child: Text(cfg.skipLabel, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.muted)))
                  else Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(color: AppColors.goldSoft, borderRadius: BorderRadius.circular(20)),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.workspace_premium_rounded, size: 13, color: AppColors.gold),
                      SizedBox(width: 4),
                      Text('PREMIUM', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, color: AppColors.gold)),
                    ]),
                  ),
                ]),
                const SizedBox(height: 12),
                Center(child: GestureDetector(
                  onTap: _showControls,
                  child: Container(
                    height: videoH,
                    width: videoH * 9 / 16,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.gold.withValues(alpha: .35), width: 1.2),
                      boxShadow: const [BoxShadow(color: AppColors.shadow, blurRadius: 24, offset: Offset(0, 10))],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(19),
                      child: Stack(fit: StackFit.expand, children: [
                        const ColoredBox(color: AppColors.paperDeep),
                        if (_poster != null) Image.network(_poster ?? '', fit: BoxFit.cover,
                          errorBuilder: (_, _, _) => Image.asset('assets/paywall/father_poster.jpg', fit: BoxFit.cover))
                        else Image.asset('assets/paywall/father_poster.jpg', fit: BoxFit.cover),
                        if (_ready && v != null) FittedBox(fit: BoxFit.cover, child: SizedBox(
                          width: v.value.size.width, height: v.value.size.height, child: VideoPlayer(v))),
                        Positioned(left: 7, right: 7, bottom: 7, child: IgnorePointer(
                          ignoring: !_controls,
                          child: AnimatedOpacity(
                            opacity: _controls ? 1 : 0,
                            duration: const Duration(milliseconds: 250),
                            child: Row(children: [
                              if (_ready && v != null) ValueListenableBuilder<VideoPlayerValue>(
                                valueListenable: v,
                                builder: (context, value, _) => _miniButton(
                                  icon: value.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                  tooltip: value.isPlaying ? 'Pause video' : 'Play video',
                                  onTap: () {
                                    _resumePlayback = !value.isPlaying;
                                    value.isPlaying ? v.pause() : v.play();
                                  },
                                ),
                              ),
                              const Spacer(),
                              _miniButton(
                                icon: _muted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                                tooltip: _muted ? 'Listen to the message' : 'Mute video',
                                onTap: _ready ? _toggleSound : null,
                              ),
                            ]),
                          ),
                        )),
                      ]),
                    ),
                  ),
                )),
                const SizedBox(height: 14),
                Text(cfg.headline, textAlign: TextAlign.center,
                  style: const TextStyle(fontFamily: AppTheme.serif, fontSize: 21, height: 1.25, color: AppColors.ink)),
                const SizedBox(height: 14),
                const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _Benefit(Icons.menu_book_rounded, 'Bible'),
                  _Benefit(Icons.wallpaper_rounded, 'Wallpaper'),
                  _Benefit(Icons.headphones_rounded, 'Prayers'),
                  _Benefit(Icons.ios_share_rounded, 'Status'),
                  _Benefit(Icons.music_note_rounded, 'Ringtone'),
                ]),
                const SizedBox(height: 4),
                Wrap(alignment: WrapAlignment.center, children: [
                  for (final entry in const [(LegalKind.terms, 'Terms'), (LegalKind.privacy, 'Privacy'), (LegalKind.refunds, 'Refunds'), (LegalKind.contact, 'Help')])
                    TextButton(
                      style: TextButton.styleFrom(minimumSize: const Size(0, 30), padding: const EdgeInsets.symmetric(horizontal: 8)),
                      onPressed: () => _legal(entry.$1),
                      child: Text(entry.$2, style: const TextStyle(fontSize: 11, color: AppColors.muted))),
                ]),
              ],
            )),
            Container(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 8),
              decoration: const BoxDecoration(
                color: AppColors.paper,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                boxShadow: [BoxShadow(color: AppColors.shadow, blurRadius: 18, offset: Offset(0, -4))],
              ),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                if (_app != null) Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(children: [
                    _UpiIcon(_app as UpiApp),
                    const SizedBox(width: 10),
                    Expanded(child: Text(_app?.name ?? '', maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700))),
                    if (_apps.length > 1) TextButton(
                      style: TextButton.styleFrom(minimumSize: const Size(0, 32), padding: const EdgeInsets.symmetric(horizontal: 6)),
                      onPressed: _paying ? null : _switchApp,
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Text('Switch', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                        Icon(Icons.keyboard_arrow_down_rounded, size: 18, color: AppColors.gold),
                      ]),
                    ),
                  ]),
                ),
                if (_paymentError != null) Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(_paymentError ?? '', textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 11.5, color: AppColors.danger, height: 1.35)),
                ),
                SizedBox(width: double.infinity, height: 50, child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                  onPressed: _paying ? null : _pay,
                  child: _paying
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: AppColors.onPrimary, strokeWidth: 2))
                    : Text(cfg.cta, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                )),
                const SizedBox(height: 6),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.lock_rounded, size: 11, color: AppColors.muted),
                  const SizedBox(width: 4),
                  Flexible(child: Text(cfg.finePrint,
                    textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, color: AppColors.muted, height: 1.3))),
                ]),
                if (AppConfig.allowTestUnlock) TextButton(
                  style: TextButton.styleFrom(minimumSize: const Size(0, 28)),
                  onPressed: _testUnlock,
                  child: const Text('Test unlock (internal build)', style: TextStyle(fontSize: 11, color: AppColors.muted))),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _UpiIcon extends StatelessWidget {
  const _UpiIcon(this.app);
  final UpiApp app;
  @override
  Widget build(BuildContext context) {
    final icon = app.icon;
    return Container(
      width: 34, height: 34,
      decoration: BoxDecoration(
        color: AppColors.paper,
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: AppColors.line),
      ),
      clipBehavior: Clip.antiAlias,
      padding: const EdgeInsets.all(3),
      child: icon != null
        ? Image.memory(icon, fit: BoxFit.contain, gaplessPlayback: true)
        : const Icon(Icons.account_balance_wallet_rounded, size: 18, color: AppColors.accent),
    );
  }
}

class _Benefit extends StatelessWidget {
  const _Benefit(this.icon, this.title);
  final IconData icon;
  final String title;
  @override
  Widget build(BuildContext context) => Column(mainAxisSize: MainAxisSize.min, children: [
    Container(
      width: 46, height: 46,
      decoration: BoxDecoration(
        color: AppColors.goldSoft,
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.gold.withValues(alpha: .35)),
      ),
      child: Icon(icon, size: 21, color: AppColors.gold),
    ),
    const SizedBox(height: 6),
    Text(title, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.ink)),
  ]);
}
