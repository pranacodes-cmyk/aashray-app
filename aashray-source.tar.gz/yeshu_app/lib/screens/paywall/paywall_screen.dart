import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import '../../core/config.dart';
import '../../core/meta/meta_events.dart';
import '../../core/premium/premium_store.dart';
import '../../core/premium/subscription_rules.dart';
import '../../core/premium/subscription_service.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import 'legal_screen.dart';

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key});
  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen> with WidgetsBindingObserver {
  VideoPlayerController? _video;
  String? _poster;
  bool _ready = false;
  bool _muted = true;
  bool _paying = false;
  bool _resumePlayback = true;
  String? _paymentError;
  static const _mediaOrigin = 'https://velora-wallpaper-gallery.lovable.app';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    MetaEvents.paywallView();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _initVideo();
    });
  }

  Future<void> _initVideo() async {
    try {
      final poster = jsonDecode(await rootBundle.loadString('assets/media/faith-showcase.jpg.asset.json')) as Map<String, dynamic>;
      final asset = jsonDecode(await rootBundle.loadString('assets/media/faith-showcase.mp4.asset.json')) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() => _poster = '$_mediaOrigin${poster['url']}');
      if (MediaQuery.of(context).disableAnimations) return;
      final c = VideoPlayerController.networkUrl(Uri.parse('$_mediaOrigin${asset['url']}'),
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true));
      _video = c;
      await c.initialize();
      if (!mounted) return;
      await c.setVolume(0);
      await c.setLooping(true);
      await c.play();
      if (mounted) setState(() => _ready = true);
    } catch (_) {
      // Keep the poster and checkout available if streaming is unavailable.
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = _video;
    if (c == null) return;
    if (state == AppLifecycleState.resumed && _resumePlayback && _ready) {
      c.play();
    } else {
      if (state == AppLifecycleState.inactive) _resumePlayback = c.value.isPlaying;
      c.pause();
    }
  }

  Future<void> _toggleSound() async {
    final c = _video;
    if (c == null || !_ready) return;
    await c.setVolume(_muted ? 1 : 0);
    if (!c.value.isPlaying) await c.play();
    if (mounted) setState(() => _muted = !_muted);
  }

  Future<void> _pay() async {
    if (_paying) return;
    setState(() => _paying = true);
    final result = await SubscriptionService.instance.startTrial();
    if (!mounted) return;
    setState(() => _paying = false);
    if (result is SubFailed) {
      _paymentError = result.message;
      setState(() {});
    }
  }

  Future<void> _testUnlock() async {
    await PremiumStore.instance.grantTestDay();
  }

  Future<void> _legal(LegalKind kind) async {
    final c = _video;
    final wasPlaying = c?.value.isPlaying ?? false;
    await c?.pause();
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: kind)));
    if (mounted && wasPlaying) await c?.play();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _video?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: ContentWidth(
        child: Column(children: [
          Expanded(child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
            children: [
              Row(children: [
                Image.asset('assets/branding/aashray-logo.png', width: 25, height: 31),
                const SizedBox(width: 10),
                const Text('Aashray', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
                const Spacer(),
                const Icon(Icons.auto_awesome_outlined, size: 18, color: AppColors.gold),
              ]),
              const SizedBox(height: 18),
              Center(child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: 320, maxHeight: (MediaQuery.sizeOf(context).height * .53).clamp(250, 540).toDouble()),
                child: AspectRatio(aspectRatio: 9 / 16, child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Stack(fit: StackFit.expand, children: [
                    const ColoredBox(color: AppColors.paperDeep),
                    if (_poster != null) Image.network(_poster ?? '', fit: BoxFit.contain,
                      errorBuilder: (_, _, _) => Image.asset('assets/paywall/father_poster.jpg', fit: BoxFit.contain))
                    else Image.asset('assets/paywall/father_poster.jpg', fit: BoxFit.contain),
                    if (_ready && _video != null) Center(child: AspectRatio(
                      aspectRatio: _video?.value.aspectRatio ?? 9 / 16,
                      child: VideoPlayer(_video as VideoPlayerController),
                    )),
                    Positioned(right: 8, bottom: 8, child: Material(
                      color: AppColors.paper,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: _muted ? 'Listen to the message' : 'Mute video',
                        onPressed: _ready ? _toggleSound : null,
                        icon: Icon(_muted ? Icons.volume_off_outlined : Icons.volume_up_outlined, color: AppColors.accent),
                      ),
                    )),
                    if (_ready && _video != null) Positioned(left: 8, bottom: 8,
                      child: ValueListenableBuilder<VideoPlayerValue>(
                        valueListenable: _video as VideoPlayerController,
                        builder: (context, value, _) => Material(
                          color: AppColors.paper,
                          shape: const CircleBorder(),
                          child: IconButton(
                            tooltip: value.isPlaying ? 'Pause video' : 'Play video',
                            onPressed: () {
                              final c = _video;
                              if (c == null) return;
                              _resumePlayback = !value.isPlaying;
                              value.isPlaying ? c.pause() : c.play();
                            },
                            icon: Icon(value.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, color: AppColors.accent),
                          ),
                        ),
                      ),
                    ),
                  ]),
                )),
              )),
              const SizedBox(height: 20),
              const Text('A little closer to Him.', textAlign: TextAlign.center,
                style: TextStyle(fontFamily: AppTheme.serif, fontSize: 23, height: 1.3)),
              const SizedBox(height: 8),
              const Text('A new verse each morning. His peace each night.', textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.5)),
              const SizedBox(height: 22),
              const Row(children: [
                _Benefit(Icons.menu_book_outlined, 'Bible'),
                _Benefit(Icons.wallpaper_outlined, 'Daily verse'),
                _Benefit(Icons.headphones_outlined, 'Prayer & stories'),
                _Benefit(Icons.ios_share_outlined, 'Status'),
              ]),
              const SizedBox(height: 12),
              Wrap(alignment: WrapAlignment.center, children: [
                for (final entry in const [(LegalKind.terms, 'Terms'), (LegalKind.privacy, 'Privacy'), (LegalKind.refunds, 'Refunds'), (LegalKind.contact, 'Help')])
                  TextButton(onPressed: () => _legal(entry.$1), child: Text(entry.$2, style: const TextStyle(fontSize: 11, color: AppColors.muted))),
              ]),
            ],
          )),
          Container(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
            decoration: const BoxDecoration(color: AppColors.paper, border: Border(top: BorderSide(color: AppColors.line))),
            child: SizedBox(width: double.infinity, height: 54, child: FilledButton(
              onPressed: _paying ? null : _pay,
              child: _paying
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: AppColors.onPrimary, strokeWidth: 2))
                : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('Start ₹2 trial', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  SizedBox(width: 12), Icon(Icons.arrow_forward_rounded, size: 20),
                ]),
            )),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
            child: Column(children: [
              if (_paymentError != null) Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(_paymentError ?? '', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5, color: AppColors.accent, height: 1.4)),
              ),
              const Text('₹$kTrialAmountInr for $kTrialDays days, then ₹$kMonthlyInr/month via UPI AutoPay. Cancel anytime in your UPI app.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 10.5, color: AppColors.muted, height: 1.4)),
              if (AppConfig.allowTestUnlock) TextButton(onPressed: _testUnlock,
                child: const Text('Test unlock (internal build)', style: TextStyle(fontSize: 11, color: AppColors.muted))),
            ]),
          ),
        ]),
      ),
    ),
  );
}

class _Benefit extends StatelessWidget {
  const _Benefit(this.icon, this.label);
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Expanded(child: Column(children: [
    Icon(icon, color: AppColors.gold, size: 23),
    const SizedBox(height: 8),
    Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: AppColors.inkSoft, height: 1.4)),
  ]));
}
