import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../../widgets/personalize_sheet.dart';
import '../../core/data/catalog.dart';
import '../../core/data/status_templates.dart';
import '../../core/status_export.dart';
import '../../core/theme.dart';
import '../daily/daily_verse_art.dart';
import '../../widgets/common.dart';
import 'status_card.dart';

class StatusViewer extends StatefulWidget {
  const StatusViewer({
    super.key,
    required this.category,
    required this.categoryIndex,
    required this.initial,
  }) : templates = null,
       singleText = null,
       singleReference = null,
       singleGreeting = null,
       dailyDate = null;
  const StatusViewer.featured({
    super.key,
    required this.templates,
    required this.initial,
  }) : category = null,
       categoryIndex = 0,
       singleText = null,
       singleReference = null,
       singleGreeting = null,
       dailyDate = null;
  const StatusViewer.single({
    super.key,
    required String text,
    required String reference,
    required String greeting,
  }) : category = null,
       categoryIndex = 0,
       initial = 0,
       templates = null,
       singleText = text,
       singleReference = reference,
       singleGreeting = greeting,
       dailyDate = null;
  const StatusViewer.daily({super.key, required DateTime date})
    : dailyDate = date,
      category = null,
      categoryIndex = 0,
      initial = 0,
      templates = null,
      singleText = null,
      singleReference = null,
      singleGreeting = null;
  final StatusCategory? category;
  final int categoryIndex;
  final int initial;
  final List<StatusTemplate>? templates;
  final String? singleText, singleReference, singleGreeting;
  final DateTime? dailyDate;
  @override
  State<StatusViewer> createState() => _StatusViewerState();
}

class _StatusViewerState extends State<StatusViewer> {
  late final _pages = PageController(initialPage: widget.initial);
  late int _index = widget.initial;
  final _keys = <int, GlobalKey>{};
  String _name = '';
  Uint8List? _photo;
  bool _busy = false;
  int get _count =>
      widget.templates?.length ?? widget.category?.items.length ?? 1;
  ({String text, String reference, String greeting, String background}) _item(
    int i,
  ) {
    final date = widget.dailyDate;
    if (date != null) {
      final verse = Catalog.verseFor(date);
      return (
        text: verse.text,
        reference: verse.reference,
        greeting: 'God bless you',
        background: Catalog.backgroundFor(date) ?? '',
      );
    }
    final templates = widget.templates;
    if (templates != null) {
      final t = templates[i];
      return (
        text: t.text,
        reference: t.reference,
        greeting: t.greeting,
        background: t.background,
      );
    }
    final cat = widget.category;
    if (cat != null) {
      final t = cat.items[i];
      return (
        text: t.text,
        reference: t.reference,
        greeting: cat.greeting,
        background: Catalog.statusBackground(widget.categoryIndex * 3 + i),
      );
    }
    return (
      text: widget.singleText ?? '',
      reference: widget.singleReference ?? '',
      greeting: widget.singleGreeting ?? 'God bless you',
      background: Catalog.statusBackground(0),
    );
  }

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  Future<void> _personalize() async {
    final result =
        await showModalBottomSheet<({String name, Uint8List? photo})>(
          context: context,
          isScrollControlled: true,
          useSafeArea: true,
          requestFocus: true,
          builder: (_) => PersonalizeSheet(name: _name, photo: _photo),
        );
    if (result != null && mounted)
      setState(() {
        _name = result.name;
        _photo = result.photo;
      });
  }

  Future<void> _export({bool save = false, bool whatsapp = false}) async {
    final key = _keys[_index];
    if (_busy || key == null) return;
    setState(() => _busy = true);
    try {
      final bytes = await StatusExport.capture(key);
      if (bytes == null) {
        if (mounted) toast(context, 'Please wait for the picture to load.');
        return;
      }
      if (save) {
        final ok = await StatusExport.save(bytes);
        if (mounted)
          toast(
            context,
            ok
                ? 'Your blessing has been saved.'
                : 'Could not save this picture.',
          );
      } else {
        await StatusExport.share(bytes, whatsapp: whatsapp);
      }
    } catch (_) {
      if (mounted)
        toast(
          context,
          'Could not share this picture. Try Save instead.',
          error: true,
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.bg,
    appBar: AppBar(
      title: Text(
        _count == 1
            ? (widget.dailyDate != null
                ? 'Share today’s verse'
                : 'Your blessing')
            : 'Blessing ${_index + 1} of $_count',
      ),
      actions: [
        IconButton(
          tooltip: 'Personalize',
          onPressed: _personalize,
          icon: const Icon(Icons.person_outline, color: AppColors.gold),
        ),
      ],
    ),
    body: ContentWidth(
      child: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pages,
              itemCount: _count,
              onPageChanged: (i) => setState(() => _index = i),
              itemBuilder: (context, i) {
                final t = _item(i);
                final key = _keys.putIfAbsent(i, GlobalKey.new);
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 8, 24, 12),
                    child: AspectRatio(
                      aspectRatio: 9 / 16,
                      child: RepaintBoundary(
                        key: key,
                        child:
                            widget.dailyDate != null
                                ? DailyVerseArt(
                                  date: widget.dailyDate ?? DateTime.now(),
                                  aspect: 9 / 16,
                                  name: _name,
                                  photo: _photo,
                                )
                                : StatusCard(
                                  background: t.background,
                                  greeting: t.greeting,
                                  text: t.text,
                                  reference: t.reference,
                                  name: _name,
                                  photo: _photo,
                                ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: SizedBox(
              width: double.infinity,
              height: 44,
              child: OutlinedButton.icon(
                onPressed: _personalize,
                icon: const Icon(Icons.edit_outlined, size: 18),
                label: Text(
                  _name.isEmpty ? 'Add your name & photo' : 'Edit name & photo',
                ),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton.filledTonal(
                    icon: const Icon(Icons.download_outlined),
                    tooltip: 'Save image',
                    onPressed: _busy ? null : () => _export(save: true),
                  ),
                  FilledButton.icon(
                    onPressed: _busy ? null : () => _export(whatsapp: true),
                    icon: const Icon(Icons.chat_outlined, size: 20),
                    label: const Text('WhatsApp'),
                  ),
                  IconButton.filledTonal(
                    icon: const Icon(Icons.ios_share_outlined),
                    tooltip: 'Share image',
                    onPressed: _busy ? null : () => _export(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
