import 'dart:typed_data';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../core/theme.dart';
import '../../core/data/web_media.dart';
import '../../widgets/blessing_signature.dart';

/// 9:16 WhatsApp status picture: calm background, greeting, verse and
/// reference. Sizes scale with the card width so the shared image matches the
/// thumbnail exactly.
class StatusCard extends StatelessWidget {
  const StatusCard({
    super.key,
    required this.background,
    required this.greeting,
    required this.text,
    required this.reference,
    this.compact = false,
    this.artworkContainsText = false,
    this.name = '',
    this.photo,
  });

  final String background;
  final String greeting;
  final String text;
  final String reference;
  final String name;
  final Uint8List? photo;

  /// Thumbnails trim long verses.
  final bool compact;
  final bool artworkContainsText;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 9 / 16,
      child: LayoutBuilder(
        builder: (context, c) {
          final w = c.maxWidth;
          final len = text.length;
          final verseSize =
              w *
              (len > 200
                  ? 0.056
                  : len > 130
                  ? 0.064
                  : 0.074);
          return Stack(
            fit: StackFit.expand,
            children: [
              const ColoredBox(color: AppColors.paper),
              if (background.isNotEmpty)
                CachedNetworkImage(
                  imageUrl: WebMedia.resolve(background),
                  fit: artworkContainsText ? BoxFit.contain : BoxFit.cover,
                  memCacheWidth: compact ? 360 : 1080,
                  fadeInDuration: const Duration(milliseconds: 150),
                  errorWidget: (_, _, _) => const SizedBox.shrink(),
                ),
              if (!artworkContainsText) DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      AppColors.scrim.withValues(alpha: .1),
                      AppColors.scrim.withValues(alpha: .22),
                      AppColors.scrim.withValues(alpha: .85),
                    ],
                  ),
                ),
              ),
              if (!artworkContainsText) Padding(
                padding: EdgeInsets.fromLTRB(
                  w * 0.09,
                  w * 0.16,
                  w * 0.09,
                  (name.trim().isNotEmpty || photo != null) ? w * .34 : w * .1,
                ),
                child: Column(
                  children: [
                    Text(
                      greeting,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: AppTheme.serif,
                        fontStyle: FontStyle.italic,
                        fontWeight: FontWeight.w700,
                        fontSize: w * 0.095,
                        color: AppColors.imageGold,
                        shadows: const [
                          Shadow(color: AppColors.scrim, blurRadius: 8),
                        ],
                      ),
                    ),
                    SizedBox(height: w * 0.03),
                    Container(
                      width: w * 0.16,
                      height: 1.4,
                      color: AppColors.imageGold.withValues(alpha: .7),
                    ),
                    const Spacer(),
                    Expanded(
                      flex: 5,
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.bottomCenter,
                        child: SizedBox(
                          width: w * .82,
                          child: Text(
                      '“$text”',
                      textAlign: TextAlign.center,
                      
                      style: TextStyle(
                        fontFamily: AppTheme.serif,
                        fontSize: verseSize,
                        height: 1.45,
                        color: AppColors.imageInk,
                        fontWeight: FontWeight.w500,
                        shadows: const [
                          Shadow(
                            color: AppColors.scrim,
                            blurRadius: 10,
                            offset: Offset(0, 1),
                          ),
                        ],
                      ),
                    ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: w * 0.05),
                    Text(
                      reference.toUpperCase(),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: w * 0.034,
                        letterSpacing: 0,
                        fontWeight: FontWeight.w800,
                        color: AppColors.imageGold,
                      ),
                    ),
                    SizedBox(height: w * .045),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.add,
                          size: w * 0.045,
                          color: AppColors.imageGold.withValues(alpha: .8),
                        ),
                        SizedBox(width: w * 0.01),
                        Text(
                          'AASHRAY',
                          style: TextStyle(
                            fontFamily: AppTheme.serif,
                            fontSize: w * 0.034,
                            letterSpacing: 0,
                            fontWeight: FontWeight.w700,
                            color: AppColors.imageSoft,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (name.trim().isNotEmpty || photo != null)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: BlessingSignature(name: name, photo: photo),
                ),
            ],
          );
        },
      ),
    );
  }
}
