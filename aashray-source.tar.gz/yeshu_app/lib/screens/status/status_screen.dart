import 'package:flutter/material.dart';
import '../../core/data/catalog.dart';
import '../../core/data/status_templates.dart';
import '../../widgets/common.dart';
import 'status_card.dart';
import 'status_viewer.dart';

class StatusScreen extends StatefulWidget {
  const StatusScreen({super.key});
  @override
  State<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen> {
  String? _category;
  @override
  Widget build(BuildContext context) {
    final items =
        StatusTemplates.featured
            .where((t) => _category == null || t.categoryId == _category)
            .toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Christian status')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: PageIntro(
                  title: 'Faith, with a personal touch',
                  detail:
                      '${StatusTemplates.featured.length} Christian designs · Your name & photo',
                  icon: Icons.ios_share_outlined,
                ),
              ),
              SliverToBoxAdapter(
                child: SizedBox(
                  height: 46,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: const Text('All designs'),
                          selected: _category == null,
                          onSelected: (_) => setState(() => _category = null),
                        ),
                      ),
                      for (final cat in Catalog.status)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(cat.name),
                            selected: _category == cat.id,
                            onSelected:
                                (_) => setState(() => _category = cat.id),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(24, 18, 24, 28),
                sliver: SliverGrid.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 9 / 16,
                  ),
                  itemCount: items.length,
                  itemBuilder:
                      (context, i) => GestureDetector(
                        onTap:
                            () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(
                                builder:
                                    (_) => StatusViewer.featured(
                                      templates: items,
                                      initial: i,
                                    ),
                              ),
                            ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: StatusCard(
                            background: items[i].background,
                            greeting: items[i].greeting,
                            text: items[i].text,
                            reference: items[i].reference,
                            compact: true,
                            artworkContainsText: items[i].artworkContainsText,
                            name: 'Your name',
                          ),
                        ),
                      ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
