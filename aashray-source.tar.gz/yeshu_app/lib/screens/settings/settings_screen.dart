import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../core/config.dart';
import '../../core/premium/premium_store.dart';
import '../../core/share_helper.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../daily/daily_wallpaper_screen.dart';
import '../paywall/legal_screen.dart';
import '../paywall/paywall_screen.dart';
import '../peace/peace_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  void _push(BuildContext context, Widget page) =>
      Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));

  @override
  Widget build(BuildContext context) {
    final p = PremiumStore.instance;
    final expiry = p.expiry;
    final active = p.isActive;
    // Never surface internal/test identifiers to users.
    final subId = p.paymentId;
    final showSubId = active && subId != null && !subId.startsWith('test');

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ContentWidth(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            // Membership card
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppColors.ink,
                borderRadius: BorderRadius.circular(18),
                boxShadow: const [BoxShadow(color: AppColors.shadow, blurRadius: 20, offset: Offset(0, 8))],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.imageGold.withValues(alpha: .5)),
                    ),
                    child: const Center(child: CrossMark(size: 22, color: AppColors.imageGold)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${AppConfig.appName} Premium',
                      style: const TextStyle(color: AppColors.imageInk, fontWeight: FontWeight.w800, fontSize: 17)),
                    const SizedBox(height: 3),
                    Text(
                      active && expiry != null
                        ? 'Active · valid till ${expiry.day}/${expiry.month}/${expiry.year}'
                        : 'Bible, wallpapers, prayers & status — all in one',
                      style: const TextStyle(color: AppColors.imageSoft, fontSize: 13, height: 1.3)),
                  ])),
                ]),
                if (!active) ...[
                  const SizedBox(height: 14),
                  SizedBox(width: double.infinity, height: 44, child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.imageGold,
                      foregroundColor: AppColors.ink,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () => _push(context, const PaywallScreen()),
                    child: const Text('Unlock Premium', style: TextStyle(fontWeight: FontWeight.w800)),
                  )),
                ],
              ]),
            ),
            if (showSubId) ...[
              const SizedBox(height: 12),
              _Group(children: [
                _Row(
                  icon: Icons.receipt_long_outlined,
                  title: 'Subscription ID',
                  subtitle: subId,
                  trailing: const Icon(Icons.copy_rounded, size: 18, color: AppColors.muted),
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: subId));
                    toast(context, 'Subscription ID copied');
                  },
                ),
              ]),
            ],
            const _Header('Your sanctuary'),
            _Group(children: [
              _Row(icon: Icons.today_outlined, title: 'Daily verse wallpaper',
                onTap: () => _push(context, const DailyWallpaperScreen())),
              _Row(icon: Icons.headphones_outlined, title: 'Prayers & bedtime stories',
                onTap: () => _push(context, const PeaceScreen())),
              _Row(icon: Icons.favorite_border_rounded, title: 'Share with family',
                onTap: () => ShareHelper.shareText(
                  'I use ${AppConfig.appName} for the Bible, Jesus wallpapers and daily status. ${AppConfig.playStoreUrl}')),
            ]),
            const _Header('Help & legal'),
            _Group(children: [
              _Row(icon: Icons.support_agent_outlined, title: 'Contact & support',
                onTap: () => _push(context, const LegalScreen(kind: LegalKind.contact))),
              _Row(icon: Icons.receipt_long_outlined, title: 'Refund & cancellation',
                onTap: () => _push(context, const LegalScreen(kind: LegalKind.refunds))),
              _Row(icon: Icons.privacy_tip_outlined, title: 'Privacy policy',
                onTap: () => _push(context, const LegalScreen(kind: LegalKind.privacy))),
              _Row(icon: Icons.description_outlined, title: 'Terms & conditions',
                onTap: () => _push(context, const LegalScreen(kind: LegalKind.terms))),
            ]),
            const SizedBox(height: 28),
            const Center(child: CrossMark(size: 18, color: AppColors.gold)),
            const SizedBox(height: 8),
            FutureBuilder<PackageInfo>(
              future: PackageInfo.fromPlatform(),
              builder: (context, snap) => Text(
                snap.hasData ? '${AppConfig.appName} · Version ${snap.data!.version}' : AppConfig.appName,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.muted, fontSize: 12),
              ),
            ),
            const SizedBox(height: 2),
            const Text('Made with love & faith', textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.muted, fontSize: 11.5)),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(6, 24, 6, 8),
    child: Text(text.toUpperCase(),
      style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, letterSpacing: 1.1, color: AppColors.muted)),
  );
}

class _Group extends StatelessWidget {
  const _Group({required this.children});
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: AppColors.paper,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppColors.line),
    ),
    clipBehavior: Clip.antiAlias,
    child: Column(children: [
      for (var i = 0; i < children.length; i++) ...[
        if (i > 0) const Divider(height: 1, indent: 58, color: AppColors.line),
        children[i],
      ],
    ]),
  );
}

class _Row extends StatelessWidget {
  const _Row({required this.icon, required this.title, this.subtitle, this.trailing, required this.onTap});
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(children: [
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(color: AppColors.goldSoft, borderRadius: BorderRadius.circular(9)),
          child: Icon(icon, size: 17, color: AppColors.gold),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: AppColors.ink)),
          if (subtitle != null)
            Text(subtitle!, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        ])),
        trailing ?? const Icon(Icons.chevron_right_rounded, size: 20, color: AppColors.muted),
      ]),
    ),
  );
}
