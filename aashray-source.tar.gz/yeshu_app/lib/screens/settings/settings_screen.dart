import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../core/config.dart';
import '../../core/premium/premium_store.dart';
import '../../core/share_helper.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../daily/daily_wallpaper_screen.dart';
import '../paywall/legal_screen.dart';
import '../peace/peace_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = PremiumStore.instance;
    final expiry = p.expiry;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ContentWidth(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 30),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.ink,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const CrossMark(size: 26, color: AppColors.imageGold),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${AppConfig.appName} Premium',
                            style: const TextStyle(
                              color: AppColors.imageInk,
                              fontWeight: FontWeight.w800,
                              fontSize: 17,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            expiry == null
                                ? 'Not active'
                                : 'Active · ${p.daysRemaining} days left (until ${expiry.day}/${expiry.month}/${expiry.year})',
                            style: const TextStyle(
                              color: AppColors.imageSoft,
                              fontSize: 13.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (p.paymentId != null)
              ListTile(
                leading: const Icon(Icons.receipt_long_outlined),
                title: const Text('Payment ID'),
                subtitle: Text(p.paymentId!),
                trailing: const Icon(Icons.copy_rounded, size: 20),
                onTap: () {
                  Clipboard.setData(ClipboardData(text: p.paymentId!));
                  toast(context, 'Payment ID copied');
                },
              ),
            const SectionTitle(
              'Your sanctuary',
              padding: EdgeInsets.fromLTRB(24, 12, 24, 12),
            ),
            ListTile(
              leading: const Icon(Icons.today_outlined),
              title: const Text('Daily wallpaper'),
              onTap:
                  () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const DailyWallpaperScreen(),
                    ),
                  ),
            ),
            ListTile(
              leading: const Icon(Icons.headphones_outlined),
              title: const Text('Prayers & bedtime stories'),
              onTap:
                  () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const PeaceScreen(),
                    ),
                  ),
            ),
            const SectionTitle(
              'About Aashray',
              padding: EdgeInsets.fromLTRB(24, 24, 24, 12),
            ),
            ListTile(
              leading: const Icon(Icons.share_outlined),
              title: const Text('Share Aashray with family'),
              onTap:
                  () => ShareHelper.shareText(
                    'I use ${AppConfig.appName} for the Bible, Jesus wallpapers and daily status. ${AppConfig.playStoreUrl}',
                  ),
            ),
            ListTile(
              leading: const Icon(Icons.description_outlined),
              title: const Text('Terms & Conditions'),
              onTap:
                  () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const LegalScreen(kind: LegalKind.terms),
                    ),
                  ),
            ),
            ListTile(
              leading: const Icon(Icons.privacy_tip_outlined),
              title: const Text('Privacy Policy'),
              onTap:
                  () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder:
                          (_) => const LegalScreen(kind: LegalKind.privacy),
                    ),
                  ),
            ),
            for (final entry in const [
              (LegalKind.refunds, Icons.receipt_long_outlined),
              (LegalKind.delivery, Icons.download_done_outlined),
              (LegalKind.contact, Icons.support_agent_outlined),
            ])
              ListTile(
                leading: Icon(entry.$2),
                title: Text(switch (entry.$1) {
                  LegalKind.refunds => 'Refund & Cancellation',
                  LegalKind.delivery => 'Digital Delivery Policy',
                  _ => 'Contact & Support',
                }),
                trailing: const Icon(Icons.chevron_right, size: 20),
                onTap:
                    () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => LegalScreen(kind: entry.$1),
                      ),
                    ),
              ),
            const SizedBox(height: 20),
            FutureBuilder<PackageInfo>(
              future: PackageInfo.fromPlatform(),
              builder:
                  (context, snap) => Text(
                    snap.hasData
                        ? '${AppConfig.appName} ${snap.data!.version} (${snap.data!.buildNumber})'
                        : AppConfig.appName,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppColors.muted,
                      fontSize: 12.5,
                    ),
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
