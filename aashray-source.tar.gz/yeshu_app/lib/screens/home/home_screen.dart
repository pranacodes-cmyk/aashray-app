import 'package:flutter/material.dart';
import '../../core/audio/audio_hub.dart';
import '../../core/data/catalog.dart';
import '../../core/data/peace_catalog.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../bible/bible_screen.dart';
import '../daily/daily_wallpaper_screen.dart';
import '../peace/peace_player_screen.dart';
import '../peace/peace_screen.dart';
import '../settings/settings_screen.dart';
import '../status/status_screen.dart';
import '../status/status_viewer.dart';
import '../wallpapers/wallpapers_screen.dart';
import '../ringtones/ringtones_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  void _open(BuildContext context, Widget page) =>
      Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page));
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final verse = Catalog.verseFor(now);
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ContentWidth(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
            children: [
              Row(
                children: [
                  Image.asset('assets/branding/aashray-logo.png', width: 26, height: 32),
                  const SizedBox(width: 10),
                  const Text(
                    'Aashray',
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800),
                  ),
                  const Spacer(),
                  IconButton(
                    tooltip: 'Settings',
                    onPressed: () => _open(context, const SettingsScreen()),
                    icon: const Icon(Icons.settings_outlined, size: 22),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Verse of the day',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Text(
                    MaterialLocalizations.of(context).formatMediumDate(now),
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppColors.muted,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: Image.asset(
                        'assets/images/verse_garden.jpg',
                        fit: BoxFit.cover,
                        alignment: Alignment.topCenter,
                      ),
                    ),
                    Positioned.fill(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              AppColors.scrim.withValues(alpha: .04),
                              AppColors.scrim.withValues(alpha: .85),
                            ],
                            stops: const [.1, 1],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(24, 104, 24, 24),
                      child: Column(
                        children: [
                          Text(
                            '“${verse.text}”',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: AppTheme.serif,
                              fontSize: verse.text.length > 150 ? 19 : 22,
                              height: 1.5,
                              color: AppColors.imageInk,
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            verse.reference,
                            style: const TextStyle(
                              color: AppColors.imageGold,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed:
                          () => _open(context, const DailyWallpaperScreen()),
                      icon: const Icon(Icons.wallpaper_rounded, size: 18),
                      label: const Text(
                        'Set wallpaper',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12.5),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed:
                          () => _open(context, StatusViewer.daily(date: now)),
                      icon: const Icon(Icons.person_add_alt_1_outlined, size: 18),
                      label: const Text(
                        'Make status',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12.5),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Your wallpaper changes automatically — a new verse every day.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11.5,
                  color: Theme.of(context).textTheme.bodySmall?.color
                      ?.withValues(alpha: .75),
                ),
              ),
              const SizedBox(height: 28),
              const Text(
                'Your daily blessings',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 14),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: 18,
                crossAxisSpacing: 12,
                childAspectRatio: .98,
                children: [
                  _Feature(
                    title: 'Wallpapers',
                    detail: 'Faith on your screen',
                    asset: 'wallpapers_tile',
                    onTap: () => _open(context, const WallpapersScreen()),
                  ),
                  _Feature(
                    title: 'Holy Bible',
                    detail: 'Read the Word',
                    asset: 'bible_tile',
                    onTap: () => _open(context, const BibleScreen()),
                  ),
                  _Feature(
                    title: 'Prayer',
                    detail: 'A moment with God',
                    asset: 'prayer_tile',
                    onTap: () => _open(context, const PeaceScreen()),
                  ),
                  _Feature(
                    title: 'Meditation',
                    detail: 'Peace for your soul',
                    asset: 'meditation_tile',
                    onTap:
                        () => _open(
                          context,
                          const PeaceScreen(initialKind: 'meditation'),
                        ),
                  ),
                  _Feature(
                    title: 'Christian status',
                    detail: 'Your name & photo',
                    asset: 'status_tile',
                    onTap: () => _open(context, const StatusScreen()),
                  ),
                  _Feature(
                    title: 'Night stories',
                    detail: 'Rest in His peace',
                    asset: 'verse_garden',
                    onTap:
                        () => _open(
                          context,
                          const PeaceScreen(initialKind: 'story'),
                        ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              const Divider(),
              ListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                leading: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppColors.accentSoft,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.music_note_rounded,
                    color: AppColors.accent,
                  ),
                ),
                title: const Text(
                  'Aashray bhajans',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                ),
                subtitle: const Text(
                  'Hindi ringtones',
                  style: TextStyle(color: AppColors.muted, fontSize: 12),
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => _open(context, const RingtonesScreen()),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  const _Feature({
    required this.title,
    required this.detail,
    required this.asset,
    required this.onTap,
  });
  final String title, detail, asset;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Semantics(
    button: true,
    label: title,
    onTap: onTap,
    excludeSemantics: true,
    child: Material(
      color: AppColors.bg,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  width: double.infinity,
                  child: Image.asset(
                    'assets/images/$asset.jpg',
                    fit: BoxFit.cover,
                    alignment: Alignment.topCenter,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 9),
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
            ),
            const SizedBox(height: 3),
            Text(
              detail,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppColors.muted, fontSize: 11),
            ),
          ],
        ),
      ),
    ),
  );
}

void openPeaceTrack(BuildContext context, PeaceTrack t) {
  tapHaptic();
  AudioHub.instance.playPeace(t);
  Navigator.push(
    context,
    MaterialPageRoute<void>(builder: (_) => const PeacePlayerScreen()),
  );
}

class PeaceTile extends StatelessWidget {
  const PeaceTile({super.key, required this.track, this.width = 150});
  final PeaceTrack track;
  final double width;
  @override
  Widget build(BuildContext context) => SizedBox(
    width: width,
    child: GestureDetector(
      onTap: () => openPeaceTrack(context, track),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AspectRatio(
            aspectRatio: 1,
            child: Stack(
              fit: StackFit.expand,
              children: [
                NetImage(track.thumbUrl, radius: 8, memWidth: 320),
                Positioned(
                  right: 6,
                  bottom: 6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.scrim.withValues(alpha: .65),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      track.minutesLabel,
                      style: const TextStyle(
                        color: AppColors.imageInk,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            track.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12, height: 1.3),
          ),
        ],
      ),
    ),
  );
}
