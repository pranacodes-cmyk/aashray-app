import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../../core/native/wallpaper_bridge.dart';
import '../../core/prefs.dart';
import '../../core/premium/premium_store.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../status/status_viewer.dart';
import 'daily_verse_art.dart';

class DailyWallpaperScreen extends StatefulWidget {
  const DailyWallpaperScreen({super.key});
  @override
  State<DailyWallpaperScreen> createState() => _DailyWallpaperScreenState();
}

class _DailyWallpaperScreenState extends State<DailyWallpaperScreen>
    with WidgetsBindingObserver {
  DateTime _today = DateTime.now();
  bool _active = false, _working = false, _awaitingPicker = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    final active =
        kIsWeb
            ? Prefs.getBool('daily_wallpaper_web_simulated')
            : await WallpaperBridge.dailyIsActive();
    if (!mounted) return;
    setState(() {
      _active = active;
      _today = DateTime.now();
    });
    if (_awaitingPicker) {
      _awaitingPicker = false;
      if (active)
        toast(context, 'Daily wallpaper is on. A new verse every day.');
    }
  }

  Future<void> _set() async {
    if (_working) return;
    if (!PremiumStore.instance.isActive) {
      toast(context, 'Premium is required for daily wallpaper.', error: true);
      return;
    }
    tapHaptic();
    if (kIsWeb) {
      final confirm = await showDialog<bool>(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text('Preview daily wallpaper'),
              content: const Text(
                'This browser cannot change your phone wallpaper. Preview auto-change here; Android uses its Set wallpaper screen.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('Enable preview'),
                ),
              ],
            ),
      );
      if (confirm != true) return;
      await Prefs.setBool('daily_wallpaper_web_simulated', true);
      await _refresh();
      return;
    }
    setState(() => _working = true);
    try {
      await WallpaperBridge.dailyVerseSetPremium(
        PremiumStore.instance.isActive,
      );
      final status = await WallpaperBridge.dailyCacheStatus().timeout(
        const Duration(seconds: 6),
      );
      if (status?['ready'] != true) {
        final prepared = await WallpaperBridge.dailyPrefetch().timeout(
          const Duration(seconds: 45),
        );
        if (prepared?['success'] != true || prepared?['ready'] != true) {
          if (mounted)
            toast(
              context,
              'Connect once to prepare the daily pictures, then try again.',
              error: true,
            );
          return;
        }
      }
      _awaitingPicker = true;
      final opened = await WallpaperBridge.openDailyPicker().timeout(
        const Duration(seconds: 10),
      );
      if (!opened) {
        _awaitingPicker = false;
        if (mounted)
          toast(
            context,
            'Could not open Set wallpaper. Please try again.',
            error: true,
          );
      }
    } catch (_) {
      _awaitingPicker = false;
      if (mounted)
        toast(
          context,
          'Could not prepare daily wallpaper. Please try again.',
          error: true,
        );
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Daily auto-rotating')),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 24),
          children: [
            Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: ((MediaQuery.sizeOf(context).height - 320) *
                          9 /
                          19.5)
                      .clamp(135.0, 290.0),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: DailyVerseArt(date: _today),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Icon(
                  _active
                      ? Icons.check_circle_outline
                      : Icons.autorenew_rounded,
                  color: _active ? AppColors.green : AppColors.gold,
                  size: 23,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _active
                            ? (kIsWeb
                                ? 'Daily rotation · preview on'
                                : 'Daily rotation is on')
                            : 'A fresh wallpaper every day',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        kIsWeb
                            ? 'Phone wallpaper is unchanged in web preview'
                            : 'Changes daily · works offline after setup',
                        style: const TextStyle(
                          color: AppColors.muted,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _working ? null : _set,
              icon:
                  _working
                      ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.onPrimary,
                        ),
                      )
                      : const Icon(Icons.wallpaper_outlined, size: 20),
              label: Text(
                _working
                    ? 'Preparing pictures…'
                    : _active
                    ? 'Apply again'
                    : 'Set wallpaper',
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Your wallpaper changes automatically — a new verse every day.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11.5,
                color: Theme.of(context).textTheme.bodySmall?.color
                    ?.withValues(alpha: .75),
              ),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => StatusViewer.daily(date: _today),
                    ),
                  ),
              icon: const Icon(Icons.ios_share_outlined, size: 20),
              label: const Text('Share with name & photo'),
            ),
          ],
        ),
      ),
    ),
  );
}
