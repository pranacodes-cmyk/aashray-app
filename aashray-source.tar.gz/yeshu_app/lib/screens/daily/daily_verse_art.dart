import 'dart:typed_data';
import 'package:flutter/material.dart';

import '../../core/data/catalog.dart';
import '../../core/data/day_rules.dart';
import '../../widgets/common.dart';
import '../../widgets/blessing_signature.dart';

/// Exact in-app twin of the Android daily wallpaper service drawing
/// (DailyVerseWallpaperService.drawNow): same background crop, gradient,
/// proportions and system serif typeface — so what you see is what you set.
class DailyVerseArt extends StatelessWidget {
  const DailyVerseArt({
    super.key,
    required this.date,
    this.aspect = 9 / 19.5,
    this.name = '',
    this.photo,
  });

  final DateTime date;
  final String name;
  final Uint8List? photo;

  /// width / height
  final double aspect;

  @override
  Widget build(BuildContext context) {
    final verse = Catalog.verseFor(date);
    final bg = Catalog.backgroundFor(date);
    return AspectRatio(
      aspectRatio: aspect,
      child: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF070B18),
                  Color(0xFF14213F),
                  Color(0xFF090611),
                ],
                stops: [0, 0.48, 1],
              ),
            ),
          ),
          if (bg != null) NetImage(bg, memWidth: 1080),
          CustomPaint(
            painter: _VersePainter(
              verse: verse,
              date: date,
              personal: name.trim().isNotEmpty || photo != null,
            ),
          ),
          if (name.trim().isNotEmpty || photo != null)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: BlessingSignature(name: name, photo: photo),
            ),
        ],
      ),
    );
  }
}

class _VersePainter extends CustomPainter {
  _VersePainter({
    required this.verse,
    required this.date,
    this.personal = false,
  });
  final bool personal;

  final Verse verse;
  final DateTime date;

  static const gold = Color.fromARGB(255, 245, 204, 110);
  static const serif = 'serif';

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final rect = Offset.zero & size;

    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color.fromARGB(38, 0, 0, 0),
            Color.fromARGB(64, 0, 0, 0),
            Color.fromARGB(115, 0, 0, 0),
            Color.fromARGB(166, 0, 0, 0),
            Color.fromARGB(217, 0, 0, 0),
          ],
          stops: [0, 0.35, 0.55, 0.75, 1],
        ).createShader(rect),
    );

    final blockCenterY = h * 0.42;
    final crossY = blockCenterY - h * 0.087;

    // Top cross
    final cross =
        Paint()
          ..color = gold
          ..strokeWidth = w * 0.006
          ..strokeCap = StrokeCap.round
          ..maskFilter = MaskFilter.blur(BlurStyle.solid, w * 0.004);
    final crossH = w * 0.0615;
    final arm = w * 0.0239;
    final armY = crossY - crossH / 2 + w * 0.0188;
    canvas.drawLine(
      Offset(w / 2, crossY - crossH / 2),
      Offset(w / 2, crossY + crossH / 2),
      cross,
    );
    canvas.drawLine(
      Offset(w / 2 - arm, armY),
      Offset(w / 2 + arm, armY),
      cross,
    );

    // Date
    final dateFont = w * 0.0205;
    final label =
        '${kMonthNames[date.month - 1].toUpperCase()} ${date.day} · ${date.year}';
    final dateY = crossY + h * 0.0308;
    final dateTp = _text(
      label,
      TextStyle(
        fontFamily: serif,
        fontWeight: FontWeight.w700,
        fontSize: dateFont,
        letterSpacing: dateFont * 0.33,
        color: gold,
        shadows: [
          Shadow(
            color: const Color.fromARGB(217, 0, 0, 0),
            blurRadius: w * 0.007,
          ),
        ],
      ),
      w,
    );
    _drawAtBaseline(canvas, dateTp, w, dateY);
    final hair =
        Paint()
          ..color = const Color.fromARGB(217, 232, 188, 89)
          ..strokeWidth = (w * 0.0009).clamp(1.0, 4.0);
    final half = dateTp.width / 2 + w * 0.0205;
    final len = w * 0.0513;
    final hairY = dateY - w * 0.0068;
    canvas.drawLine(
      Offset(w / 2 - half - len, hairY),
      Offset(w / 2 - half, hairY),
      hair,
    );
    canvas.drawLine(
      Offset(w / 2 + half, hairY),
      Offset(w / 2 + half + len, hairY),
      hair,
    );

    // Verse
    final verseFont = w * 0.0547;
    final lineH = verseFont * 1.45;
    final textStartY = dateY + h * 0.0395;
    final lines = _wrap(
      '“${verse.text}”',
      TextStyle(
        fontFamily: serif,
        fontStyle: FontStyle.italic,
        fontSize: verseFont,
      ),
      w * 0.88,
    );
    for (var i = 0; i < lines.length; i++) {
      final tp = _text(
        lines[i],
        TextStyle(
          fontFamily: serif,
          fontStyle: FontStyle.italic,
          fontSize: verseFont,
          color: Colors.white,
          shadows: [
            Shadow(
              color: const Color.fromARGB(230, 0, 0, 0),
              blurRadius: w * 0.011,
              offset: Offset(0, w * 0.003),
            ),
          ],
        ),
        w * 2,
      );
      _drawAtBaseline(canvas, tp, w, textStartY + i * lineH);
    }

    // Reference
    final refFont = w * 0.0239;
    final refTp = _text(
      '— ${verse.reference.toUpperCase()}',
      TextStyle(
        fontFamily: serif,
        fontWeight: FontWeight.w700,
        fontSize: refFont,
        letterSpacing: refFont * 0.178,
        color: gold,
        shadows: [
          Shadow(
            color: const Color.fromARGB(166, 0, 0, 0),
            blurRadius: w * 0.006,
          ),
        ],
      ),
      w,
    );
    _drawAtBaseline(
      canvas,
      refTp,
      w,
      textStartY + lines.length * lineH + w * 0.0376,
    );

    if (personal) return;

    // Bottom branding
    final brandY = h - h * 0.0711;
    final divY = brandY - h * 0.0182;
    final divRect = Rect.fromLTWH(
      w / 2 - w * 0.12,
      divY,
      w * 0.24,
      (w * 0.0013).clamp(1.0, 4.0),
    );
    canvas.drawRect(
      divRect,
      Paint()
        ..shader = const LinearGradient(
          colors: [
            Color.fromARGB(0, 245, 204, 110),
            Color.fromARGB(217, 245, 204, 110),
            Color.fromARGB(0, 245, 204, 110),
          ],
        ).createShader(divRect),
    );
    final small =
        Paint()
          ..color = gold
          ..strokeWidth = w * 0.003
          ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(w / 2, brandY - w * 0.0154),
      Offset(w / 2, brandY + w * 0.0103),
      small,
    );
    canvas.drawLine(
      Offset(w / 2 - w * 0.0077, brandY - w * 0.0077),
      Offset(w / 2 + w * 0.0077, brandY - w * 0.0077),
      small,
    );

    final markFont = w * 0.0308;
    _drawAtBaseline(
      canvas,
      _text(
        'AASHRAY',
        TextStyle(
          fontFamily: serif,
          fontWeight: FontWeight.w700,
          fontSize: markFont,
          letterSpacing: markFont * 0.167,
          color: gold,
          shadows: [
            Shadow(
              color: const Color.fromARGB(217, 0, 0, 0),
              blurRadius: w * 0.007,
            ),
          ],
        ),
        w,
      ),
      w,
      brandY + h * 0.0205,
    );
    final tagFont = w * 0.0171;
    _drawAtBaseline(
      canvas,
      _text(
        'BIBLE · WALLPAPERS · STATUS',
        TextStyle(
          fontFamily: serif,
          fontSize: tagFont,
          letterSpacing: tagFont * 0.2,
          color: const Color.fromARGB(199, 255, 255, 255),
        ),
        w,
      ),
      w,
      brandY + h * 0.034,
    );
  }

  TextPainter _text(String s, TextStyle style, double maxWidth) {
    return TextPainter(
      text: TextSpan(text: s, style: style),
      textDirection: TextDirection.ltr,
      maxLines: 1,
    )..layout(maxWidth: maxWidth);
  }

  void _drawAtBaseline(
    Canvas canvas,
    TextPainter tp,
    double w,
    double baseline,
  ) {
    final ascent = tp.computeDistanceToActualBaseline(TextBaseline.alphabetic);
    tp.paint(canvas, Offset((w - tp.width) / 2, baseline - ascent));
  }

  /// Greedy word wrap — the same algorithm the Android service uses.
  List<String> _wrap(String text, TextStyle style, double maxWidth) {
    final out = <String>[];
    var cur = '';
    for (final word in text.split(' ')) {
      final test = cur.isEmpty ? word : '$cur $word';
      final tp = TextPainter(
        text: TextSpan(text: test, style: style),
        textDirection: TextDirection.ltr,
      )..layout();
      if (tp.width > maxWidth && cur.isNotEmpty) {
        out.add(cur);
        cur = word;
      } else {
        cur = test;
      }
    }
    if (cur.isNotEmpty) out.add(cur);
    return out;
  }

  @override
  bool shouldRepaint(_VersePainter old) =>
      old.verse != verse || old.date != date || old.personal != personal;
}
