import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import '../../core/audio/audio_hub.dart';
import '../../core/data/catalog.dart';
import '../../core/native/media_bridge.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';

/// Hymn ringtones: preview and set as ringtone, notification or alarm.
class RingtonesScreen extends StatefulWidget {
  const RingtonesScreen({super.key});

  @override
  State<RingtonesScreen> createState() => _RingtonesScreenState();
}

class _RingtonesScreenState extends State<RingtonesScreen>
    with WidgetsBindingObserver {
  /// Waiting for the user to come back from "Modify system settings".
  (Ringtone, RingtoneTarget)? _pending;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _pending != null) {
      final p = _pending;
      if (p == null) return;
      _pending = null;
      MediaBridge.canWriteSettings().then((ok) {
        if (!mounted) return;
        if (ok) {
          _apply(p.$1, p.$2);
        } else {
          toast(
            context,
            'Ringtone is saved. Allow Modify system settings to set it.',
            error: true,
          );
        }
      });
    }
  }

  Future<bool> _save(Ringtone r, {bool quiet = false}) async {
    final outcome = await MediaBridge.saveRingtone(
      asset: r.asset,
      title: r.title,
    );
    if (!mounted) return false;
    if (outcome != RingtoneOutcome.ok) {
      toast(
        context,
        outcome == RingtoneOutcome.storageDenied
            ? 'Allow storage access to save this ringtone.'
            : 'Could not save this ringtone. Please try again.',
        error: true,
      );
      return false;
    }
    if (!quiet)
      toast(
        context,
        kIsWeb
            ? 'Your bhajan MP3 has been downloaded.'
            : 'Saved in Ringtones. Ready in your phone’s sound settings.',
      );
    return true;
  }

  Future<void> _chooseTarget(Ringtone r) async {
    tapHaptic();
    final saved = await _save(r, quiet: true);
    if (!saved || !mounted) return;
    if (kIsWeb) {
      toast(
        context,
        'MP3 saved. On Android, open Settings → Sound → Phone ringtone and choose this file.',
      );
      return;
    }
    final target = await showModalBottomSheet<RingtoneTarget>(
      context: context,
      builder:
          (c) => SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Set “${r.title}” as',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                SheetOption(
                  icon: Icons.phone_in_talk_rounded,
                  title: 'Phone ringtone',
                  onTap: () => Navigator.pop(c, RingtoneTarget.ringtone),
                ),
                SheetOption(
                  icon: Icons.notifications_active_rounded,
                  title: 'Notification sound',
                  tint: AppColors.gold,
                  onTap: () => Navigator.pop(c, RingtoneTarget.notification),
                ),
                SheetOption(
                  icon: Icons.alarm_rounded,
                  title: 'Alarm sound',
                  tint: AppColors.rose,
                  onTap: () => Navigator.pop(c, RingtoneTarget.alarm),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
    );
    if (target == null || !mounted) return;
    if (!await MediaBridge.canWriteSettings()) {
      if (!mounted) return;
      final go = await showDialog<bool>(
        context: context,
        builder:
            (c) => AlertDialog(
              title: const Text('One quick permission'),
              content: const Text(
                'To change your ringtone, Android needs you to allow “Modify system settings” for Aashray.\n\nTurn it on, then come back — we will set it automatically.',
                style: TextStyle(height: 1.4),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(c, false),
                  child: const Text('Not now'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(c, true),
                  child: const Text('Allow'),
                ),
              ],
            ),
      );
      if (go == true) {
        _pending = (r, target);
        final opened = await MediaBridge.openWriteSettings();
        if (!opened && mounted) {
          _pending = null;
          toast(
            context,
            'Ringtone saved. Open phone Settings → Apps → Aashray → Modify system settings, then retry Set.',
            error: true,
          );
        }
      }
      return;
    }
    await _apply(r, target);
  }

  Future<void> _apply(Ringtone r, RingtoneTarget target) async {
    final outcome = await withBusy(
      context,
      'Setting…',
      () => MediaBridge.setRingtone(
        asset: r.asset,
        title: r.title,
        target: target,
      ),
    );
    if (!mounted) return;
    final what = switch (target) {
      RingtoneTarget.ringtone => 'ringtone',
      RingtoneTarget.notification => 'notification sound',
      RingtoneTarget.alarm => 'alarm sound',
    };
    switch (outcome) {
      case RingtoneOutcome.ok:
        toast(context, '“${r.title}” is now your $what.');
      case RingtoneOutcome.needsPermission:
        toast(
          context,
          'Please allow “Modify system settings” and try again.',
          error: true,
        );
      case RingtoneOutcome.storageDenied:
        toast(
          context,
          'Allow storage access to save this ringtone.',
          error: true,
        );
      case RingtoneOutcome.savedNotSet:
        toast(
          context,
          'Saved. Your phone did not confirm the change; choose it in Settings → Sound → Phone ringtone.',
          error: true,
        );
      case RingtoneOutcome.error:
        toast(
          context,
          'Could not set the $what. Please try again.',
          error: true,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = Catalog.ringtones;
    return Scaffold(
      appBar: AppBar(title: const Text('Ringtones')),
      body: ContentWidth(
        child: ListenableBuilder(
          listenable: AudioHub.instance,
          builder: (context, _) {
            final hub = AudioHub.instance;
            return ListView(
              padding: const EdgeInsets.fromLTRB(0, 4, 0, 24),
              children: [
                const PageIntro(
                  title: 'Songs of faith.',
                  detail: '8 original Hindi bhajans · 30 seconds each',
                  icon: Icons.music_note_rounded,
                ),
                for (final r in list) ...[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: _RingtoneRow(
                      ringtone: r,
                      playing: hub.isCurrent('ring-${r.id}') && hub.playing,
                      loading: hub.isCurrent('ring-${r.id}') && hub.loading,
                      current: hub.isCurrent('ring-${r.id}'),
                      onPlay: () {
                        tapHaptic();
                        hub.playRingtone(r);
                      },
                      onSet: () => _chooseTarget(r),
                      onSave: () => _save(r),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}

class _RingtoneRow extends StatelessWidget {
  const _RingtoneRow({
    required this.ringtone,
    required this.playing,
    required this.loading,
    required this.current,
    required this.onPlay,
    required this.onSet,
    required this.onSave,
  });

  final Ringtone ringtone;
  final bool playing;
  final bool loading;
  final bool current;
  final VoidCallback onPlay;
  final VoidCallback onSet;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.fromLTRB(10, 10, 12, 10),
      decoration: BoxDecoration(
        color: current ? AppColors.primarySoft : AppColors.paper,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Semantics(
                button: true,
                label: '${playing ? "Pause" : "Play"} ${ringtone.title}',
                child: Material(
                  color: AppColors.primary,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: onPlay,
                    child: SizedBox(
                      width: 44,
                      height: 44,
                      child:
                          loading
                              ? const Padding(
                                padding: EdgeInsets.all(15),
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.4,
                                  color: AppColors.onPrimary,
                                ),
                              )
                              : Icon(
                                playing
                                    ? Icons.pause_rounded
                                    : Icons.play_arrow_rounded,
                                color: AppColors.onPrimary,
                                size: 30,
                              ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      ringtone.title,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                      ),
                    ),
                    Text(
                      'Hindi bhajan · ${ringtone.seconds}s',
                      style: const TextStyle(
                        color: AppColors.muted,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Save ${ringtone.title}',
                onPressed: onSave,
                icon: const Icon(
                  Icons.download_outlined,
                  color: AppColors.gold,
                ),
              ),
              FilledButton.tonal(
                onPressed: onSet,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.accentSoft,
                  foregroundColor: AppColors.accent,
                  minimumSize: const Size(64, 42),
                  textStyle: const TextStyle(fontWeight: FontWeight.w800),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text('Set'),
              ),
            ],
          ),
          if (current) const _Progress(),
        ],
      ),
    );
  }
}

class _Progress extends StatelessWidget {
  const _Progress();

  @override
  Widget build(BuildContext context) {
    final player = AudioHub.instance.player;
    return StreamBuilder<Duration>(
      stream: player.positionStream,
      builder: (context, snap) {
        final total = player.duration ?? Duration.zero;
        final pos = snap.data ?? Duration.zero;
        final done = player.processingState == ProcessingState.completed;
        final v =
            total.inMilliseconds <= 0 || done
                ? 0.0
                : (pos.inMilliseconds / total.inMilliseconds).clamp(0.0, 1.0);
        return Padding(
          padding: const EdgeInsets.fromLTRB(6, 10, 4, 2),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: v,
              minHeight: 4,
              backgroundColor: AppColors.paper,
            ),
          ),
        );
      },
    );
  }
}
