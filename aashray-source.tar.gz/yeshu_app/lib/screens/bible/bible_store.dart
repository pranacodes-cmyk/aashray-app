import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../../core/prefs.dart';

class SavedVerse {
  const SavedVerse({
    required this.bookId,
    required this.bookName,
    required this.chapter,
    required this.verse,
    required this.text,
  });

  final int bookId;
  final String bookName;
  final int chapter;
  final int verse;
  final String text;

  String get key => '$bookId:$chapter:$verse';
  String get reference => '$bookName $chapter:$verse';

  Map<String, Object> toJson() => {
    'b': bookId,
    'n': bookName,
    'c': chapter,
    'v': verse,
    't': text,
  };

  static SavedVerse fromJson(Map<String, dynamic> j) => SavedVerse(
    bookId: j['b'] as int,
    bookName: j['n'] as String,
    chapter: j['c'] as int,
    verse: j['v'] as int,
    text: j['t'] as String,
  );
}

/// Reading position, saved verses and text size — all on the device.
class BibleStore extends ChangeNotifier {
  BibleStore._() {
    _load();
  }

  static final instance = BibleStore._();

  static const _kLast = 'bible_last';
  static const _kSaved = 'bible_saved_v1';
  static const _kFont = 'bible_font';

  int? lastBook;
  int? lastChapter;
  String? lastBookName;
  double fontSize = 19;
  String fontFamily = 'Lora';
  int lastVerse = 1;
  List<SavedVerse> saved = [];

  void _load() {
    final last = Prefs.getString(_kLast);
    if (last != null) {
      final parts = last.split('|');
      if (parts.length == 3) {
        lastBook = int.tryParse(parts[0]);
        lastChapter = int.tryParse(parts[1]);
        lastBookName = parts[2];
      }
    }
    fontSize = Prefs.getDouble(_kFont) ?? 19;
    fontFamily =
        Prefs.getString('bible_font_family') == 'Manrope' ? 'Manrope' : 'Lora';
    lastVerse = Prefs.getInt('bible_last_verse') ?? 1;
    saved = [
      for (final s in Prefs.getList(_kSaved))
        if (_tryParse(s) case final v?) v,
    ];
  }

  static SavedVerse? _tryParse(String s) {
    try {
      return SavedVerse.fromJson(jsonDecode(s) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  bool get hasLast => lastBook != null && lastChapter != null;

  void setLast(int bookId, String bookName, int chapter) {
    lastBook = bookId;
    lastChapter = chapter;
    lastBookName = bookName;
    Prefs.setString(_kLast, '$bookId|$chapter|$bookName');
    notifyListeners();
  }

  void setFont(double size) {
    fontSize = size.clamp(15, 30).toDouble();
    Prefs.setDouble(_kFont, fontSize);
    notifyListeners();
  }

  void setFontFamily(String family) {
    fontFamily = family == 'Manrope' ? 'Manrope' : 'Lora';
    Prefs.setString('bible_font_family', fontFamily);
    notifyListeners();
  }

  void setPosition(SavedVerse verse) {
    lastVerse = verse.verse;
    Prefs.setInt('bible_last_verse', lastVerse);
    setLast(verse.bookId, verse.bookName, verse.chapter);
  }

  bool isSaved(int b, int c, int v) =>
      saved.any((s) => s.bookId == b && s.chapter == c && s.verse == v);

  /// Adds or removes; returns true when the verse is now saved.
  bool toggle(SavedVerse v) {
    final i = saved.indexWhere((s) => s.key == v.key);
    if (i >= 0) {
      saved.removeAt(i);
    } else {
      saved.insert(0, v);
    }
    Prefs.setList(_kSaved, [for (final s in saved) jsonEncode(s.toJson())]);
    notifyListeners();
    return i < 0;
  }
}
