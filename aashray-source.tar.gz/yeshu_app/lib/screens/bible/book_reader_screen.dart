import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/data/bible_reading_rules.dart';
import '../../core/data/bible_repo.dart';
import '../../core/theme.dart';
import 'bible_screen.dart';
import 'bible_selector.dart';
import 'bible_store.dart';
import 'book_pages.dart';

/// Real-book reading: printed paper pages that turn like a book.
/// Swipe or tap the right/left edge to turn; chapters flow on continuously.
class BookReaderScreen extends StatefulWidget {
  const BookReaderScreen({
    super.key,
    required this.bookId,
    required this.chapter,
    this.verse = 1,
  });
  final int bookId;
  final int chapter;
  final int verse;
  @override
  State<BookReaderScreen> createState() => _BookReaderScreenState();
}

typedef _Chapter = ({int bookId, int chapter, List<String> verses});

class _BookReaderScreenState extends State<BookReaderScreen>
    with SingleTickerProviderStateMixin {
  final List<_Chapter> _chapters = [];
  List<BookPage> _pages = const [];
  int _index = 0;
  int _generation = 0;
  bool _loading = true, _failed = false, _loadingMore = false;
  Size? _pageSize;
  String _layoutKey = '';
  late ({int bookId, int chapter, int verse}) _anchor = (
    bookId: widget.bookId,
    chapter: widget.chapter,
    verse: widget.verse,
  );

  // Turn animation: 0 = flat, 1 = fully turned. Forward turns the current
  // page away; backward brings the previous page back down.
  late final AnimationController _turn = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 520),
  );
  int _direction = 0; // 1 forward, -1 backward, 0 idle

  @override
  void initState() {
    super.initState();
    _open(widget.bookId, widget.chapter, widget.verse);
  }

  @override
  void dispose() {
    _turn.dispose();
    super.dispose();
  }

  String _name(int id) => BibleRepo.instance.book(id)?.name ?? 'Bible';

  Future<void> _open(int bookId, int chapter, int verse) async {
    final generation = ++_generation;
    setState(() {
      _loading = true;
      _failed = false;
      _chapters.clear();
      _pages = const [];
      _layoutKey = '';
      _anchor = (bookId: bookId, chapter: chapter, verse: verse);
    });
    try {
      final verses = await BibleRepo.instance.chapter(bookId, chapter);
      if (!mounted || generation != _generation) return;
      if (verses.isEmpty) throw StateError('empty chapter');
      _chapters.add((bookId: bookId, chapter: chapter, verses: verses));
      setState(() => _loading = false);
      _remember();
    } catch (_) {
      if (!mounted || generation != _generation) return;
      setState(() {
        _loading = false;
        _failed = true;
      });
    }
  }

  /// Rebuilds pages for the current size/font, keeping the reader's place.
  void _paginate(Size size) {
    final store = BibleStore.instance;
    final key =
        '${size.width.round()}x${size.height.round()}|${store.fontFamily}|${store.fontSize}|${_chapters.length}|${_chapters.isEmpty ? '' : '${_chapters.first.bookId}:${_chapters.first.chapter}'}';
    if (key == _layoutKey) return;
    _layoutKey = key;
    _pageSize = size;
    final style = bookTextStyle(store.fontFamily, store.fontSize);
    final pages = <BookPage>[
      for (final c in _chapters)
        ...paginateChapter(
          bookId: c.bookId,
          bookName: _name(c.bookId),
          chapter: c.chapter,
          verses: c.verses,
          width: size.width,
          height: size.height,
          style: style,
        ),
    ];
    var index = 0;
    for (var i = 0; i < pages.length; i++) {
      final p = pages[i];
      if (p.bookId == _anchor.bookId &&
          p.chapter == _anchor.chapter &&
          p.firstVerse <= _anchor.verse) {
        index = i;
      }
    }
    _pages = pages;
    _index = index.clamp(0, math.max(0, pages.length - 1));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _remember();
    });
  }

  void _remember() {
    if (_pages.isEmpty) return;
    final p = _pages[_index];
    _anchor = (bookId: p.bookId, chapter: p.chapter, verse: p.firstVerse);
    final store = BibleStore.instance;
    store.lastVerse = p.firstVerse;
    store.setLast(p.bookId, p.bookName, p.chapter);
    if (_pages.length - _index <= 3) _loadNext();
  }

  Future<void> _loadNext() async {
    if (_loadingMore || _chapters.isEmpty) return;
    final last = _chapters.last;
    final next = nextReadingPosition(
      BibleRepo.instance.books,
      last.bookId,
      last.chapter,
    );
    if (next == null) return;
    _loadingMore = true;
    final generation = _generation;
    try {
      final verses = await BibleRepo.instance.chapter(
        next.bookId,
        next.chapter,
      );
      if (!mounted || generation != _generation || verses.isEmpty) return;
      setState(() {
        _chapters.add((
          bookId: next.bookId,
          chapter: next.chapter,
          verses: verses,
        ));
        _layoutKey = '';
      });
    } catch (_) {
      // Retried on the next page turn.
    } finally {
      _loadingMore = false;
    }
  }

  Future<void> _loadPrevious() async {
    if (_loadingMore || _chapters.isEmpty) return;
    final first = _chapters.first;
    final books = BibleRepo.instance.books;
    ReadingPosition? prev;
    if (first.chapter > 1) {
      prev = (bookId: first.bookId, chapter: first.chapter - 1);
    } else {
      final i = books.indexWhere((b) => b.id == first.bookId);
      if (i > 0) prev = (bookId: books[i - 1].id, chapter: books[i - 1].chapters);
    }
    if (prev == null) return;
    _loadingMore = true;
    final generation = _generation;
    try {
      final verses = await BibleRepo.instance.chapter(
        prev.bookId,
        prev.chapter,
      );
      if (!mounted || generation != _generation || verses.isEmpty) return;
      setState(() {
        _chapters.insert(0, (
          bookId: prev!.bookId,
          chapter: prev.chapter,
          verses: verses,
        ));
        // Land on the last page of the previous chapter.
        _anchor = (bookId: prev.bookId, chapter: prev.chapter, verse: 1 << 20);
        _layoutKey = '';
      });
    } catch (_) {
    } finally {
      _loadingMore = false;
    }
  }

  // ------------------------------------------------------------ turning

  bool get _canForward => _index < _pages.length - 1;

  void _forward() {
    if (_turn.isAnimating || _direction != 0) return;
    if (!_canForward) {
      _loadNext();
      return;
    }
    HapticFeedback.selectionClick();
    _direction = 1;
    _turn.value = 0;
    _turn.animateTo(1, curve: Curves.easeInOutCubic).whenComplete(_finish);
  }

  void _backward() {
    if (_turn.isAnimating || _direction != 0) return;
    if (_index == 0) {
      _loadPrevious();
      return;
    }
    HapticFeedback.selectionClick();
    _direction = -1;
    _turn.value = 1;
    _turn.animateTo(0, curve: Curves.easeInOutCubic).whenComplete(_finish);
  }

  void _finish() {
    if (!mounted) return;
    setState(() {
      if (_direction == 1 && _turn.value >= .999) _index++;
      if (_direction == -1 && _turn.value <= .001) _index--;
      _direction = 0;
      _turn.value = 0;
    });
    _remember();
  }

  void _dragStart(DragStartDetails d) {}

  void _dragUpdate(DragUpdateDetails d) {
    final w = _pageSize?.width ?? 300;
    if (_direction == 0) {
      if (d.delta.dx < 0 && _canForward) {
        _direction = 1;
        _turn.value = 0;
      } else if (d.delta.dx > 0 && _index > 0) {
        _direction = -1;
        _turn.value = 1;
      } else {
        if (d.delta.dx < 0) _loadNext();
        if (d.delta.dx > 0) _loadPrevious();
        return;
      }
    }
    _turn.value = (_turn.value - d.delta.dx / (w * 1.1)).clamp(0.0, 1.0);
  }

  void _dragEnd(DragEndDetails d) {
    if (_direction == 0) return;
    final v = d.primaryVelocity ?? 0;
    final goForward = v < -300 || (v.abs() <= 300 && _turn.value > .5);
    final target = goForward ? 1.0 : 0.0;
    if (target == 1 && _direction == 1 || target == 0 && _direction == -1) {
      HapticFeedback.selectionClick();
    }
    _turn
        .animateTo(target, duration: const Duration(milliseconds: 300), curve: Curves.easeOut)
        .whenComplete(_finish);
  }

  // ------------------------------------------------------------ chrome

  Future<void> _select() async {
    final p = _pages.isEmpty ? null : _pages[_index];
    final choice = await selectBiblePassage(
      context,
      p?.bookId ?? _anchor.bookId,
      p?.chapter ?? _anchor.chapter,
    );
    if (choice == null || !mounted) return;
    _open(choice.bookId, choice.chapter, 1);
  }

  void _style() => showModalBottomSheet<void>(
    context: context,
    builder:
        (c) => SafeArea(
          child: ListenableBuilder(
            listenable: BibleStore.instance,
            builder: (_, _) {
              final s = BibleStore.instance;
              return Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'Reading style',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 14),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'Lora', label: Text('Serif')),
                        ButtonSegment(value: 'Manrope', label: Text('Modern')),
                      ],
                      selected: {s.fontFamily},
                      onSelectionChanged: (v) => s.setFontFamily(v.first),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        const Text('A', style: TextStyle(fontSize: 14)),
                        Expanded(
                          child: Slider(
                            value: s.fontSize,
                            min: 15,
                            max: 30,
                            divisions: 15,
                            onChanged: s.setFont,
                          ),
                        ),
                        const Text('A', style: TextStyle(fontSize: 24)),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ),
  );

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.paddingOf(context);
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: AppColors.bookDesk,
        body: ListenableBuilder(
          listenable: BibleStore.instance,
          builder: (context, _) {
            final p = _pages.isEmpty ? null : _pages[_index];
            return Column(
              children: [
                SizedBox(height: pad.top),
                _TopBar(
                  title: p == null
                      ? _name(_anchor.bookId)
                      : '${p.bookName} ${p.chapter}',
                  onBack: () => Navigator.maybePop(context),
                  onSelect: _select,
                  onStyle: _style,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 2, 14, 10),
                    child: _book(),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(bottom: pad.bottom + 10),
                  child: Text(
                    _pages.isEmpty
                        ? ' '
                        : 'Swipe or tap the edge to turn the page',
                    style: TextStyle(
                      fontSize: 11.5,
                      color: AppColors.bookPaper.withValues(alpha: .6),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _book() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.imageGold),
      );
    }
    if (_failed) {
      return Center(
        child: FilledButton(
          onPressed: () => _open(_anchor.bookId, _anchor.chapter, _anchor.verse),
          child: const Text('Retry Bible'),
        ),
      );
    }
    return LayoutBuilder(
      builder: (context, box) {
        const inner = EdgeInsets.fromLTRB(30, 34, 24, 46);
        _paginate(Size(box.maxWidth - inner.horizontal, box.maxHeight - inner.vertical));
        if (_pages.isEmpty) return const SizedBox.shrink();
        Widget page(int i) => _PaperPage(
          page: _pages[i],
          number: i + 1,
          padding: inner,
        );
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onHorizontalDragStart: _dragStart,
          onHorizontalDragUpdate: _dragUpdate,
          onHorizontalDragEnd: _dragEnd,
          onTapUp: (d) {
            final x = d.localPosition.dx / box.maxWidth;
            if (x > .62) _forward();
            if (x < .38) _backward();
          },
          child: AnimatedBuilder(
            animation: _turn,
            builder: (context, _) {
              final t = _turn.value;
              final turning = _direction != 0;
              // Page underneath and the page currently lifting.
              final int under, top;
              if (_direction == -1) {
                under = _index;
                top = _index - 1;
              } else {
                under = math.min(_index + 1, _pages.length - 1);
                top = _index;
              }
              return Stack(
                fit: StackFit.expand,
                children: [
                  // Stacked page edges: the thickness of the book.
                  for (var k = 3; k >= 1; k--)
                    Transform.translate(
                      offset: Offset(k * 2.0, k * 1.5),
                      child: const DecoratedBox(
                        decoration: BoxDecoration(
                          color: AppColors.bookPaperEdge,
                          borderRadius: BorderRadius.horizontal(
                            right: Radius.circular(6),
                          ),
                        ),
                      ),
                    ),
                  if (turning) page(under),
                  if (turning)
                    // Shadow the lifting page casts on the one underneath.
                    IgnorePointer(
                      child: ColoredBox(
                        color: AppColors.scrim.withValues(
                          alpha: (1 - t) * .18,
                        ),
                      ),
                    ),
                  if (turning)
                    _TurningPage(progress: t, child: page(top))
                  else
                    page(_index),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

/// Rotates a page around the spine (left edge) like a real leaf.
class _TurningPage extends StatelessWidget {
  const _TurningPage({required this.progress, required this.child});
  final double progress;
  final Widget child;
  @override
  Widget build(BuildContext context) {
    final angle = -progress * math.pi / 2;
    return Transform(
      alignment: Alignment.centerLeft,
      transform: Matrix4.identity()
        ..setEntry(3, 2, 0.0011)
        ..rotateY(angle),
      child: Stack(
        fit: StackFit.expand,
        children: [
          child,
          // The leaf darkens as it lifts towards the reader.
          IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppColors.scrim.withValues(alpha: progress * .05),
                    AppColors.scrim.withValues(alpha: progress * .35),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PaperPage extends StatelessWidget {
  const _PaperPage({
    required this.page,
    required this.number,
    required this.padding,
  });
  final BookPage page;
  final int number;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    final store = BibleStore.instance;
    final style = bookTextStyle(store.fontFamily, store.fontSize);
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.horizontal(right: Radius.circular(6)),
        gradient: const LinearGradient(
          // Gutter shading near the spine, like an open book.
          colors: [
            AppColors.bookPaperEdge,
            AppColors.bookPaper,
            AppColors.bookPaper,
          ],
          stops: [0, .06, 1],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.scrim.withValues(alpha: .35),
            blurRadius: 18,
            offset: const Offset(2, 6),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: 12,
            left: padding.left,
            right: padding.right,
            child: Row(
              children: [
                Text(
                  page.bookName.toUpperCase(),
                  style: const TextStyle(
                    fontSize: 9.5,
                    letterSpacing: 1.6,
                    fontWeight: FontWeight.w700,
                    color: AppColors.bookRed,
                  ),
                ),
                const Spacer(),
                Text(
                  'Chapter ${page.chapter}',
                  style: TextStyle(
                    fontSize: 9.5,
                    letterSpacing: .6,
                    color: AppColors.bookInk.withValues(alpha: .55),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: padding,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (page.firstOfChapter)
                  SizedBox(
                    height: chapterHeadingHeight(store.fontSize),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          page.chapter == 1
                              ? page.bookName
                              : 'Chapter',
                          style: TextStyle(
                            fontFamily: 'Lora',
                            fontSize: store.fontSize * .78,
                            fontStyle: FontStyle.italic,
                            color: AppColors.bookInk.withValues(alpha: .7),
                          ),
                        ),
                        Text(
                          '${page.chapter}',
                          style: TextStyle(
                            fontFamily: 'Lora',
                            fontSize: store.fontSize * 2.3,
                            height: 1.1,
                            fontWeight: FontWeight.w600,
                            color: AppColors.bookRed,
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(top: 6),
                          width: 34,
                          height: 1,
                          color: AppColors.bookRed.withValues(alpha: .5),
                        ),
                      ],
                    ),
                  ),
                Text.rich(
                  TextSpan(
                    children: [
                      for (final v in page.verses)
                        verseSpan(v, style, AppColors.bookRed),
                    ],
                  ),
                  textAlign: TextAlign.justify,
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 16,
            left: 0,
            right: 0,
            child: Text(
              '— $number —',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Lora',
                fontSize: 11,
                color: AppColors.bookInk.withValues(alpha: .5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.title,
    required this.onBack,
    required this.onSelect,
    required this.onStyle,
  });
  final String title;
  final VoidCallback onBack, onSelect, onStyle;
  @override
  Widget build(BuildContext context) {
    const ink = AppColors.bookPaper;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 4),
      child: Row(
        children: [
          if (Navigator.canPop(context))
            IconButton(
              tooltip: 'Back',
              onPressed: onBack,
              icon: const Icon(Icons.arrow_back_rounded, color: ink),
            ),
          Expanded(
            child: TextButton(
              onPressed: onSelect,
              style: TextButton.styleFrom(
                foregroundColor: ink,
                alignment: Alignment.centerLeft,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: Text(
                      title,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: 'Lora',
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const Icon(Icons.expand_more_rounded, size: 20),
                ],
              ),
            ),
          ),
          IconButton(
            tooltip: 'Scroll mode',
            onPressed: () => BibleStore.instance.setReadMode('scroll'),
            icon: const Icon(Icons.view_day_outlined, color: ink),
          ),
          IconButton(
            tooltip: 'Saved verses',
            onPressed:
                () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const SavedVersesScreen(),
                  ),
                ),
            icon: const Icon(Icons.bookmarks_outlined, color: ink),
          ),
          IconButton(
            tooltip: 'Reading style',
            onPressed: onStyle,
            icon: const Icon(Icons.text_fields_rounded, color: ink),
          ),
        ],
      ),
    );
  }
}
