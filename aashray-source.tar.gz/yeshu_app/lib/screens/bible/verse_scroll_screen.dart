import 'package:flutter/material.dart';
import '../../core/data/bible_repo.dart';
import '../../core/data/bible_reading_rules.dart';
import '../../core/data/catalog.dart';
import '../../core/share_helper.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../status/status_viewer.dart';
import 'bible_store.dart';
import 'bible_selector.dart';
import 'bible_screen.dart';

class VerseScrollScreen extends StatefulWidget {
  const VerseScrollScreen({
    super.key,
    required this.bookId,
    required this.chapter,
    this.verse = 1,
  });
  final int bookId, chapter, verse;
  @override
  State<VerseScrollScreen> createState() => _VerseScrollScreenState();
}

class _VerseScrollScreenState extends State<VerseScrollScreen> {
  final List<SavedVerse> _items = [];
  late PageController _pages;
  int _index = 0;
  int _generation = 0;
  int _book = 0;
  int _chapter = 1;
  bool _loading = false;
  bool _failed = false;
  bool _ended = false;
  SavedVerse? get _current => _items.isEmpty ? null : _items[_index];
  @override
  void initState() {
    super.initState();
    _pages = PageController();
    _open(widget.bookId, widget.chapter, widget.verse);
  }

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  Future<void> _open(int book, int chapter, int verse) async {
    final generation = ++_generation;
    setState(() {
      _items.clear();
      _index = 0;
      _book = book;
      _chapter = chapter;
      _loading = true;
      _failed = false;
      _ended = false;
    });
    try {
      final texts = await BibleRepo.instance.chapter(book, chapter);
      if (!mounted || generation != _generation) return;
      if (texts.isEmpty) throw StateError('No verses');
      final name = BibleRepo.instance.book(book)?.name ?? '';
      final start = (verse - 1).clamp(0, texts.length - 1);
      final old = _pages;
      setState(() {
        _pages = PageController(initialPage: start);
        _index = start;
        _items.addAll([
          for (var i = 0; i < texts.length; i++)
            SavedVerse(
              bookId: book,
              bookName: name,
              chapter: chapter,
              verse: i + 1,
              text: texts[i],
            ),
        ]);
        _loading = false;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
      BibleStore.instance.setPosition(_items[start]);
      if (_items.length - start <= 4) _loadNext();
    } catch (_) {
      if (!mounted || generation != _generation) return;
      setState(() {
        _loading = false;
        _failed = true;
      });
    }
  }

  Future<void> _loadNext() async {
    if (_loading || _failed || _ended || _items.isEmpty) return;
    final last = _items.last;
    final next = nextReadingPosition(
      BibleRepo.instance.books,
      last.bookId,
      last.chapter,
    );
    if (next == null) {
      setState(() => _ended = true);
      return;
    }
    final generation = _generation;
    setState(() => _loading = true);
    try {
      final texts = await BibleRepo.instance.chapter(next.bookId, next.chapter);
      if (!mounted || generation != _generation) return;
      if (texts.isEmpty) throw StateError('No verses');
      final name = BibleRepo.instance.book(next.bookId)?.name ?? '';
      setState(() {
        _items.addAll([
          for (var i = 0; i < texts.length; i++)
            SavedVerse(
              bookId: next.bookId,
              bookName: name,
              chapter: next.chapter,
              verse: i + 1,
              text: texts[i],
            ),
        ]);
        _loading = false;
      });
    } catch (_) {
      if (!mounted || generation != _generation) return;
      setState(() {
        _loading = false;
        _failed = true;
      });
    }
  }

  Future<void> _select() async {
    final current = _current;
    final choice = await selectBiblePassage(
      context,
      current?.bookId ?? _book,
      current?.chapter ?? _chapter,
    );
    if (choice == null || !mounted) return;
    _open(choice.bookId, choice.chapter, 1);
  }

  void _fonts() => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder:
        (context) => SafeArea(
          child: ListenableBuilder(
            listenable: BibleStore.instance,
            builder: (_, _) {
              final store = BibleStore.instance;
              return SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Reading style',
                              style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'Close',
                            onPressed: () => Navigator.pop(context),
                            icon: const Icon(Icons.close_rounded),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      SegmentedButton<String>(
                        showSelectedIcon: false,
                        segments: const [
                          ButtonSegment(
                            value: 'Lora',
                            label: Text(
                              'Serif',
                              style: TextStyle(fontFamily: 'Lora'),
                            ),
                          ),
                          ButtonSegment(
                            value: 'Manrope',
                            label: Text('Modern'),
                          ),
                        ],
                        selected: {store.fontFamily},
                        onSelectionChanged: (s) => store.setFontFamily(s.first),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          const Text(
                            'Text size',
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                          const Spacer(),
                          Text(
                            '${store.fontSize.round()}',
                            style: const TextStyle(color: AppColors.muted),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          IconButton(
                            tooltip: 'Smaller text',
                            onPressed: () => store.setFont(store.fontSize - 1),
                            icon: const Icon(Icons.text_decrease_rounded),
                          ),
                          Expanded(
                            child: Slider(
                              value: store.fontSize,
                              min: 15,
                              max: 30,
                              divisions: 15,
                              onChanged: store.setFont,
                            ),
                          ),
                          IconButton(
                            tooltip: 'Larger text',
                            onPressed: () => store.setFont(store.fontSize + 1),
                            icon: const Icon(Icons.text_increase_rounded),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppColors.paperDeep,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          _current?.text ??
                              'The Lord is my shepherd; I shall not want.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: store.fontFamily,
                            fontSize: store.fontSize,
                            height: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.scrim,
    body: ListenableBuilder(
      listenable: BibleStore.instance,
      builder:
          (context, _) => Stack(
            children: [
              if (_items.isNotEmpty)
                PageView.builder(
                  key: ValueKey(_generation),
                  controller: _pages,
                  scrollDirection: Axis.vertical,
                  itemCount: _items.length,
                  onPageChanged: (i) {
                    setState(() => _index = i);
                    BibleStore.instance.setPosition(_items[i]);
                    if (_items.length - i <= 4) _loadNext();
                  },
                  itemBuilder:
                      (_, i) =>
                          _VerseSlide(verse: _items[i], active: i == _index),
                )
              else ...[
                Positioned.fill(
                  child: Image.asset(
                    'assets/images/verse_garden.jpg',
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned.fill(
                  child: ColoredBox(
                    color: AppColors.scrim.withValues(alpha: .6),
                  ),
                ),
                Center(
                  child:
                      _failed
                          ? TextButton(
                            onPressed: () => _open(_book, _chapter, 1),
                            child: const Text(
                              'Retry Bible',
                              style: TextStyle(color: AppColors.imageInk),
                            ),
                          )
                          : const CircularProgressIndicator(
                            color: AppColors.imageInk,
                          ),
                ),
              ],
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
                  child: Row(
                    children: [
                      _OverlayIcon(
                        icon: Icons.arrow_back_rounded,
                        label: 'Back',
                        onTap: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextButton(
                          onPressed: _select,
                          style: TextButton.styleFrom(
                            foregroundColor: AppColors.imageInk,
                            alignment: Alignment.centerLeft,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: Text(
                                  '${_current?.bookName ?? BibleRepo.instance.book(_book)?.name ?? 'Bible'} ${_current?.chapter ?? _chapter}',
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              const Icon(Icons.expand_more_rounded, size: 20),
                            ],
                          ),
                        ),
                      ),
                      _OverlayIcon(
                        icon: Icons.bookmarks_outlined,
                        label: 'Saved verses',
                        onTap:
                            () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(
                                builder: (_) => const SavedVersesScreen(),
                              ),
                            ),
                      ),
                      const SizedBox(width: 6),
                      _OverlayIcon(
                        icon: Icons.text_fields_rounded,
                        label: 'Reading style',
                        onTap: _fonts,
                      ),
                    ],
                  ),
                ),
              ),
              if (_current case final current?)
                Positioned(
                  bottom: MediaQuery.paddingOf(context).bottom + 20,
                  left: 24,
                  right: 24,
                  child: Row(
                    children: [
                      Text(
                        'KJV · ${current.chapter}:${current.verse}',
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: AppColors.imageSoft,
                        ),
                      ),
                      const Spacer(),
                      _OverlayIcon(
                        icon:
                            BibleStore.instance.isSaved(
                                  current.bookId,
                                  current.chapter,
                                  current.verse,
                                )
                                ? Icons.bookmark_rounded
                                : Icons.bookmark_border_rounded,
                        label:
                            BibleStore.instance.isSaved(
                                  current.bookId,
                                  current.chapter,
                                  current.verse,
                                )
                                ? 'Unsave verse'
                                : 'Save verse',
                        onTap: () => BibleStore.instance.toggle(current),
                      ),
                      const SizedBox(width: 10),
                      _OverlayIcon(
                        icon: Icons.ios_share_outlined,
                        label: 'Share verse',
                        onTap:
                            () => ShareHelper.shareText(
                              '“${current.text}” — ${current.reference} (KJV)\n\n${ShareHelper.appLine}',
                            ),
                      ),
                      const SizedBox(width: 10),
                      _OverlayIcon(
                        icon: Icons.add_photo_alternate_outlined,
                        label: 'Make status picture',
                        onTap:
                            () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(
                                builder:
                                    (_) => StatusViewer.single(
                                      text: current.text,
                                      reference: '${current.reference} (KJV)',
                                      greeting: 'Word of God',
                                    ),
                              ),
                            ),
                      ),
                    ],
                  ),
                ),
              if (_failed && _items.isNotEmpty)
                Positioned(
                  bottom: 84,
                  left: 24,
                  right: 24,
                  child: Center(
                    child: TextButton(
                      onPressed: () {
                        setState(() => _failed = false);
                        _loadNext();
                      },
                      child: const Text(
                        'Retry next chapter',
                        style: TextStyle(color: AppColors.imageInk),
                      ),
                    ),
                  ),
                ),
            ],
          ),
    ),
  );
}

class _OverlayIcon extends StatelessWidget {
  const _OverlayIcon({
    required this.icon,
    required this.label,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => IconButton.filled(
    tooltip: label,
    onPressed: onTap,
    style: IconButton.styleFrom(
      backgroundColor: AppColors.scrim.withValues(alpha: .3),
      foregroundColor: AppColors.imageInk,
      fixedSize: const Size(42, 42),
    ),
    icon: Icon(icon, size: 21),
  );
}

class _VerseSlide extends StatelessWidget {
  const _VerseSlide({required this.verse, required this.active});
  final SavedVerse verse;
  final bool active;
  @override
  Widget build(BuildContext context) {
    final store = BibleStore.instance;
    final image = Catalog.statusBackground(verse.bookId * 7 + verse.chapter);
    return Stack(
      fit: StackFit.expand,
      children: [
        if (image.isEmpty)
          Image.asset('assets/images/verse_garden.jpg', fit: BoxFit.cover)
        else
          NetImage(image, memWidth: 1400),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.scrim.withValues(alpha: .5),
                AppColors.scrim.withValues(alpha: .35),
                AppColors.scrim.withValues(alpha: .82),
              ],
              stops: const [0, .4, 1],
            ),
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(28, 80, 28, 94),
            child: LayoutBuilder(
              builder:
                  (context, bounds) => Center(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        maxWidth: 600,
                        maxHeight: bounds.maxHeight,
                      ),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const CrossMark(
                              size: 25,
                              color: AppColors.imageGold,
                            ),
                            const SizedBox(height: 26),
                            Text(
                              verse.text,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: store.fontFamily,
                                fontSize: store.fontSize + 5,
                                color: AppColors.imageInk,
                                height: 1.55,
                              ),
                            ),
                            const SizedBox(height: 24),
                            Container(
                              width: 26,
                              height: 1,
                              color: AppColors.imageGold,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              verse.reference,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: AppColors.imageGold,
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
            ),
          ),
        ),
      ],
    );
  }
}
