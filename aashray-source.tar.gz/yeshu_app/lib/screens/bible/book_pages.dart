import 'package:flutter/painting.dart';

/// One verse (or the part of a verse) printed on a book page.
class PageVerse {
  const PageVerse(this.number, this.text, {this.continued = false});
  final int number;
  final String text;

  /// True when this is the rest of a verse started on the previous page.
  final bool continued;
}

/// A printed page of one chapter.
class BookPage {
  const BookPage({
    required this.bookId,
    required this.bookName,
    required this.chapter,
    required this.verses,
    required this.firstOfChapter,
  });
  final int bookId;
  final String bookName;
  final int chapter;
  final List<PageVerse> verses;
  final bool firstOfChapter;
  int get firstVerse => verses.isEmpty ? 1 : verses.first.number;
}

/// Space the chapter heading takes on a chapter's first page.
double chapterHeadingHeight(double fontSize) => fontSize * 5.2;

/// Text style used for both measuring and painting, so pages never overflow.
TextStyle bookTextStyle(String family, double size) => TextStyle(
  fontFamily: family,
  fontSize: size,
  height: 1.62,
  color: const Color(0xFF2B2117),
);

InlineSpan verseSpan(PageVerse v, TextStyle style, Color numberColor) =>
    TextSpan(
      children: [
        if (!v.continued)
          TextSpan(
            text: '${v.number} ',
            style: style.copyWith(
              fontSize: style.fontSize! * .62,
              fontWeight: FontWeight.w700,
              color: numberColor,
            ),
          ),
        TextSpan(text: '${v.text} ', style: style),
      ],
    );

/// Splits a chapter into pages that each fit [width] x [height].
/// Long verses continue on the next page, so no text is ever lost.
List<BookPage> paginateChapter({
  required int bookId,
  required String bookName,
  required int chapter,
  required List<String> verses,
  required double width,
  required double height,
  required TextStyle style,
}) {
  final pages = <BookPage>[];
  if (width <= 40 || height <= 40) return pages;
  var current = <PageVerse>[];
  bool fits(List<PageVerse> list, bool first) {
    final painter = TextPainter(
      text: TextSpan(
        children: [for (final v in list) verseSpan(v, style, style.color!)],
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.justify,
    )..layout(maxWidth: width);
    final room = first ? height - chapterHeadingHeight(style.fontSize!) : height;
    final h = painter.height;
    painter.dispose();
    return h <= room;
  }

  void flush() {
    pages.add(
      BookPage(
        bookId: bookId,
        bookName: bookName,
        chapter: chapter,
        verses: current,
        firstOfChapter: pages.isEmpty,
      ),
    );
    current = <PageVerse>[];
  }

  for (var i = 0; i < verses.length; i++) {
    var piece = PageVerse(i + 1, verses[i].trim());
    while (true) {
      final first = pages.isEmpty;
      if (fits([...current, piece], first)) {
        current.add(piece);
        break;
      }
      // Fit as many words of this verse as possible, continue the rest.
      final words = piece.text.split(' ');
      var lo = 0, hi = words.length - 1;
      while (lo < hi) {
        final mid = (lo + hi + 1) ~/ 2;
        final part = PageVerse(
          piece.number,
          words.take(mid).join(' '),
          continued: piece.continued,
        );
        if (fits([...current, part], first)) {
          lo = mid;
        } else {
          hi = mid - 1;
        }
      }
      if (lo == 0 && current.isEmpty) lo = 1; // never loop forever
      if (lo > 0) {
        current.add(
          PageVerse(
            piece.number,
            words.take(lo).join(' '),
            continued: piece.continued,
          ),
        );
      }
      flush();
      if (lo >= words.length) break;
      piece = PageVerse(
        piece.number,
        words.skip(lo).join(' '),
        continued: true,
      );
    }
  }
  if (current.isNotEmpty || pages.isEmpty) flush();
  return pages;
}
