import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/data/bible_repo.dart';
import '../../core/data/bible_reading_rules.dart';
import 'bible_screen.dart';
import '../../core/share_helper.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../status/status_viewer.dart';
import 'bible_store.dart';

/// Chapter reader: verse numbers, adjustable text size, previous / next
/// chapter, and per-verse actions (save, copy, share, make status).
class ChapterScreen extends StatefulWidget {
  const ChapterScreen({
    super.key,
    required this.bookId,
    required this.chapter,
    this.highlightVerse,
  });

  final int bookId;
  final int chapter;
  final int? highlightVerse;

  @override
  State<ChapterScreen> createState() => _ChapterScreenState();
}

class _ChapterScreenState extends State<ChapterScreen> {
  late int _bookId = widget.bookId;
  late int _chapter = widget.chapter;
  late int? _highlight = widget.highlightVerse;
  late Future<List<String>> _verses;
  final _scroll = ScrollController();
  final List<({int bookId, int chapter, List<String> verses})> _following = [];
  bool _loadingMore = false;
  bool _moreFailed = false;
  int _generation = 0;

  BibleBook get _book =>
      BibleRepo.instance.book(_bookId) ??
      const BibleBook(id: 0, name: 'Genesis', chapters: 50);

  @override
  void initState() {
    super.initState();
    _open();
    _scroll.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _open() {
    _generation++;
    _following.clear();
    _loadingMore = false;
    _moreFailed = false;
    _verses = BibleRepo.instance.chapter(_bookId, _chapter);
    BibleStore.instance.setLast(_bookId, _book.name, _chapter);
  }

  void _onScroll() {
    if (_scroll.hasClients && _scroll.position.extentAfter < 700) _loadMore();
  }

  Future<void> _loadMore() async {
    if (_loadingMore || _moreFailed) return;
    final last =
        _following.isEmpty
            ? (bookId: _bookId, chapter: _chapter)
            : (
              bookId: _following.last.bookId,
              chapter: _following.last.chapter,
            );
    final next = nextReadingPosition(
      BibleRepo.instance.books,
      last.bookId,
      last.chapter,
    );
    if (next == null) return;
    final generation = _generation;
    setState(() => _loadingMore = true);
    try {
      final verses = await BibleRepo.instance.chapter(
        next.bookId,
        next.chapter,
      );
      if (!mounted || generation != _generation) return;
      if (verses.isEmpty) throw StateError('Empty chapter');
      setState(() {
        _following.add((
          bookId: next.bookId,
          chapter: next.chapter,
          verses: verses,
        ));
        _loadingMore = false;
      });
    } catch (_) {
      if (!mounted || generation != _generation) return;
      setState(() {
        _loadingMore = false;
        _moreFailed = true;
      });
    }
  }

  void _selectChapter() {
    var selectedBook = _bookId;
    var selectedChapter = _chapter;
    showModalBottomSheet<ReadingPosition>(
      context: context,
      isScrollControlled: true,
      builder:
          (sheet) => StatefulBuilder(
            builder: (context, update) {
              final book = BibleRepo.instance.book(selectedBook) ?? _book;
              return SafeArea(
                child: SizedBox(
                  height: MediaQuery.sizeOf(context).height * .72,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 12, 12),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Book & chapter',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            IconButton(
                              tooltip: 'Close',
                              onPressed: () => Navigator.pop(sheet),
                              icon: const Icon(Icons.close_rounded),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: ListView.builder(
                                itemCount: BibleRepo.instance.books.length,
                                itemBuilder: (_, i) {
                                  final b = BibleRepo.instance.books[i];
                                  return ListTile(
                                    selected: selectedBook == b.id,
                                    selectedTileColor: AppColors.accentSoft,
                                    dense: true,
                                    title: Text(
                                      b.name,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    onTap:
                                        () => update(() {
                                          selectedBook = b.id;
                                          selectedChapter = 1;
                                        }),
                                  );
                                },
                              ),
                            ),
                            const VerticalDivider(width: 1),
                            Expanded(
                              child: GridView.builder(
                                padding: const EdgeInsets.all(12),
                                gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 3,
                                      mainAxisSpacing: 8,
                                      crossAxisSpacing: 8,
                                    ),
                                itemCount: book.chapters,
                                itemBuilder:
                                    (_, i) => Material(
                                      color:
                                          selectedChapter == i + 1
                                              ? AppColors.accent
                                              : AppColors.paperDeep,
                                      borderRadius: BorderRadius.circular(8),
                                      child: InkWell(
                                        onTap:
                                            () => update(
                                              () => selectedChapter = i + 1,
                                            ),
                                        borderRadius: BorderRadius.circular(8),
                                        child: Center(
                                          child: Text(
                                            '${i + 1}',
                                            style: TextStyle(
                                              fontWeight: FontWeight.w700,
                                              color:
                                                  selectedChapter == i + 1
                                                      ? AppColors.onPrimary
                                                      : AppColors.ink,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed:
                                () => Navigator.pop(sheet, (
                                  bookId: selectedBook,
                                  chapter: selectedChapter,
                                )),
                            child: Text('Read ${book.name} $selectedChapter'),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
    ).then((position) {
      if (position == null || !mounted) return;
      setState(() {
        _bookId = position.bookId;
        _chapter = position.chapter;
        _highlight = null;
        _open();
      });
      if (_scroll.hasClients) _scroll.jumpTo(0);
    });
  }

  void _verseActions(int number, String text, {int? bookId, int? chapter}) {
    final actionBookId = bookId ?? _bookId;
    final actionChapter = chapter ?? _chapter;
    final actionBook = BibleRepo.instance.book(actionBookId) ?? _book;
    final ref = '${actionBook.name} $actionChapter:$number';
    final saved = BibleStore.instance.isSaved(
      actionBookId,
      actionChapter,
      number,
    );
    setState(() => _highlight = number);
    showModalBottomSheet<void>(
      context: context,
      builder:
          (c) => SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(22, 0, 22, 10),
                  child: Column(
                    children: [
                      Text(
                        ref,
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          color: AppColors.primary,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        text,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: AppTheme.serif,
                          color: AppColors.inkSoft,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                SheetOption(
                  icon:
                      saved
                          ? Icons.bookmark_remove_rounded
                          : Icons.bookmark_add_rounded,
                  title: saved ? 'Remove from saved' : 'Save verse',
                  tint: AppColors.teal,
                  onTap: () {
                    Navigator.pop(c);
                    final now = BibleStore.instance.toggle(
                      SavedVerse(
                        bookId: actionBookId,
                        bookName: actionBook.name,
                        chapter: actionChapter,
                        verse: number,
                        text: text,
                      ),
                    );
                    toast(context, now ? 'Saved' : 'Removed from saved');
                  },
                ),
                SheetOption(
                  icon: Icons.auto_awesome_rounded,
                  title: 'Make status picture',
                  tint: AppColors.rose,
                  onTap: () {
                    Navigator.pop(c);
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder:
                            (_) => StatusViewer.single(
                              text: text,
                              reference: '$ref (KJV)',
                              greeting: 'Word of God',
                            ),
                      ),
                    );
                  },
                ),
                SheetOption(
                  icon: Icons.copy_rounded,
                  title: 'Copy',
                  tint: AppColors.inkSoft,
                  onTap: () {
                    Navigator.pop(c);
                    Clipboard.setData(
                      ClipboardData(text: '“$text” — $ref (KJV)'),
                    );
                    toast(context, 'Copied');
                  },
                ),
                SheetOption(
                  icon: Icons.share_rounded,
                  title: 'Share',
                  onTap: () {
                    Navigator.pop(c);
                    ShareHelper.shareText(
                      '“$text” — $ref (KJV)\n\n${ShareHelper.appLine}',
                    );
                  },
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
    ).whenComplete(() {
      if (mounted) setState(() => _highlight = null);
    });
  }

  void _fontSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder:
          (c) => SafeArea(
            child: ListenableBuilder(
              listenable: BibleStore.instance,
              builder: (context, _) {
                final size = BibleStore.instance.fontSize;
                return Padding(
                  padding: const EdgeInsets.fromLTRB(22, 0, 22, 22),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'Text size',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 17,
                        ),
                      ),
                      Row(
                        children: [
                          const Text('A', style: TextStyle(fontSize: 15)),
                          Expanded(
                            child: Slider(
                              value: size,
                              min: 15,
                              max: 30,
                              divisions: 15,
                              onChanged: BibleStore.instance.setFont,
                            ),
                          ),
                          const Text('A', style: TextStyle(fontSize: 26)),
                        ],
                      ),
                      Text(
                        'In the beginning God created the heaven and the earth.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: AppTheme.serif,
                          fontSize: size,
                          height: 1.6,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final book = _book;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: TextButton(
          onPressed: _selectChapter,
          style: TextButton.styleFrom(foregroundColor: AppColors.ink),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '${book.name} $_chapter',
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                ),
              ),
              const SizedBox(width: 4),
              const Icon(Icons.expand_more_rounded, size: 20),
            ],
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Saved verses',
            onPressed:
                () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const SavedVersesScreen(),
                  ),
                ),
            icon: const Icon(Icons.bookmarks_outlined, size: 21),
          ),
          IconButton(
            tooltip: 'Text size',
            onPressed: _fontSheet,
            icon: const Icon(Icons.text_fields_rounded),
          ),
        ],
      ),
      body: ContentWidth(
        child: FutureBuilder<List<String>>(
          future: _verses,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            final verses = snap.data ?? const [];
            if (snap.hasError || verses.isEmpty) {
              return Center(
                child: TextButton(
                  onPressed: () => setState(_open),
                  child: const Text(
                    'Could not open this chapter. Tap to retry.',
                  ),
                ),
              );
            }
            return ListenableBuilder(
              listenable: BibleStore.instance,
              builder: (context, _) {
                final size = BibleStore.instance.fontSize;
                final sections = [
                  (bookId: _bookId, chapter: _chapter, verses: verses),
                  ..._following,
                ];
                return ListView(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
                  children: [
                    const Text(
                      'KING JAMES VERSION',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 10,
                        color: AppColors.muted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    for (final section in sections) ...[
                      Padding(
                        padding: const EdgeInsets.only(top: 28, bottom: 22),
                        child: Column(
                          children: [
                            const CrossMark(size: 20),
                            const SizedBox(height: 16),
                            Text(
                              BibleRepo.instance.book(section.bookId)?.name ??
                                  '',
                              style: const TextStyle(
                                fontFamily: AppTheme.serif,
                                fontSize: 29,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Chapter ${section.chapter}',
                              style: const TextStyle(
                                color: AppColors.primary,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                      for (var n = 1; n <= section.verses.length; n++)
                        InkWell(
                          onTap:
                              () => _verseActions(
                                n,
                                section.verses[n - 1],
                                bookId: section.bookId,
                                chapter: section.chapter,
                              ),
                          borderRadius: BorderRadius.circular(8),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: 7,
                              horizontal: 3,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  BibleStore.instance.isSaved(
                                        section.bookId,
                                        section.chapter,
                                        n,
                                      )
                                      ? AppColors.goldSoft
                                      : (_highlight == n &&
                                              section.bookId == _bookId &&
                                              section.chapter == _chapter
                                          ? AppColors.accentSoft
                                          : null),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text.rich(
                              TextSpan(
                                children: [
                                  TextSpan(
                                    text: '$n  ',
                                    style: TextStyle(
                                      fontFamily: 'Manrope',
                                      fontSize: size * .58,
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  TextSpan(text: section.verses[n - 1]),
                                ],
                              ),
                              style: TextStyle(
                                fontFamily: AppTheme.serif,
                                fontSize: size,
                                height: 1.8,
                                color: AppColors.ink,
                              ),
                            ),
                          ),
                        ),
                    ],
                    if (_loadingMore)
                      const Padding(
                        padding: EdgeInsets.all(20),
                        child: Center(
                          child: SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        ),
                      ),
                    if (_moreFailed)
                      TextButton(
                        onPressed: () {
                          setState(() => _moreFailed = false);
                          _loadMore();
                        },
                        child: const Text('Retry next chapter'),
                      ),
                    if (!_loadingMore && !_moreFailed)
                      Padding(
                        padding: const EdgeInsets.only(top: 24),
                        child: TextButton.icon(
                          onPressed: _loadMore,
                          icon: const Icon(
                            Icons.arrow_downward_rounded,
                            size: 18,
                          ),
                          label: const Text('Continue reading'),
                        ),
                      ),
                  ],
                );
              },
            );
          },
        ),
      ),
    );
  }
}
