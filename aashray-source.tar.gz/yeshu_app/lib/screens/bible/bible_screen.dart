import 'package:flutter/material.dart';
import '../../core/data/bible_reading_rules.dart';
import '../../core/data/bible_repo.dart';
import '../../core/theme.dart';
import 'bible_store.dart';
import 'verse_scroll_screen.dart';

class BibleScreen extends StatelessWidget {
  const BibleScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final store = BibleStore.instance;
    final position = initialReadingPosition(
      BibleRepo.instance.books,
      store.lastBook,
      store.lastChapter,
    );
    return VerseScrollScreen(
      bookId: position.bookId,
      chapter: position.chapter,
      verse: store.lastVerse,
    );
  }
}

class SavedVersesScreen extends StatelessWidget {
  const SavedVersesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Saved verses')),
      body: ListenableBuilder(
        listenable: BibleStore.instance,
        builder: (context, _) {
          final saved = BibleStore.instance.saved;
          if (saved.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Tap any verse while reading and choose “Save” to keep it here.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppColors.muted,
                    fontSize: 15.5,
                    height: 1.4,
                  ),
                ),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.symmetric(vertical: 8),
            itemCount: saved.length,
            separatorBuilder:
                (_, _) => const Divider(indent: 20, endIndent: 20),
            itemBuilder: (context, i) {
              final v = saved[i];
              return ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 6,
                ),
                title: Text(
                  v.text,
                  style: const TextStyle(
                    fontFamily: AppTheme.serif,
                    fontSize: 16.5,
                    height: 1.45,
                  ),
                ),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    v.reference,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      color: AppColors.primary,
                    ),
                  ),
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.bookmark_remove_outlined),
                  onPressed: () => BibleStore.instance.toggle(v),
                ),
                onTap:
                    () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder:
                            (_) => VerseScrollScreen(
                              bookId: v.bookId,
                              chapter: v.chapter,
                              verse: v.verse,
                            ),
                      ),
                    ),
              );
            },
          );
        },
      ),
    );
  }
}
