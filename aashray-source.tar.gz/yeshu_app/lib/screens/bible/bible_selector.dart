import 'package:flutter/material.dart';
import '../../core/data/bible_repo.dart';
import '../../core/data/bible_reading_rules.dart';
import '../../core/theme.dart';

Future<ReadingPosition?> selectBiblePassage(
  BuildContext context,
  int bookId,
  int chapter,
) => showModalBottomSheet<ReadingPosition>(
  context: context,
  isScrollControlled: true,
  builder: (_) => _PassageSelector(bookId: bookId, chapter: chapter),
);

class _PassageSelector extends StatefulWidget {
  const _PassageSelector({required this.bookId, required this.chapter});
  final int bookId, chapter;
  @override
  State<_PassageSelector> createState() => _PassageSelectorState();
}

class _PassageSelectorState extends State<_PassageSelector> {
  late int _book = widget.bookId;
  late int _chapter = widget.chapter;
  late bool _new = _book >= 39;
  String _query = '';
  @override
  Widget build(BuildContext context) {
    final selected = BibleRepo.instance.book(_book);
    final books =
        BibleRepo.instance.books
            .where(
              (b) =>
                  b.isOldTestament != _new &&
                  b.name.toLowerCase().contains(_query.toLowerCase()),
            )
            .toList();
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * .8,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Holy Bible',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Close',
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              SegmentedButton<bool>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: false, label: Text('Old Testament')),
                  ButtonSegment(value: true, label: Text('New Testament')),
                ],
                selected: {_new},
                onSelectionChanged: (s) => setState(() => _new = s.first),
              ),
              const SizedBox(height: 12),
              TextField(
                onChanged: (v) => setState(() => _query = v),
                decoration: InputDecoration(
                  hintText: 'Search books',
                  prefixIcon: const Icon(Icons.search_rounded),
                  filled: true,
                  fillColor: AppColors.paperDeep,
                  contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'BOOK',
                      style: TextStyle(
                        fontSize: 10,
                        color: AppColors.muted,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      '${selected?.name ?? ''} · CHAPTER',
                      style: const TextStyle(
                        fontSize: 10,
                        color: AppColors.muted,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: books.length,
                        itemBuilder:
                            (_, i) => ListTile(
                              contentPadding: const EdgeInsets.only(
                                left: 8,
                                right: 4,
                              ),
                              dense: true,
                              selected: books[i].id == _book,
                              selectedColor: AppColors.accent,
                              selectedTileColor: AppColors.accentSoft,
                              title: Text(
                                books[i].name,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              trailing:
                                  books[i].id == _book
                                      ? const Icon(
                                        Icons.check_rounded,
                                        size: 16,
                                      )
                                      : null,
                              onTap:
                                  () => setState(() {
                                    _book = books[i].id;
                                    _chapter = 1;
                                  }),
                            ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GridView.builder(
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3,
                              crossAxisSpacing: 6,
                              mainAxisSpacing: 6,
                            ),
                        itemCount: selected?.chapters ?? 0,
                        itemBuilder:
                            (_, i) => Material(
                              color:
                                  _chapter == i + 1
                                      ? AppColors.accent
                                      : AppColors.paperDeep,
                              borderRadius: BorderRadius.circular(8),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(8),
                                onTap: () => setState(() => _chapter = i + 1),
                                child: Center(
                                  child: Text(
                                    '${i + 1}',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      color:
                                          _chapter == i + 1
                                              ? AppColors.onPrimary
                                              : AppColors.ink,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              FilledButton(
                onPressed:
                    selected == null
                        ? null
                        : () => Navigator.pop(context, (
                          bookId: _book,
                          chapter: _chapter,
                        )),
                child: Text('Read ${selected?.name ?? ''} $_chapter'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
