import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';

import '../../core/data/catalog.dart';
import '../../core/native/wallpaper_bridge.dart';
import '../../core/share_helper.dart';
import '../../widgets/common.dart';
import '../../core/theme.dart';

/// Full-screen photo wallpaper viewer: swipe, set, save, share.
class WallpaperViewer extends StatefulWidget {
  const WallpaperViewer({
    super.key,
    required this.items,
    required this.initial,
    this.onLive,
    this.header,
  });

  final List<StaticWallpaper> items;
  final int initial;
  final VoidCallback? onLive;

  /// Optional centred top control (the Live/Static switch).
  final Widget? header;

  @override
  State<WallpaperViewer> createState() => _WallpaperViewerState();
}

class _WallpaperViewerState extends State<WallpaperViewer> {
  late final PageController _pages = PageController(
    initialPage: widget.initial,
  );
  late int _index = widget.initial;

  StaticWallpaper get _current => widget.items[_index];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _warmAround(_index);
  }

  /// Decode the next three and previous one so swiping never shows a blank page.
  void _warmAround(int i) {
    for (final j in [i + 1, i + 2, i + 3, i - 1]) {
      if (j >= 0 && j < widget.items.length) {
        NetImage.warm(context, widget.items[j].image, memWidth: 1080);
      }
    }
  }

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  Future<void> _set() async {
    tapHaptic();
    final target = await showModalBottomSheet<String>(
      context: context,
      builder:
          (c) => SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Text(
                    'Set wallpaper on',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                ),
                SheetOption(
                  icon: Icons.home_rounded,
                  title: 'Home screen',
                  onTap: () => Navigator.pop(c, 'home'),
                ),
                SheetOption(
                  icon: Icons.lock_rounded,
                  title: 'Lock screen',
                  onTap: () => Navigator.pop(c, 'lock'),
                ),
                SheetOption(
                  icon: Icons.smartphone_rounded,
                  title: 'Both screens',
                  onTap: () => Navigator.pop(c, 'both'),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
    );
    if (target == null || !mounted) return;
    if (kIsWeb) {
      toast(
        context,
        'Apply preview: selected ${target == 'both' ? 'both screens' : '$target screen'}. Wallpaper applies on Android.',
      );
      return;
    }
    final ok = await withBusy(
      context,
      'Setting your wallpaper…',
      () => WallpaperBridge.setStatic(_current.image, target: target),
    );
    if (!mounted) return;
    toast(
      context,
      ok
          ? 'Wallpaper set. God bless you!'
          : 'Could not set the wallpaper. Please check your internet.',
      error: !ok,
    );
  }

  Future<void> _save() async {
    tapHaptic();
    final ok = await withBusy(context, 'Saving…', () async {
      final f = await ShareHelper.download(_current.image);
      return f != null &&
          await ShareHelper.saveToGallery(f, 'Aashray ${_current.title}'.trim());
    });
    if (mounted)
      toast(
        context,
        ok
            ? 'Saved to your gallery (Pictures/Aashray).'
            : 'Could not save. Please try again.',
        error: !ok,
      );
  }

  Future<void> _share() async {
    tapHaptic();
    final f = await withBusy(
      context,
      'Preparing…',
      () => ShareHelper.download(_current.image),
    );
    if (f == null) {
      if (mounted)
        toast(
          context,
          'Could not load the picture. Please check your internet.',
          error: true,
        );
      return;
    }
    await ShareHelper.shareFile(f, text: ShareHelper.appLine);
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: AppColors.ink,
        body: Stack(
          fit: StackFit.expand,
          children: [
            PageView.builder(
              controller: _pages,
              allowImplicitScrolling: true,
              itemCount: widget.items.length,
              onPageChanged: (i) {
                setState(() => _index = i);
                _warmAround(i);
              },
              itemBuilder: (context, i) {
                final w = widget.items[i];
                return Hero(
                  tag: 'wp-${w.id}',
                  child: NetImage(w.image, memWidth: 1080, dark: true),
                );
              },
            ),
            const IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0x66000000),
                      Color(0x00000000),
                      Color(0x00000000),
                      Color(0x99000000),
                    ],
                    stops: [0, 0.16, 0.7, 1],
                  ),
                ),
              ),
            ),
            Positioned(
              top: pad.top + 6,
              left: 8,
              right: 8,
              child: Row(
                children: [
                  SoftIconButton(
                    icon: Icons.arrow_back_rounded,
                    dark: true,
                    size: 44,
                    onTap: () => Navigator.pop(context),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Center(child: widget.header)),
                  const SizedBox(width: 54),
                  if (widget.onLive != null && widget.header == null)
                    SoftIconButton(
                      icon: Icons.play_circle_outline,
                      dark: true,
                      size: 44,
                      onTap: widget.onLive,
                    ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: pad.bottom + 16,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        tooltip: 'Previous wallpaper',
                        onPressed:
                            _index > 0
                                ? () => _pages.previousPage(
                                  duration: const Duration(milliseconds: 240),
                                  curve: Curves.easeOut,
                                )
                                : null,
                        icon: const Icon(
                          Icons.chevron_left,
                          color: AppColors.imageInk,
                        ),
                      ),
                      Text(
                        '${_index + 1} / ${widget.items.length}',
                        style: const TextStyle(
                          color: AppColors.imageInk,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      IconButton(
                        tooltip: 'Next wallpaper',
                        onPressed:
                            _index < widget.items.length - 1
                                ? () => _pages.nextPage(
                                  duration: const Duration(milliseconds: 240),
                                  curve: Curves.easeOut,
                                )
                                : null,
                        icon: const Icon(
                          Icons.chevron_right,
                          color: AppColors.imageInk,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SoftIconButton(
                        icon: Icons.download_rounded,
                        label: 'Save',
                        dark: true,
                        onTap: _save,
                      ),
                      SetWallpaperButton(onTap: _set, label: 'Apply wallpaper'),
                      SoftIconButton(
                        icon: Icons.share_rounded,
                        label: 'Share',
                        dark: true,
                        onTap: _share,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SetWallpaperButton extends StatelessWidget {
  const SetWallpaperButton({
    super.key,
    required this.onTap,
    this.label = 'Set wallpaper',
  });
  final VoidCallback onTap;
  final String label;

  @override
  Widget build(BuildContext context) {
    return FilledButton.icon(
      onPressed: onTap,
      icon: const Icon(Icons.wallpaper_rounded, size: 20),
      label: Text(label),
      style: FilledButton.styleFrom(
        minimumSize: const Size(0, 52),
        padding: const EdgeInsets.symmetric(horizontal: 18),
      ),
    );
  }
}
