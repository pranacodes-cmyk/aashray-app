import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import '../../core/data/catalog.dart';
import '../../core/native/wallpaper_bridge.dart';
import '../../core/share_helper.dart';
import '../../widgets/common.dart';
import 'wallpaper_viewer.dart';

/// Full-screen live wallpaper preview. Only the visible page plays video.
class LiveViewer extends StatefulWidget {
  const LiveViewer({super.key, required this.items, required this.initial});

  final List<LiveWallpaper> items;
  final int initial;

  @override
  State<LiveViewer> createState() => _LiveViewerState();
}

class _LiveViewerState extends State<LiveViewer> {
  late final PageController _pages = PageController(
    initialPage: widget.initial,
  );
  late int _index = widget.initial;
  final Map<int, Size> _sizes = {};

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  Future<void> _set() async {
    tapHaptic();
    final w = widget.items[_index];
    final size = _sizes[_index];
    final ok = await withBusy(
      context,
      'Downloading live wallpaper…',
      () => WallpaperBridge.setLive(
        w.video,
        w.id,
        width: size?.width.round(),
        height: size?.height.round(),
      ),
    );
    if (!mounted) return;
    if (ok) {
      toast(context, 'Tap “Set wallpaper” on the next screen.');
    } else {
      toast(
        context,
        'Could not prepare this live wallpaper. Please check your internet.',
        error: true,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    final w = widget.items[_index];
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          fit: StackFit.expand,
          children: [
            PageView.builder(
              controller: _pages,
              itemCount: widget.items.length,
              onPageChanged: (i) => setState(() => _index = i),
              itemBuilder:
                  (context, i) => _LivePage(
                    item: widget.items[i],
                    active: i == _index,
                    onSize: (s) => _sizes[i] = s,
                  ),
            ),
            const IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0x66000000),
                      Color(0x00000000),
                      Color(0x00000000),
                      Color(0x99000000),
                    ],
                    stops: [0, 0.16, 0.7, 1],
                  ),
                ),
              ),
            ),
            Positioned(
              top: pad.top + 6,
              left: 8,
              right: 8,
              child: Row(
                children: [
                  SoftIconButton(
                    icon: Icons.arrow_back_rounded,
                    dark: true,
                    size: 44,
                    onTap: () => Navigator.pop(context),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      w.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: pad.bottom + 22,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SetWallpaperButton(onTap: _set, label: 'Set live wallpaper'),
                  SoftIconButton(
                    icon: Icons.share_rounded,
                    label: 'Share',
                    dark: true,
                    onTap:
                        () => ShareHelper.shareText(
                          '${w.title} — beautiful live wallpaper.\n\n${ShareHelper.appLine}',
                        ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LivePage extends StatefulWidget {
  const _LivePage({
    required this.item,
    required this.active,
    required this.onSize,
  });

  final LiveWallpaper item;
  final bool active;
  final ValueChanged<Size> onSize;

  @override
  State<_LivePage> createState() => _LivePageState();
}

class _LivePageState extends State<_LivePage> {
  VideoPlayerController? _c;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    if (widget.active) _start();
  }

  @override
  void didUpdateWidget(_LivePage old) {
    super.didUpdateWidget(old);
    if (widget.active && _c == null) _start();
    if (!widget.active) _c?.pause();
    if (widget.active && _ready) _c?.play();
  }

  Future<void> _start() async {
    final c = VideoPlayerController.networkUrl(
      Uri.parse(widget.item.video),
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );
    _c = c;
    try {
      await c.initialize();
      await c.setVolume(0);
      await c.setLooping(true);
      if (!mounted) return;
      widget.onSize(c.value.size);
      setState(() => _ready = true);
      if (widget.active) await c.play();
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return Stack(
      fit: StackFit.expand,
      children: [
        if (Catalog.hasPoster(item))
          Image.asset(item.posterAsset, fit: BoxFit.cover),
        if (_ready && _c != null)
          FittedBox(
            fit: BoxFit.cover,
            clipBehavior: Clip.hardEdge,
            child: SizedBox(
              width: _c!.value.size.width,
              height: _c!.value.size.height,
              child: VideoPlayer(_c!),
            ),
          ),
        if (!_ready && !_failed)
          const Center(
            child: SizedBox(
              width: 34,
              height: 34,
              child: CircularProgressIndicator(
                color: Colors.white,
                strokeWidth: 2.6,
              ),
            ),
          ),
        if (_failed)
          Center(
            child: TextButton.icon(
              onPressed: () {
                setState(() => _failed = false);
                _c?.dispose();
                _c = null;
                _start();
              },
              icon: const Icon(Icons.refresh_rounded, color: Colors.white),
              label: const Text(
                'Tap to retry',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
      ],
    );
  }
}
