import 'package:flutter/material.dart';
import '../../core/data/catalog.dart';
import '../../core/theme.dart';
import 'live_viewer.dart';
import 'wallpaper_viewer.dart';

/// One full-screen wallpaper at a time, with a simple Static / Live switch.
class WallpapersScreen extends StatefulWidget {
  const WallpapersScreen({super.key});
  @override
  State<WallpapersScreen> createState() => _WallpapersScreenState();
}

class _WallpapersScreenState extends State<WallpapersScreen> {
  bool _live = false;

  Widget get _switch => _KindSwitch(
    live: _live,
    onChanged: (v) => setState(() => _live = v),
  );

  @override
  Widget build(BuildContext context) {
    if (Catalog.wallpapers.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Wallpapers')),
        body: const Center(child: Icon(Icons.image_not_supported_outlined)),
      );
    }
    if (_live && Catalog.live.isNotEmpty) {
      return LiveViewer(
        key: const ValueKey('live'),
        items: Catalog.live,
        initial: 0,
        header: _switch,
      );
    }
    return WallpaperViewer(
      key: const ValueKey('static'),
      items: Catalog.wallpapers,
      initial: 0,
      header: Catalog.live.isEmpty ? null : _switch,
    );
  }
}

class _KindSwitch extends StatelessWidget {
  const _KindSwitch({required this.live, required this.onChanged});
  final bool live;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(3),
    decoration: BoxDecoration(
      color: AppColors.scrim.withValues(alpha: .45),
      borderRadius: BorderRadius.circular(30),
      border: Border.all(color: AppColors.imageInk.withValues(alpha: .25)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _seg('Static', !live, () => onChanged(false)),
        _seg('Live', live, () => onChanged(true)),
      ],
    ),
  );

  Widget _seg(String label, bool on, VoidCallback tap) => Semantics(
    button: true,
    selected: on,
    child: GestureDetector(
      onTap: tap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        decoration: BoxDecoration(
          color: on ? AppColors.imageGold : Colors.transparent,
          borderRadius: BorderRadius.circular(26),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 13,
            color: on ? AppColors.scrim : AppColors.imageInk,
          ),
        ),
      ),
    ),
  );
}
