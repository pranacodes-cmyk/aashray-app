import 'package:flutter/material.dart';
import '../../core/data/catalog.dart';
import 'live_viewer.dart';
import 'wallpaper_viewer.dart';

/// Open the single-image experience directly, without a thumbnail grid.
class WallpapersScreen extends StatelessWidget {
  const WallpapersScreen({super.key});
  @override
  Widget build(BuildContext context) {
    if (Catalog.wallpapers.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Wallpapers')),
        body: const Center(child: Icon(Icons.image_not_supported_outlined)),
      );
    }
    return WallpaperViewer(
      items: Catalog.wallpapers,
      initial: 0,
      onLive:
          Catalog.live.isEmpty
              ? null
              : () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (_) => LiveViewer(items: Catalog.live, initial: 0),
                ),
              ),
    );
  }
}
