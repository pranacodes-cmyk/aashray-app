import 'package:flutter/material.dart';

import '../../core/audio/audio_hub.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../../widgets/audio_language_switch.dart';

/// Full player for the current Peace track.
class PeacePlayerScreen extends StatelessWidget {
  const PeacePlayerScreen({super.key});

  static String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final hub = AudioHub.instance;
    return ListenableBuilder(
      listenable: hub,
      builder: (context, _) {
        final track = hub.current?.track;
        if (track == null) {
          return Scaffold(
            appBar: AppBar(),
            body: const Center(
              child: Text(
                'Nothing is playing.',
                style: TextStyle(color: AppColors.muted),
              ),
            ),
          );
        }
        if (hub.error != null) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!context.mounted || hub.error == null) return;
            toast(context, hub.error!, error: true);
            hub.clearError();
          });
        }
        final size = MediaQuery.of(context).size;
        final art = (size.width - 64).clamp(200.0, 360.0);
        return Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
              onPressed: () => Navigator.pop(context),
            ),
            title: Text(track.kindLabel),
            centerTitle: true,
          ),
          body: SafeArea(
            top: false,
            child: ContentWidth(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(32, 8, 32, 24),
                children: [
                  const Center(child: AudioLanguageSwitch()),
                  const SizedBox(height: 20),
                  Center(
                    child: Container(
                      width: art,
                      height: art,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: const [
                          BoxShadow(
                            color: AppColors.shadow,
                            blurRadius: 30,
                            offset: Offset(0, 14),
                          ),
                        ],
                      ),
                      child: NetImage(track.coverUrl, radius: 8, memWidth: 900),
                    ),
                  ),
                  const SizedBox(height: 26),
                  Text(
                    track.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontFamily: AppTheme.serif,
                      fontSize: 25,
                      fontWeight: FontWeight.w500,
                      height: 1.3,
                    ),
                  ),
                  if (track.scripture.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(
                      track.scripture,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppColors.gold,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                  const SizedBox(height: 8),
                  Text(
                    track.description,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppColors.muted,
                      height: 1.4,
                      fontSize: 14.5,
                    ),
                  ),
                  const SizedBox(height: 20),
                  StreamBuilder<Duration>(
                    stream: hub.player.positionStream,
                    builder: (context, snap) {
                      final total =
                          hub.player.duration ??
                          Duration(seconds: track.duration);
                      var pos = snap.data ?? Duration.zero;
                      if (pos > total) pos = total;
                      final max =
                          total.inMilliseconds <= 0
                              ? 1.0
                              : total.inMilliseconds.toDouble();
                      return Column(
                        children: [
                          SliderTheme(
                            data: SliderTheme.of(context).copyWith(
                              trackHeight: 4,
                              thumbShape: const RoundSliderThumbShape(
                                enabledThumbRadius: 7,
                              ),
                            ),
                            child: Slider(
                              value: pos.inMilliseconds.toDouble().clamp(
                                0,
                                max,
                              ),
                              max: max,
                              onChanged:
                                  (v) => hub.seek(
                                    Duration(milliseconds: v.round()),
                                  ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 22),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _fmt(pos),
                                  style: const TextStyle(
                                    color: AppColors.muted,
                                    fontSize: 12.5,
                                  ),
                                ),
                                Text(
                                  _fmt(total),
                                  style: const TextStyle(
                                    color: AppColors.muted,
                                    fontSize: 12.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        iconSize: 34,
                        onPressed: () => hub.seekBy(-15),
                        icon: const Icon(Icons.replay_10_rounded),
                      ),
                      const SizedBox(width: 22),
                      Material(
                        color: AppColors.primary,
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: hub.toggle,
                          child: SizedBox(
                            width: 76,
                            height: 76,
                            child:
                                hub.loading
                                    ? const Padding(
                                      padding: EdgeInsets.all(24),
                                      child: CircularProgressIndicator(
                                        color: AppColors.onPrimary,
                                        strokeWidth: 2.6,
                                      ),
                                    )
                                    : Icon(
                                      hub.playing
                                          ? Icons.pause_rounded
                                          : Icons.play_arrow_rounded,
                                      color: AppColors.onPrimary,
                                      size: 44,
                                    ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 22),
                      IconButton(
                        iconSize: 34,
                        onPressed: () => hub.seekBy(15),
                        icon: const Icon(Icons.forward_10_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
