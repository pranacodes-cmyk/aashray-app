import 'package:flutter/material.dart';

import '../../core/data/day_rules.dart';
import '../../core/data/peace_catalog.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';
import '../../widgets/audio_language_switch.dart';
import '../home/home_screen.dart';

/// Prayers for today, meditations and bedtime Bible stories.
class PeaceScreen extends StatelessWidget {
  const PeaceScreen({super.key, this.initialKind});
  final String? initialKind;

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
    valueListenable: PeaceCatalog.language,
    builder: (context, _, _) => _buildContent(context),
  );

  Widget _buildContent(BuildContext context) {
    final now = DateTime.now();
    final prayers = PeaceCatalog.prayersFor(now);
    final meditations = PeaceCatalog.byKind('meditation');
    final stories = PeaceCatalog.byKind('story');
    final slot = prayerSlotFor(now.hour);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          initialKind == 'meditation'
              ? 'Meditation'
              : initialKind == 'story'
              ? 'Night stories'
              : 'Prayers & Peace',
        ),
      ),
      body: ContentWidth(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 28),
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 4, 20, 16),
              child: AudioLanguageSwitch(),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  height: 190,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(
                        initialKind == 'meditation'
                            ? 'assets/images/meditation_tile.jpg'
                            : initialKind == 'story'
                            ? 'assets/images/verse_garden.jpg'
                            : 'assets/images/prayer_tile.jpg',
                        fit: BoxFit.cover,
                        alignment: Alignment.topCenter,
                      ),
                      DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              AppColors.scrim.withValues(alpha: .02),
                              AppColors.scrim.withValues(alpha: .8),
                            ],
                            stops: const [.25, 1],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 20,
                        right: 20,
                        bottom: 20,
                        child: Text(
                          initialKind == 'meditation'
                              ? 'Be still with God.'
                              : initialKind == 'story'
                              ? 'Rest in His peace.'
                              : 'A moment with Him.',
                          style: const TextStyle(
                            fontFamily: AppTheme.serif,
                            fontSize: 24,
                            color: AppColors.imageInk,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (initialKind == null)
              const SectionTitle(
                "Today's prayers",
                padding: EdgeInsets.fromLTRB(20, 8, 12, 10),
              ),
            for (final p in initialKind == null ? prayers : <PeaceTrack>[])
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 0, 24, 10),
                child: Material(
                  color: p.slot == slot ? AppColors.greenSoft : AppColors.paper,
                  borderRadius: BorderRadius.circular(8),
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => openPeaceTrack(context, p),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 84,
                          height: 84,
                          child: NetImage(p.thumbUrl, memWidth: 220),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                (p.slot == slot ? 'NOW · ' : '') +
                                    (p.slot ?? '').toUpperCase(),
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0,
                                  color:
                                      p.slot == slot
                                          ? AppColors.green
                                          : AppColors.muted,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                p.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15.5,
                                ),
                              ),
                              Text(
                                '${p.scripture} · ${p.minutesLabel}',
                                style: const TextStyle(
                                  color: AppColors.muted,
                                  fontSize: 12.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.only(right: 14),
                          child: Icon(
                            Icons.play_circle_fill_rounded,
                            color: AppColors.primary,
                            size: 34,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            if (initialKind != 'story') ...[
              SectionTitle('Meditation with God'),
              _Grid(items: meditations),
            ],
            if (initialKind != 'meditation') ...[
              SectionTitle('Bedtime Bible stories'),
              _Grid(items: stories),
            ],
            if (PeaceCatalog.attribution.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
                child: Text(
                  PeaceCatalog.attribution,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.muted, fontSize: 12),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _Grid extends StatelessWidget {
  const _Grid({required this.items});
  final List<PeaceTrack> items;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: LayoutBuilder(
        builder: (context, c) {
          final w = (c.maxWidth - 12) / 2;
          return Wrap(
            spacing: 12,
            runSpacing: 16,
            children: [for (final t in items) PeaceTile(track: t, width: w)],
          );
        },
      ),
    );
  }
}
