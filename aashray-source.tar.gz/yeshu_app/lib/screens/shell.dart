import 'package:flutter/material.dart';

import '../core/audio/audio_hub.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'bible/bible_screen.dart';
import 'home/home_screen.dart';
import 'peace/peace_player_screen.dart';
import 'ringtones/ringtones_screen.dart';
import 'status/status_screen.dart';
import 'wallpapers/wallpapers_screen.dart';

/// Tab switching from anywhere (Home tiles open other tabs).
class ShellTabs {
  ShellTabs._();
  static final index = ValueNotifier<int>(0);

  static const home = 0;
  static const wallpapers = 1;
  static const bible = 2;
  static const status = 3;
  static const ringtones = 4;

  static void go(int i) => index.value = i;
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final _built = <int>{0};

  static const _tabs = <Widget>[
    HomeScreen(),
    WallpapersScreen(),
    BibleScreen(),
    StatusScreen(),
    RingtonesScreen(),
  ];

  @override
  void initState() {
    super.initState();
    ShellTabs.index.value = 0;
    ShellTabs.index.addListener(_onTab);
  }

  @override
  void dispose() {
    ShellTabs.index.removeListener(_onTab);
    super.dispose();
  }

  void _onTab() => setState(() => _built.add(ShellTabs.index.value));

  @override
  Widget build(BuildContext context) {
    final index = ShellTabs.index.value;
    return PopScope(
      canPop: index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && index != 0) ShellTabs.go(0);
      },
      child: Scaffold(
        body: IndexedStack(
          index: index,
          children: [
            for (var i = 0; i < _tabs.length; i++)
              _built.contains(i) ? _tabs[i] : const SizedBox.shrink(),
          ],
        ),
        bottomNavigationBar: const MiniPlayer(),
      ),
    );
  }
}

/// Shown above the tab bar while a prayer / story is loaded.
class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final hub = AudioHub.instance;
    return ListenableBuilder(
      listenable: hub,
      builder: (context, _) {
        final now = hub.current;
        final track = now?.track;
        if (track == null) return const SizedBox.shrink();
        return Material(
          color: AppColors.paper,
          child: InkWell(
            onTap:
                () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const PeacePlayerScreen(),
                  ),
                ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
              child: Row(
                children: [
                  SizedBox(
                    width: 44,
                    height: 44,
                    child: NetImage(track.thumbUrl, radius: 10, memWidth: 120),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          track.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14.5,
                          ),
                        ),
                        Text(
                          now!.subtitle,
                          maxLines: 1,
                          style: const TextStyle(
                            color: AppColors.muted,
                            fontSize: 12.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (hub.loading)
                    const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.4),
                      ),
                    )
                  else
                    IconButton(
                      onPressed: hub.toggle,
                      icon: Icon(
                        hub.playing
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded,
                        size: 30,
                        color: AppColors.primary,
                      ),
                    ),
                  IconButton(
                    onPressed: hub.stop,
                    icon: const Icon(
                      Icons.close_rounded,
                      color: AppColors.muted,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
