import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/native/media_bridge.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('com.aashray.faith/media');
  test('eight original Hindi bhajans each contain exactly 30 seconds of audio', () {
    final records = jsonDecode(File('assets/data/ringtones.json').readAsStringSync()) as List;
    expect(records.length, 8);
    expect(records.map((r) => r['id']).toSet().length, 8);
    for (final record in records) {
      expect(record['seconds'], 30);
      final audio = Process.runSync('ffmpeg', ['-v', 'error', '-i', record['asset'] as String, '-f', 's16le', '-ac', '1', '-ar', '44100', '-'], stdoutEncoding: null);
      expect(audio.exitCode, 0);
      expect((audio.stdout as List<int>).length, 30 * 44100 * 2);
    }
  });
  test('saving ringtone does not request system settings access', () async {
    final calls = <String>[];
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(channel, (call) async {
      calls.add(call.method);
      return 'ok';
    });
    expect(await MediaBridge.saveRingtone(asset: 'assets/ringtones/yeshu-mera-sahara.mp3', title: 'Aashray Mera Sahara'), RingtoneOutcome.ok);
    expect(calls, ['saveRingtone']);
  });
  test('app never declares the Modify system settings permission', () {
    final manifest = File('android/app/src/main/AndroidManifest.xml').readAsStringSync();
    expect(manifest.contains('WRITE_SETTINGS'), isFalse);
    final native = File('android/app/src/main/java/com/aashray/faith/MediaChannel.java').readAsStringSync();
    expect(native.contains('setActualDefaultRingtoneUri'), isFalse);
  });
}
