import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/premium/plans.dart';

void main() {
  test('monthly plan is ₹199 for 30 days, charged in paise', () {
    expect(kMonthlyPlan.priceInr, 199);
    expect(kMonthlyPlan.periodDays, 30);
    expect(kMonthlyPlan.amountPaise, 19900);
  });

  test('yearly plan is ₹999 for 365 days and shows ₹83 per month', () {
    expect(kYearlyPlan.priceInr, 999);
    expect(kYearlyPlan.periodDays, 365);
    expect(kYearlyPlan.amountPaise, 99900);
    expect(kYearlyPlan.perMonthInr, 83);
  });

  test('yearly saves 58% against twelve monthly payments', () {
    expect(yearlySavingsPercent(kMonthlyPlan, kYearlyPlan), 58);
  });

  test('a new purchase starts now', () {
    final now = DateTime(2026, 10, 29, 12);
    expect(extendExpiry(currentExpiry: null, plan: kMonthlyPlan, now: now), DateTime(2026, 11, 28, 12));
  });

  test('renewing early keeps the remaining days', () {
    final now = DateTime(2026, 10, 29);
    final current = DateTime(2026, 11, 5);
    expect(extendExpiry(currentExpiry: current, plan: kMonthlyPlan, now: now), DateTime(2026, 12, 5));
  });

  test('renewing after expiry starts from now, not from the old date', () {
    final now = DateTime(2026, 10, 29);
    final old = DateTime(2026, 9, 1);
    expect(extendExpiry(currentExpiry: old, plan: kYearlyPlan, now: now), now.add(const Duration(days: 365)));
  });

  test('premium locks at the exact expiry instant', () {
    final expiry = DateTime(2026, 11, 1, 10);
    expect(isEntitled(expiry, DateTime(2026, 11, 1, 9, 59)), isTrue);
    expect(isEntitled(expiry, expiry), isFalse);
    expect(isEntitled(null, expiry), isFalse);
  });

  test('days left rounds up and is 0 once expired', () {
    final now = DateTime(2026, 10, 29, 12);
    expect(daysLeft(DateTime(2026, 10, 30, 13), now), 2);
    expect(daysLeft(DateTime(2026, 10, 29, 11), now), 0);
  });
}
