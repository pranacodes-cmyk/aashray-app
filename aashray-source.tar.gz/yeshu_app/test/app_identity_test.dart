import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/config.dart';

void main() {
  test('standalone identity is Aashray with independent package', () {
    expect(AppConfig.appName, 'Aashray');
    expect(AppConfig.androidPackage, 'com.aashray.faith');
    expect(
      File(
        'android/app/build.gradle.kts',
      ).readAsStringSync().contains('applicationId = "com.aashray.faith"'),
      isTrue,
    );
    expect(
      File(
        'android/app/src/main/java/com/aashray/faith/MediaChannel.java',
      ).readAsStringSync().contains('com.aashray.faith/media'),
      isTrue,
    );
  });
}
