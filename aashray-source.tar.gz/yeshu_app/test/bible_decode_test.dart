import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/data/bible_decode.dart';

void main() {
  final bytes = utf8.encode(
    '[["In the beginning God created the heaven and the earth."]]',
  );
  test('bundled compressed Bible decodes', () {
    expect(
      decodeBibleBook(const GZipEncoder().encode(bytes)).first.first,
      'In the beginning God created the heaven and the earth.',
    );
  });
  test('host decompressed Bible decodes without a second gzip pass', () {
    expect(
      decodeBibleBook(bytes).first.first,
      'In the beginning God created the heaven and the earth.',
    );
  });
}
