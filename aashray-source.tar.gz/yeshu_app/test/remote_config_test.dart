import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/remote_config.dart';

void main() {
  final rc = RemoteConfig.instance;

  test('skip modes come only from known server values', () {
    expect(parseSkipMode('soft'), SkipMode.soft);
    expect(parseSkipMode('review'), SkipMode.review);
    expect(parseSkipMode('anything'), SkipMode.off);
    expect(parseSkipMode(null), SkipMode.off);
  });

  test('server trial price fills the CTA', () {
    rc.debugSet({'trial_price_inr': 5, 'paywall': {'cta': 'Start ₹{trial} trial'}});
    expect(rc.cta, 'Start ₹5 trial');
  });

  test('hidden monthly price never appears in fine print', () {
    rc.debugSet({'monthly_price_inr': 399, 'paywall': {'show_monthly_price': false, 'fine_print': 'then ₹{monthly}/month'}});
    expect(rc.finePrint.contains('399'), isFalse);
  });

  test('out-of-range prices fall back to ₹2 / ₹399', () {
    rc.debugSet({'trial_price_inr': -1, 'monthly_price_inr': 999999});
    expect(rc.trialPrice, 2);
    expect(rc.monthlyPrice, 399);
  });
}
