import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/data/bible_repo.dart';
import 'package:aashray/core/data/bible_reading_rules.dart';

void main() {
  const books = [
    BibleBook(id: 0, name: 'Genesis', chapters: 50),
    BibleBook(id: 1, name: 'Exodus', chapters: 40),
  ];
  test('Bible opens directly at Genesis 1 for a new reader', () {
    expect(initialReadingPosition(books, null, null), (bookId: 0, chapter: 1));
  });
  test('Bible opens saved chapter without selection steps', () {
    expect(initialReadingPosition(books, 1, 12), (bookId: 1, chapter: 12));
  });
  test('Scrolling continues to the next chapter', () {
    expect(nextReadingPosition(books, 0, 1), (bookId: 0, chapter: 2));
  });
  test('Scrolling continues into the next book', () {
    expect(nextReadingPosition(books, 0, 50), (bookId: 1, chapter: 1));
  });
  test('Final chapter has no following content', () {
    expect(nextReadingPosition(books, 1, 40), isNull);
  });
}
