import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final templates =
      jsonDecode(File('assets/data/status_templates.json').readAsStringSync())
          as List;
  final wallpapers =
      (jsonDecode(File('assets/data/wallpapers.json').readAsStringSync())
              as Map)['wallpapers']
          as List;
  test('featured status collection contains 48 unique templates', () {
    expect(templates.length, 48);
    expect(templates.map((t) => t['id']).toSet().length, 48);
  });
  test('every template maps to the exact existing wallpaper URL', () {
    final byId = {for (final w in wallpapers) w['id']: w['image']};
    for (final t in templates) {
      expect(byId[t['wallpaperId']], t['background']);
    }
    expect(templates.map((t) => t['background']).toSet().length, 48);
  });
}
