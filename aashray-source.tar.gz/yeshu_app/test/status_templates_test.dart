import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final templates =
      jsonDecode(File('assets/data/status_templates.json').readAsStringSync())
          as List;
  final wallpapers =
      (jsonDecode(File('assets/data/wallpapers.json').readAsStringSync())
              as Map)['wallpapers']
          as List;
  test('featured status collection contains 60 unique templates', () {
    expect(templates.length, 60);
    expect(templates.map((t) => t['id']).toSet().length, 60);
  });
  test('pre-lettered artwork never receives an additional verse layer', () {
    for (final id in ['featured-15', 'featured-43', 'featured-44', 'featured-48', 'featured-51', 'featured-53', 'featured-54', 'featured-55', 'featured-58', 'featured-59']) {
      final item = templates.singleWhere((t) => t['id'] == id);
      expect(item['artworkContainsText'], isTrue, reason: id);
    }
    expect(templates.singleWhere((t) => t['id'] == 'featured-01')['artworkContainsText'], isFalse);
  });
  test('every template maps to the exact existing wallpaper URL', () {
    final byId = {for (final w in wallpapers) w['id']: w['image']};
    for (final t in templates) {
      expect(byId[t['wallpaperId']], t['background']);
    }
    expect(templates.map((t) => t['background']).toSet().length, 60);
  });
}
