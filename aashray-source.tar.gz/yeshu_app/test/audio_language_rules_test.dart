import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/data/audio_language_rules.dart';

void main() {
  test('spoken audio defaults to Hindi', () {
    expect(audioLanguageFor(null), 'hi');
    expect(audioLanguageFor('hi'), 'hi');
  });
  test('explicit saved English selection is retained', () {
    expect(audioLanguageFor('en'), 'en');
  });
  final catalog = jsonDecode(File('assets/data/peace_catalog.json').readAsStringSync()) as Map;
  for (final kind in ['prayer', 'meditation', 'story']) {
    test('$kind has actual Hindi recordings and separate English recordings', () {
      final tracks = (catalog['tracks'] as List).where((t) => t['kind'] == kind).toList();
      expect(tracks, isNotEmpty);
      for (final item in tracks) {
        final t = Map<String, dynamic>.from(item as Map);
        expect(audioVersionFor(t, 'hi')['audio'], contains('/hi/'));
        expect(audioVersionFor(t, 'en')['audio'], t['audio']);
        expect(audioVersionFor(t, 'hi')['audio'], isNot(t['audio']));
        expect(audioVersionFor(t, 'hi')['id'], t['id']);
      }
    });
  }
}