import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/premium/cashfree_checkout.dart';
import 'package:aashray/core/premium/plans.dart';

void main() {
  test('without verified order backend payment fails closed', () async {
    CashfreeCheckout.instance.backend = null;
    expect(
      await CashfreeCheckout.instance.pay(kYearlyPlan),
      isA<CheckoutNotConfigured>(),
    );
  });
  test('plans charge full price without a 2 rupee trial', () {
    expect(kPlans.map((p) => p.priceInr), [999, 199]);
    expect(kPlans.any((p) => p.priceInr == 2), isFalse);
  });
}
