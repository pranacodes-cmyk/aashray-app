import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/data/day_rules.dart';

void main() {
  test('daily auto rotation changes verse and background at local midnight', () {
    final before = DateTime(2026, 11, 4, 23, 59);
    final after = DateTime(2026, 11, 5);
    expect(verseIndexFor(before, 366), 307);
    expect(verseIndexFor(after, 366), 308);
    expect(backgroundIndexFor(before, 20), 8);
    expect(backgroundIndexFor(after, 20), 9);
  });
  test('day of year is 1-based like Android Calendar.DAY_OF_YEAR', () {
    expect(dayOfYear(DateTime(2026, 1, 1)), 1);
    expect(dayOfYear(DateTime(2026, 12, 31)), 365);
    expect(dayOfYear(DateTime(2028, 12, 31)), 366);
    expect(dayOfYear(DateTime(2026, 3, 1, 23, 59)), 60);
  });

  test('Jan 1 shows the first verse and the second background (native bg-02)', () {
    expect(verseIndexFor(DateTime(2026, 1, 1), 366), 0);
    expect(backgroundIndexFor(DateTime(2026, 1, 1), 20), 1);
    expect(backgroundIndexFor(DateTime(2026, 1, 20), 20), 0);
  });

  test('greeting follows the local hour', () {
    expect(greetingFor(6), 'Good morning');
    expect(greetingFor(13), 'Good afternoon');
    expect(greetingFor(19), 'Good evening');
    expect(greetingFor(23), 'Good night');
    expect(greetingFor(2), 'Good night');
  });

  test('prayer moments: morning 4–11, afternoon 12–16, evening 17–20, night 21–3', () {
    expect(prayerSlotFor(4), 'morning');
    expect(prayerSlotFor(11), 'morning');
    expect(prayerSlotFor(12), 'afternoon');
    expect(prayerSlotFor(17), 'evening');
    expect(prayerSlotFor(21), 'night');
    expect(prayerSlotFor(3), 'night');
  });

  test('1 AM still uses last night\'s prayers', () {
    // Thursday 29 Oct 2026, 01:00 → Wednesday's set.
    expect(prayerWeekdayFor(DateTime(2026, 10, 29, 1)), DateTime.wednesday);
    expect(prayerWeekdayFor(DateTime(2026, 10, 29, 9)), DateTime.thursday);
  });
}
