import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:aashray/core/prefs.dart';
import 'package:aashray/screens/bible/bible_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await Prefs.init();
  });
  test('reading font selection is saved', () {
    BibleStore.instance.setFontFamily('Manrope');
    expect(Prefs.getString('bible_font_family'), 'Manrope');
    BibleStore.instance.setFontFamily('Lora');
    expect(Prefs.getString('bible_font_family'), 'Lora');
  });
  test('font size controls persist the selected value', () {
    BibleStore.instance.setFont(24);
    expect(Prefs.getDouble('bible_font'), 24);
  });
  test('swiped verse saves exact book chapter and verse', () {
    BibleStore.instance.setPosition(
      const SavedVerse(
        bookId: 42,
        bookName: 'John',
        chapter: 3,
        verse: 16,
        text: 'For God so loved the world',
      ),
    );
    expect(Prefs.getString('bible_last'), '42|3|John');
    expect(Prefs.getInt('bible_last_verse'), 16);
  });
}
