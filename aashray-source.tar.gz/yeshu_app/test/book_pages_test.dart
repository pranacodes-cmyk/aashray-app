import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/screens/bible/book_pages.dart';

void main() {
  final verses = [
    for (var i = 0; i < 40; i++)
      'And God said let there be light and there was light verse $i ' * (i % 5 + 1),
  ];
  List<BookPage> pages(double w, double h) => paginateChapter(
    bookId: 0,
    bookName: 'Genesis',
    chapter: 1,
    verses: verses,
    width: w,
    height: h,
    style: bookTextStyle('Lora', 19),
  );

  test('book pages keep every word of the chapter in order', () {
    final result = pages(300, 500);
    expect(result.length, greaterThan(1));
    expect(result.first.firstOfChapter, isTrue);
    expect(result.skip(1).every((p) => !p.firstOfChapter), isTrue);
    final joined = <int, String>{};
    for (final p in result) {
      for (final v in p.verses) {
        joined[v.number] = [if (joined[v.number] != null) joined[v.number]!, v.text].join(' ');
      }
    }
    for (var i = 0; i < verses.length; i++) {
      expect(joined[i + 1], verses[i].trim());
    }
  });

  test('a verse longer than a page continues instead of being cut', () {
    final result = paginateChapter(
      bookId: 0,
      bookName: 'Psalms',
      chapter: 119,
      verses: ['word ' * 600],
      width: 260,
      height: 300,
      style: bookTextStyle('Lora', 19),
    );
    expect(result.length, greaterThan(1));
    expect(result[1].verses.first.continued, isTrue);
  });
}
