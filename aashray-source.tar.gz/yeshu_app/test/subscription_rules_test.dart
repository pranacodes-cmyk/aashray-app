import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/core/meta/meta_events.dart';
import 'package:aashray/core/premium/subscription_rules.dart';

void main() {
  final now = DateTime.utc(2026, 11, 5, 12);

  test('trial is ₹2 for 1 day, then ₹399 per month', () {
    expect(kTrialAmountInr, 2);
    expect(kTrialDays, 1);
    expect(kMonthlyInr, 399);
  });

  test('premium only when server says premium with a future accessUntil', () {
    expect(serverAccessUntil({'premium': true, 'accessUntil': '2026-11-06T12:00:00Z'}, now), DateTime.utc(2026, 11, 6, 12));
    expect(serverAccessUntil({'premium': false, 'accessUntil': '2026-11-06T12:00:00Z'}, now), isNull);
    expect(serverAccessUntil({'premium': true, 'accessUntil': '2026-11-01T12:00:00Z'}, now), isNull);
    expect(serverAccessUntil({'premium': true}, now), isNull);
    expect(serverAccessUntil({'premium': 'true', 'accessUntil': '2026-11-06T12:00:00Z'}, now), isNull);
  });

  test('app can never log StartTrial or Purchase to Meta', () {
    for (final name in ['StartTrial', 'Purchase', 'fb_mobile_purchase', 'Subscribe']) {
      expect(MetaEvents.isAllowed(name), isFalse, reason: name);
    }
    expect(MetaEvents.isAllowed('fb_mobile_initiated_checkout'), isTrue);
  });

  test('device ids match the server format', () {
    expect(isValidDeviceId('d_abcdefghijklmnopqrstuvwx'), isTrue);
    expect(isValidDeviceId('bad id'), isFalse);
  });
}
