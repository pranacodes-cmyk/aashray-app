import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aashray/widgets/personalize_sheet.dart';

void main() {
  testWidgets('name input receives focus and returns entered name', (
    tester,
  ) async {
    ({String name, dynamic photo})? result;
    await tester.pumpWidget(
      MaterialApp(
        home: Builder(
          builder:
              (context) => Scaffold(
                body: TextButton(
                  onPressed: () async {
                    result = await showModalBottomSheet<
                      ({String name, dynamic photo})
                    >(
                      context: context,
                      isScrollControlled: true,
                      requestFocus: true,
                      builder: (_) => const PersonalizeSheet(name: ''),
                    );
                  },
                  child: const Text('Open'),
                ),
              ),
        ),
      ),
    );
    await tester.tap(find.text('Open'));
    await tester.pumpAndSettle();
    final field = tester.widget<TextField>(find.byType(TextField));
    expect(field.focusNode?.hasFocus, isTrue);
    expect(field.keyboardType, TextInputType.name);
    await tester.enterText(find.byType(TextField), 'Mohit');
    await tester.tap(find.text('Apply to blessing'));
    await tester.pumpAndSettle();
    expect(result?.name, 'Mohit');
  });
}
