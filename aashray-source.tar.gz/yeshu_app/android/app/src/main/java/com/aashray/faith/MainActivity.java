package com.aashray.faith;

import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ryanheise.audioservice.AudioServiceActivity;

import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

/**
 * Flutter host. AudioServiceActivity keeps Peace prayers playing with the
 * screen off; the two channels below handle wallpapers and ringtones/sharing.
 */
public class MainActivity extends AudioServiceActivity {

    private WallpaperChannel wallpaperChannel;
    private MediaChannel mediaChannel;

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        wallpaperChannel = new WallpaperChannel(this);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), WallpaperChannel.CHANNEL)
                .setMethodCallHandler(wallpaperChannel);
        mediaChannel = new MediaChannel(this);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), MediaChannel.CHANNEL)
                .setMethodCallHandler(mediaChannel);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), MetaChannel.CHANNEL)
                .setMethodCallHandler(new MetaChannel(this));
    }

    @Override
    protected void onCreate(@Nullable android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Install + app open for Meta attribution (purchases come from the server).
        try {
            com.facebook.FacebookSdk.setAutoLogAppEventsEnabled(true);
            com.facebook.appevents.AppEventsLogger.activateApp(getApplication());
        } catch (Throwable ignored) { }
    }

    /** "Exit" keeps the engine warm so the next open is instant. */
    @Override
    public boolean popSystemNavigator() {
        try {
            if (moveTaskToBack(true)) return true;
        } catch (Throwable ignored) { }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == WallpaperChannel.REQUEST_CODE && wallpaperChannel != null) {
            wallpaperChannel.onPickerResult(resultCode);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MediaChannel.STORAGE_REQUEST && mediaChannel != null) {
            mediaChannel.onStoragePermission(grantResults.length > 0
                    && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED);
        }
    }
}
