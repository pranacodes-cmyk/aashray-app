package com.aashray.faith;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import com.facebook.appevents.AppEventsLogger;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/** Meta app events (funnel only). Money events are sent by the server. */
public class MetaChannel implements MethodChannel.MethodCallHandler {
    public static final String CHANNEL = "aashray/meta";
    private final Activity activity;
    private final AppEventsLogger logger;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public MetaChannel(Activity activity) {
        this.activity = activity;
        this.logger = AppEventsLogger.newLogger(activity);
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) {
        switch (call.method) {
            case "log": {
                String name = call.argument("name");
                Number value = call.argument("value");
                Map<String, Object> params = call.argument("params");
                Bundle b = new Bundle();
                if (params != null) for (Map.Entry<String, Object> e : params.entrySet()) b.putString(e.getKey(), String.valueOf(e.getValue()));
                if (name == null) { result.success(null); return; }
                if (value != null) logger.logEvent(name, value.doubleValue(), b); else logger.logEvent(name, b);
                result.success(null);
                return;
            }
            case "anonId":
                io.execute(() -> {
                    String id = null;
                    try { id = AppEventsLogger.getAnonymousAppDeviceGUID(activity); } catch (Throwable ignored) { }
                    final String out = id;
                    main.post(() -> result.success(out));
                });
                return;
            case "advertiserId":
                io.execute(() -> {
                    String id = null;
                    try {
                        com.google.android.gms.ads.identifier.AdvertisingIdClient.Info info =
                                com.google.android.gms.ads.identifier.AdvertisingIdClient.getAdvertisingIdInfo(activity);
                        if (info != null && !info.isLimitAdTrackingEnabled()) id = info.getId();
                    } catch (Throwable ignored) { }
                    final String out = id;
                    main.post(() -> result.success(out));
                });
                return;
            default:
                result.notImplemented();
        }
    }
}
