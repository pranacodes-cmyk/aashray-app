package com.aashray.faith.wallpaper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Shared, validated offline wallpaper assets. Serialized writes prevent .part races. */
public final class DailyVerseAssetCache {
    private DailyVerseAssetCache() {}

    public static boolean valid(File file) {
        if (!file.isFile() || file.length() <= 1024) return false;
        Bitmap bitmap = null;
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 32;
            bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            return bitmap != null && bitmap.getWidth() > 0 && bitmap.getHeight() > 0;
        } catch (RuntimeException ignored) {
            return false;
        } finally {
            if (bitmap != null) bitmap.recycle();
        }
    }

    public static boolean complete(int validCount, int total) {
        return total > 0 && validCount == total;
    }

    public static synchronized long download(String url, File out) {
        HttpURLConnection connection = null;
        File tmp = new File(out.getParentFile(), out.getName() + ".part");
        try {
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return -1;
            try (InputStream input = connection.getInputStream();
                 FileOutputStream output = new FileOutputStream(tmp)) {
                byte[] buffer = new byte[16384];
                int count;
                long bytes = 0;
                while ((count = input.read(buffer)) != -1) {
                    bytes += count;
                    if (bytes > 24L * 1024 * 1024) return -1;
                    output.write(buffer, 0, count);
                }
            }
            if (!valid(tmp)) return -1;
            // Android/Linux rename atomically replaces the destination; keep a
            // valid old image intact when a refresh fails.
            if (!tmp.renameTo(out)) return -1;
            return out.length();
        } catch (Exception ignored) {
            return -1;
        } finally {
            tmp.delete();
            if (connection != null) connection.disconnect();
        }
    }
}