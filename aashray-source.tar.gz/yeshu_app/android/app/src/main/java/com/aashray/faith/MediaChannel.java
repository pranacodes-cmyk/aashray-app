package com.aashray.faith;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.Manifest;
import android.media.MediaScannerConnection;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.flutter.FlutterInjector;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/**
 * Ringtones, gallery saves and WhatsApp sharing. Disk and MediaStore work runs
 * on a background executor; every result is completed on the main thread.
 */
public class MediaChannel implements MethodChannel.MethodCallHandler {

    public static final String CHANNEL = "com.aashray.faith/media";
    private static final String TAG = "AashrayMedia";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final String[] WHATSAPP = {"com.whatsapp", "com.whatsapp.w4b"};

    /** Android 7–9 only: storage permission for saving into the public Pictures folder. */
    public static final int STORAGE_REQUEST = 4712;

    private final Activity activity;
    private final Handler main = new Handler(Looper.getMainLooper());
    private String pendingPath;
    private String pendingName;
    private MethodChannel.Result pendingSave;
    private String pendingAudioAsset, pendingAudioTitle;

    public MediaChannel(Activity activity) {
        this.activity = activity;
    }

    private Context ctx() {
        return activity.getApplicationContext();
    }

    @Override
    public void onMethodCall(MethodCall call, MethodChannel.Result result) {
        switch (call.method) {
            case "canWriteSettings":
                result.success(Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(ctx()));
                break;
            case "openWriteSettings":
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + ctx().getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(i);
                    result.success(true);
                } catch (Exception e) {
                    result.success(false);
                }
                break;
            case "saveRingtone":
            case "setRingtone": {
                final String asset = call.argument("asset");
                final String title = call.argument("title");
                final String type = "saveRingtone".equals(call.method) ? "save" : call.argument("type");
                if (Build.VERSION.SDK_INT < 29 && activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    if (pendingSave != null) { result.success("error"); break; }
                    pendingAudioAsset = asset; pendingAudioTitle = title; pendingName = type; pendingSave = result;
                    activity.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST);
                } else runAudio(asset, title, type, result);
                break;
            }
            case "saveImage": {
                final String path = call.argument("path");
                final String name = call.argument("name");
                if (Build.VERSION.SDK_INT < 29 && activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    if (pendingSave != null) pendingSave.success(false);
                    pendingPath = path;
                    pendingName = name;
                    pendingSave = result;
                    activity.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST);
                    break;
                }
                runSave(path, name, result);
                break;
            }
            case "shareToWhatsApp": {
                String path = call.argument("path");
                String text = call.argument("text");
                result.success(shareToWhatsApp(path, text));
                break;
            }
            case "hasWhatsApp":
                result.success(whatsAppPackage() != null);
                break;
            default:
                result.notImplemented();
        }
    }

    /** Called by MainActivity once the user answers the storage dialog. */
    public void onStoragePermission(boolean granted) {
        MethodChannel.Result r = pendingSave;
        String path = pendingPath;
        String name = pendingName;
        pendingSave = null;
        pendingPath = null;
        pendingName = null;
        if (r == null) return;
        if (pendingAudioAsset != null) {
            String asset = pendingAudioAsset, title = pendingAudioTitle;
            pendingAudioAsset = null; pendingAudioTitle = null;
            if (granted) runAudio(asset, title, name, r); else r.success("storage_denied");
        } else if (granted) runSave(path, name, r);
        else r.success(false);
    }

    private void runSave(String path, String name, MethodChannel.Result result) {
        IO.execute(() -> {
            boolean ok;
            try {
                ok = saveImage(path, name);
            } catch (Exception e) {
                Log.w(TAG, "saveImage failed", e);
                ok = false;
            }
            final boolean r = ok;
            main.post(() -> result.success(r));
        });
    }

    private void runAudio(String asset, String title, String type, MethodChannel.Result result) {
        IO.execute(() -> {
            String outcome;
            try { outcome = setRingtone(asset, title, type); }
            catch (Exception e) { Log.w(TAG, "Audio save/set failed", e); outcome = "error"; }
            final String value = outcome;
            main.post(() -> result.success(value));
        });
    }

    // ------------------------------------------------------------ ringtones

    /** @return "ok", "needs_permission" or "error" */
    private String setRingtone(String asset, String title, String type) throws Exception {
        if (!"save".equals(type) && Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(ctx())) return "needs_permission";
        int ringType;
        String dir;
        String column;
        if ("notification".equals(type)) {
            ringType = RingtoneManager.TYPE_NOTIFICATION;
            dir = Environment.DIRECTORY_NOTIFICATIONS;
            column = MediaStore.Audio.Media.IS_NOTIFICATION;
        } else if ("alarm".equals(type)) {
            ringType = RingtoneManager.TYPE_ALARM;
            dir = Environment.DIRECTORY_ALARMS;
            column = MediaStore.Audio.Media.IS_ALARM;
        } else {
            ringType = RingtoneManager.TYPE_RINGTONE;
            dir = Environment.DIRECTORY_RINGTONES;
            column = MediaStore.Audio.Media.IS_RINGTONE;
        }
        if (asset == null || !asset.startsWith("assets/ringtones/") || asset.contains("..")) return "error";
        String safe = title == null ? "Bhajan" : title.replaceAll("[^A-Za-z0-9 ]", "").trim();
        String fileName = "Aashray - " + safe + ".mp3";
        ContentResolver cr = ctx().getContentResolver();
        Uri uri;
        if (Build.VERSION.SDK_INT >= 29) {
            uri = findAudio(cr, fileName, dir);
            if (uri != null) {
                try (InputStream existing = cr.openInputStream(uri)) {
                    if (existing == null || existing.read() < 0) { cr.delete(uri, null, null); uri = null; }
                } catch (Exception e) { cr.delete(uri, null, null); uri = null; }
            }
            if (uri == null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                v.put(MediaStore.MediaColumns.TITLE, "Aashray - " + safe);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/");
                v.put(column, true);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                uri = cr.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return "error";
                try {
                    try (OutputStream os = cr.openOutputStream(uri); InputStream is = openAsset(asset)) { copy(is, os); }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    if (cr.update(uri, done, null, null) < 1) throw new IllegalStateException("Audio finalize failed");
                } catch (Exception e) { cr.delete(uri, null, null); throw e; }
            }
        } else {
            File base = Environment.getExternalStoragePublicDirectory(dir);
            if (!base.exists() && !base.mkdirs()) return "error";
            File out = new File(base, fileName);
            if (!out.exists() || out.length() == 0) {
                try (OutputStream os = new FileOutputStream(out); InputStream is = openAsset(asset)) {
                    copy(is, os);
                }
            }
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DATA, out.getAbsolutePath());
            v.put(MediaStore.MediaColumns.TITLE, "Aashray - " + safe);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg");
            v.put(column, true);
            Uri table = MediaStore.Audio.Media.getContentUriForPath(out.getAbsolutePath());
            cr.delete(table, MediaStore.MediaColumns.DATA + "=?", new String[]{out.getAbsolutePath()});
            uri = cr.insert(table, v);
            if (uri == null) return "error";
        }
        if ("save".equals(type)) return "ok";
        RingtoneManager.setActualDefaultRingtoneUri(ctx(), ringType, uri);
        Uri actual = RingtoneManager.getActualDefaultRingtoneUri(ctx(), ringType);
        return uri.equals(actual) ? "ok" : "saved_not_set";
    }

    private Uri findAudio(ContentResolver cr, String name, String dir) {
        String sel = MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?";
        try (Cursor c = cr.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.MediaColumns._ID}, sel, new String[]{name, dir + "/"}, null)) {
            if (c != null && c.moveToFirst()) {
                return Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, String.valueOf(c.getLong(0)));
            }
        } catch (Exception ignored) { }
        return null;
    }

    private InputStream openAsset(String asset) throws Exception {
        String key = FlutterInjector.instance().flutterLoader().getLookupKeyForAsset(asset);
        return ctx().getAssets().open(key);
    }

    // --------------------------------------------------------------- images

    private boolean saveImage(String path, String name) throws Exception {
        File src = new File(path);
        if (!src.exists()) return false;
        String mime = path.endsWith(".png") ? "image/png" : "image/jpeg";
        String fileName = name + (mime.equals("image/png") ? ".png" : ".jpg");
        ContentResolver cr = ctx().getContentResolver();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Aashray");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return false;
            try (OutputStream os = cr.openOutputStream(uri); InputStream is = new java.io.FileInputStream(src)) {
                copy(is, os);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(uri, done, null, null);
            return true;
        }
        // Android 7–9: public Pictures/Aashray so it shows in the Gallery and survives uninstall.
        File base = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Aashray");
        if (!base.exists() && !base.mkdirs()) return false;
        File out = new File(base, fileName);
        try (OutputStream os = new FileOutputStream(out); InputStream is = new java.io.FileInputStream(src)) {
            copy(is, os);
        }
        MediaScannerConnection.scanFile(ctx(), new String[]{out.getAbsolutePath()}, new String[]{mime}, null);
        return true;
    }

    // ------------------------------------------------------------- whatsapp

    private String whatsAppPackage() {
        PackageManager pm = ctx().getPackageManager();
        for (String p : WHATSAPP) {
            try {
                pm.getPackageInfo(p, 0);
                return p;
            } catch (PackageManager.NameNotFoundException ignored) { }
        }
        return null;
    }

    private boolean shareToWhatsApp(String path, String text) {
        String pkg = whatsAppPackage();
        if (pkg == null || path == null) return false;
        try {
            File f = new File(path);
            Uri uri = FileProvider.getUriForFile(ctx(), ctx().getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(path.endsWith(".png") ? "image/png" : "image/jpeg");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
            i.setPackage(pkg);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(i);
            return true;
        } catch (Exception e) {
            Log.w(TAG, "WhatsApp share failed", e);
            return false;
        }
    }

    private static void copy(InputStream is, OutputStream os) throws Exception {
        if (os == null) throw new IllegalStateException("No output stream");
        byte[] buf = new byte[16384];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        os.flush();
    }
}
