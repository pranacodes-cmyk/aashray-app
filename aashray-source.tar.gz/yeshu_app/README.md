# Aashray — Bible, Wallpapers & Status

A simple, English-only Christian app for India (Android, Flutter). Standalone with own package id `com.aashray.faith`, own code, no RevenueCat, no ads,
no onboarding slides.

## What is inside

| Area | Free / Premium | Notes |
|---|---|---|
| Paywall | shown on launch | Father blessing video, ₹199 / 30 days or ₹999 / 365 days, one-time UPI payment (no auto-debit) |
| Home | Premium | AMOLED black/gold, photographic daily verse, four image tiles and Bible block; no bottom tabs |
| Wallpapers | Premium | 264 verified available photo + 211 live (video) wallpapers from a read-only catalog snapshot (unavailable original image URLs filtered) |
| Daily wallpaper | Premium | Plain screen (no phone mockup): today's verse picture, Set as wallpaper, WhatsApp, Share, Save; changes by itself every midnight once applied |
| Bible | Premium | English KJV, bundled (offline), last-read position, font size |
| Status | Premium | 48 wallpaper-mapped personal blessings with name/photo editor, plus 80 topic verses, WhatsApp / Share / Save |
| Ringtones | Premium | 8 hymn tones, set as ringtone / notification / alarm |
| Peace | Premium | 68 English prayers, meditations and night stories, plays with screen off |

## Build

```bash
flutter pub get
flutter test                       # price / expiry / day-of-year rules
flutter build apk --release --split-per-abi \
  --target-platform android-arm,android-arm64
```

- Cashfree native UPI Element SDK is installed. A `CashfreeOrderBackend` must
  create server orders and verify PAID before access; no private credentials
  go in the app. Until connected, checkout is disabled without taking money.
- `ALLOW_TEST_UNLOCK=true` — internal test builds only: adds a "Test unlock
  (1 day)" link on the paywall. Never use it for a store build.
- Release signing: put `android/key.properties` (storeFile, storePassword,
  keyAlias, keyPassword) next to the keystore. Without it the build falls back
  to the debug key (fine for side-loading tests, not for Play).

## Still to do before launch

1. Cashfree server order + paid-order verification and the
   custom UPI intent flow (tap → PhonePe / GPay opens directly).
2. Restore purchase after reinstall (needs the same backend).
3. Release keystore + Play listing.
4. Phone test of the native parts (wallpaper, live, daily, ringtone, save,
   WhatsApp, lock-screen audio).

## Data tools (`tool/`)

- `make_status.py` — builds `assets/data/status.json` from the Bible text.
- `make_ringtones.py` — trims/normalises the hymn tones.
- `make_live_posters.sh` — small poster frames for the live wallpaper grid.

## November redesign verification

Flutter web is the exact same code, served in the React preview. The `Preview
app` action exists only with ALLOW_TEST_UNLOCK and is not a purchase. Prices
₹199/₹999 are provisional examples, not confirmed merchant prices. No ₹2 trial.
