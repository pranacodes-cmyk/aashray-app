#!/usr/bin/env bash
# Grabs one poster frame per live wallpaper preview clip into assets/live_posters/<id>.webp
cd "$(dirname "$0")/.."
python3 -c "import json;[print(x['id'],x['preview'] or x['video']) for x in json.load(open('assets/data/wallpapers.json'))['live']]" | while read id url; do
  out=assets/live_posters/$id.webp
  [ -s "$out" ] && continue
  ffmpeg -loglevel error -y -ss 0.8 -i "$url" -frames:v 1 -vf "scale=360:-2" -quality 72 "$out" || echo "FAIL $id"
done
echo POSTERS_DONE
