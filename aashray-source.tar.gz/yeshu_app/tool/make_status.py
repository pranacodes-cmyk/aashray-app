#!/usr/bin/env python3
"""Builds assets/data/status.json from the bundled KJV so every status quote
is the exact Bible text (no hand-typed verses).  python3 tool/make_status.py
"""
import gzip
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIBLE = os.path.join(ROOT, "assets", "bible", "en")
OUT = os.path.join(ROOT, "assets", "data", "status.json")

CATEGORIES = [
    ("good-morning", "Good Morning", "Good Morning", [
        "Lamentations 3:22-23", "Psalm 118:24", "Psalm 5:3", "Psalm 143:8", "Psalm 90:14",
        "Isaiah 33:2", "Psalm 59:16", "Psalm 30:5", "Zephaniah 3:17", "Psalm 113:3",
    ]),
    ("good-night", "Good Night", "Good Night", [
        "Psalm 4:8", "Proverbs 3:24", "Psalm 121:4", "Psalm 91:1", "Matthew 11:28",
        "Psalm 127:2", "Psalm 63:6", "Psalm 3:5", "Psalm 16:7", "Isaiah 26:3",
    ]),
    ("blessings", "Blessings", "God bless you", [
        "Numbers 6:24-26", "Ephesians 1:3", "Psalm 67:1", "Psalm 115:14-15", "Deuteronomy 28:6",
        "Psalm 29:11", "Proverbs 10:22", "2 Corinthians 9:8", "Psalm 84:11", "Jeremiah 17:7",
    ]),
    ("strength", "Strength", "Be strong", [
        "Philippians 4:13", "Isaiah 41:10", "Joshua 1:9", "Isaiah 40:31", "Psalm 46:1",
        "2 Corinthians 12:9", "Psalm 28:7", "Deuteronomy 31:6", "Nehemiah 8:10", "Psalm 73:26",
    ]),
    ("love", "God's Love", "God loves you", [
        "John 3:16", "Romans 8:38-39", "1 John 4:19", "Jeremiah 31:3", "1 John 4:16",
        "Romans 5:8", "1 Corinthians 13:4", "Psalm 136:26", "Ephesians 2:4-5", "1 Corinthians 16:14",
    ]),
    ("peace", "Peace", "Peace be with you", [
        "John 14:27", "Philippians 4:6-7", "Psalm 46:10", "Isaiah 26:3", "2 Thessalonians 3:16",
        "Colossians 3:15", "Psalm 29:11", "Romans 15:13", "John 16:33", "Matthew 5:9",
    ]),
    ("faith", "Faith & Hope", "Keep the faith", [
        "Hebrews 11:1", "Jeremiah 29:11", "Proverbs 3:5-6", "Romans 8:28", "Mark 11:24",
        "Matthew 17:20", "Romans 12:12", "Psalm 37:5", "2 Corinthians 5:7", "Mark 9:23",
    ]),
    ("thanks", "Thanksgiving", "Thank you, Jesus", [
        "1 Thessalonians 5:18", "Psalm 107:1", "Psalm 100:4", "Colossians 3:17", "Psalm 9:1",
        "Psalm 136:1", "Psalm 95:2", "Ephesians 5:20", "Psalm 28:7", "Psalm 118:29",
    ]),
]

index = json.load(open(os.path.join(BIBLE, "index.json")))
BOOKS = {b["name"]: b["canonicalId"] for b in index["books"]}
BOOKS.setdefault("Psalm", BOOKS.get("Psalms"))
_cache = {}


def chapter(book_id, ch):
    if book_id not in _cache:
        _cache[book_id] = json.load(gzip.open(os.path.join(BIBLE, f"{book_id}.json.gz")))
    return _cache[book_id][ch - 1]


def lookup(ref):
    m = re.match(r"^(.+?) (\d+):(\d+)(?:-(\d+))?$", ref)
    book, ch, v1, v2 = m.group(1), int(m.group(2)), int(m.group(3)), m.group(4)
    if book not in BOOKS:
        raise SystemExit(f"Unknown book {book} in {ref}")
    verses = chapter(BOOKS[book], ch)
    last = int(v2) if v2 else v1
    text = " ".join(verses[i - 1].strip() for i in range(v1, last + 1))
    text = re.sub(r"\s+", " ", text)
    return text, ref


def main():
    out = []
    for cid, name, greeting, refs in CATEGORIES:
        items = []
        seen = set()
        for r in refs:
            if r in seen:
                continue
            seen.add(r)
            text, ref = lookup(r)
            # Typographic apostrophe so it matches the curly quotes on the card.
            text = text.replace("'", "\u2019")
            items.append({"id": f"{cid}-{len(items) + 1:02d}", "text": text, "reference": ref + " (KJV)"})
        out.append({"id": cid, "name": name, "greeting": greeting, "items": items})
    with open(OUT, "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print(sum(len(c["items"]) for c in out), "status quotes")


if __name__ == "__main__":
    main()
