#!/usr/bin/env python3
"""Renders the bundled ringtones from public-domain hymn melodies.

Every melody here is public domain (written before 1900, or an original
motif). Output: assets/ringtones/<id>.mp3 (~30 s) + assets/data/ringtones.json.
Run from anywhere:  python3 tool/make_ringtones.py
"""
import json
import os
import subprocess
import tempfile
import wave

import numpy as np
from scipy.signal import fftconvolve

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(ROOT, "assets", "ringtones")
DATA = os.path.join(ROOT, "assets", "data", "ringtones.json")
TARGET_SECONDS = 30.0

NOTE = {"C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3, "E": 4, "F": 5,
        "F#": 6, "Gb": 6, "G": 7, "G#": 8, "Ab": 8, "A": 9, "A#": 10, "Bb": 10, "B": 11}


def midi(name):
    if name == "R":
        return None
    pitch, octave = name[:-1], int(name[-1])
    return 12 * (octave + 1) + NOTE[pitch]


def freq(m):
    return 440.0 * 2 ** ((m - 69) / 12)


CHORDS = {
    "C": ["C3", "E3", "G3"], "F": ["F2", "A3", "C4"], "G": ["G2", "B3", "D4"],
    "D": ["D3", "F#3", "A3"], "Em": ["E3", "G3", "B3"], "Am": ["A2", "C4", "E4"],
    "E": ["E3", "G#3", "B3"], "A": ["A2", "C#4", "E4"], "B": ["B2", "D#4", "F#4"],
}


# ---------------------------------------------------------------- timbres
def env(n, attack, decay):
    t = np.arange(n) / SR
    a = np.minimum(1.0, t / max(attack, 1e-4))
    return a * np.exp(-t / decay)


def tone(f, dur, kind):
    tail = {"bell": 3.2, "musicbox": 1.6, "piano": 1.8, "harp": 2.0, "organ": 0.25, "celesta": 1.8}[kind]
    n = int((dur + tail) * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    if kind == "bell":
        parts = [(0.5, 0.35, 2.8), (1.0, 1.0, 2.4), (2.0, 0.5, 1.4), (2.76, 0.35, 1.0), (5.4, 0.18, 0.5), (8.93, 0.08, 0.25)]
        for ratio, amp, dec in parts:
            out += amp * np.sin(2 * np.pi * f * ratio * t) * env(n, 0.002, dec)
    elif kind == "musicbox":
        for ratio, amp, dec in [(1, 1.0, 0.9), (2, 0.18, 0.45), (3.01, 0.22, 0.3), (5.98, 0.06, 0.12)]:
            out += amp * np.sin(2 * np.pi * f * ratio * t) * env(n, 0.001, dec)
    elif kind == "celesta":
        for ratio, amp, dec in [(1, 1.0, 1.1), (2, 0.25, 0.6), (4, 0.12, 0.25)]:
            out += amp * np.sin(2 * np.pi * f * ratio * t) * env(n, 0.002, dec)
    elif kind == "harp":
        for k in range(1, 7):
            out += (0.8 / k ** 1.6) * np.sin(2 * np.pi * f * k * t) * env(n, 0.003, 1.2 / k ** 0.5)
    elif kind == "piano":
        for k in range(1, 8):
            detune = 1 + 0.0004 * k * k
            out += (1.0 / k ** 1.4) * np.sin(2 * np.pi * f * k * detune * t) * env(n, 0.004, 1.3 / k ** 0.6)
    elif kind == "organ":
        hold = np.ones(n)
        rel = int(0.25 * SR)
        hold[int(dur * SR):] = np.exp(-np.arange(n - int(dur * SR)) / rel)
        att = np.minimum(1.0, t / 0.05)
        for ratio, amp in [(0.5, 0.35), (1, 1.0), (2, 0.5), (3, 0.22), (4, 0.15), (6, 0.06)]:
            out += amp * np.sin(2 * np.pi * f * ratio * t)
        out *= hold * att * (1 + 0.03 * np.sin(2 * np.pi * 5.2 * t))
    return out


def pad(names, dur):
    n = int((dur + 0.8) * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    att = np.minimum(1.0, t / 0.35)
    rel = np.ones(n)
    end = int(dur * SR)
    rel[end:] = np.exp(-np.arange(n - end) / (0.35 * SR))
    for nm in names:
        f = freq(midi(nm))
        out += np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * 2 * f * t + 0.3)
    return out * att * rel / max(1, len(names))


def reverb(x, seconds=2.2, mix=0.28):
    n = int(seconds * SR)
    rng = np.random.default_rng(7)
    ir = rng.standard_normal(n) * np.exp(-np.arange(n) / (0.42 * SR))
    ir[0] = 0
    wet = fftconvolve(x, ir)[: len(x)]
    wet /= np.max(np.abs(wet)) + 1e-9
    dry = x / (np.max(np.abs(x)) + 1e-9)
    return (1 - mix) * dry + mix * wet


# ---------------------------------------------------------------- render
def render(song):
    bpm = song["bpm"]
    beat = 60.0 / bpm
    phrase_beats = sum(d for _, d in song["melody"])
    phrase_s = phrase_beats * beat
    gap = song.get("gap", 1.0) * beat
    loops = max(1, int((TARGET_SECONDS - 1.5) // (phrase_s + gap)))
    total = loops * (phrase_s + gap) + 3.5
    buf = np.zeros(int(total * SR) + SR * 4)

    def add(sig, at, gain):
        i = int(at * SR)
        buf[i:i + len(sig)] += gain * sig[: len(buf) - i]

    for lp in range(loops):
        t0 = lp * (phrase_s + gap)
        t = t0
        for name, d in song["melody"]:
            m = midi(name)
            if m is not None:
                add(tone(freq(m + song.get("transpose", 0)), d * beat, song["voice"]), t, 0.55)
                if song.get("double"):
                    add(tone(freq(m + song.get("transpose", 0) - 12), d * beat, song["double"]), t, 0.18)
            t += d * beat
        t = t0
        for chord, d in song.get("chords", []):
            if chord:
                names = CHORDS[chord]
                add(pad(names, d * beat), t, 0.16)
                # soft bass on the chord change
                add(tone(freq(midi(names[0]) - 12 if midi(names[0]) > 48 else midi(names[0])), d * beat, "harp"), t, 0.16)
            t += d * beat
    y = reverb(buf[: int(total * SR)], mix=song.get("reverb", 0.28))
    fade = int(2.0 * SR)
    y[-fade:] *= np.linspace(1, 0, fade)
    y[: int(0.01 * SR)] *= np.linspace(0, 1, int(0.01 * SR))
    y = y / (np.max(np.abs(y)) + 1e-9) * 0.89
    return y


def write_mp3(y, path):
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wav_path = tmp.name
    with wave.open(wav_path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((y * 32767).astype(np.int16).tobytes())
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", wav_path, "-c:a", "libmp3lame",
                    "-b:a", "128k", "-ar", "44100", path], check=True)
    os.unlink(wav_path)


def seq(text):
    """'G4:2 B4:.5 R:1' -> [(name, beats)]"""
    out = []
    for tok in text.split():
        n, d = tok.split(":")
        out.append((n, float(d)))
    return out


def ch(text):
    out = []
    for tok in text.split():
        c, d = tok.split(":")
        out.append((None if c == "-" else c, float(d)))
    return out


SONGS = [
    {
        "id": "amazing-grace", "title": "Amazing Grace", "subtitle": "Music box", "voice": "musicbox",
        "bpm": 84, "transpose": 12, "gap": 1,
        "melody": seq("D4:1 G4:2 B4:.5 G4:.5 B4:2 A4:1 G4:2 E4:1 D4:2 D4:1 G4:2 B4:.5 G4:.5 B4:2 A4:1 D5:3 "
                      "R:2 B4:1 D5:2 B4:.5 G4:.5 D4:2 E4:1 G4:2 E4:1 D4:2 D4:1 G4:2 B4:.5 G4:.5 B4:2 A4:1 G4:3"),
        "chords": ch("-:1 G:3 G:3 C:3 G:3 G:3 D:3 D:3 D:3 G:3 G:3 C:3 G:3 G:3 D:3 G:3"),
    },
    {
        "id": "silent-night", "title": "Silent Night", "subtitle": "Celesta", "voice": "celesta",
        "bpm": 96, "transpose": 12, "gap": 1.5,
        "melody": seq("G4:.75 A4:.25 G4:.5 E4:1.5 G4:.75 A4:.25 G4:.5 E4:1.5 D5:1 D5:.5 B4:1.5 C5:1 C5:.5 G4:1.5 "
                      "A4:1 A4:.5 C5:.75 B4:.25 A4:.5 G4:.75 A4:.25 G4:.5 E4:1.5 "
                      "A4:1 A4:.5 C5:.75 B4:.25 A4:.5 G4:.75 A4:.25 G4:.5 E4:1.5 "
                      "D5:1 D5:.5 F5:.75 D5:.25 B4:.5 C5:1.5 E5:1.5 C5:.75 G4:.25 E4:.5 G4:.75 F4:.25 D4:.5 C4:3"),
        "chords": ch("C:3 C:3 G:3 C:3 F:3 C:3 F:3 C:3 G:3 C:3 G:3 C:3"),
    },
    {
        "id": "joyful-joyful", "title": "Joyful, Joyful", "subtitle": "Piano", "voice": "piano",
        "bpm": 116, "transpose": 0, "gap": 1,
        "melody": seq("E4:1 E4:1 F4:1 G4:1 G4:1 F4:1 E4:1 D4:1 C4:1 C4:1 D4:1 E4:1 E4:1.5 D4:.5 D4:2 "
                      "E4:1 E4:1 F4:1 G4:1 G4:1 F4:1 E4:1 D4:1 C4:1 C4:1 D4:1 E4:1 D4:1.5 C4:.5 C4:2 "
                      "D4:1 D4:1 E4:1 C4:1 D4:1 E4:.5 F4:.5 E4:1 C4:1 D4:1 E4:.5 F4:.5 E4:1 D4:1 C4:1 D4:1 G3:2 "
                      "E4:1 E4:1 F4:1 G4:1 G4:1 F4:1 E4:1 D4:1 C4:1 C4:1 D4:1 E4:1 D4:1.5 C4:.5 C4:2"),
        "transpose_all": 0,
        "chords": ch("C:4 G:4 C:4 G:4 C:4 G:4 C:4 G:2 C:2 G:2 C:2 G:2 C:2 G:2 C:2 C:2 G:2 C:4 G:4 C:4 G:2 C:2"),
    },
    {
        "id": "doxology", "title": "Doxology", "subtitle": "Church organ", "voice": "organ",
        "bpm": 76, "gap": 1, "reverb": 0.36,
        "melody": seq("G4:2 G4:1 F#4:1 E4:1 D4:1 G4:1 A4:1 B4:2 R:1 B4:1 B4:1 B4:1 A4:1 G4:1 C5:1 B4:1 A4:2 R:1 "
                      "G4:1 A4:1 B4:1 A4:1 G4:1 E4:1 F#4:1 G4:2 R:1 D5:1 B4:1 G4:1 A4:1 C5:1 B4:1 A4:1 G4:3"),
        "chords": ch("G:2 G:1 D:1 C:1 G:1 G:1 D:1 G:2 -:1 G:3 D:1 G:1 C:1 G:1 D:2 -:1 "
                     "G:1 D:1 G:1 D:1 G:1 C:1 D:1 G:2 -:1 G:1 G:1 Em:1 D:1 C:1 G:1 D:1 G:3"),
    },
    {
        "id": "hark-the-herald", "title": "Hark! The Herald", "subtitle": "Bells", "voice": "bell",
        "bpm": 104, "gap": 1.5,
        "melody": seq("D4:1 G4:1 G4:1.5 F#4:.5 G4:1 B4:1 B4:1 A4:1 R:1 D5:1 D5:1 D5:1.5 C5:.5 B4:1 A4:1 B4:2 R:1 "
                      "D4:1 G4:1 G4:1.5 F#4:.5 G4:1 B4:1 B4:1 A4:1 R:1 D5:1 A4:1 A4:1.5 F#4:.5 F#4:1 E4:1 D4:2"),
        "chords": ch("G:4 G:2 D:3 G:2 D:2 G:3 G:4 G:2 D:3 D:2 A:2 D:2"),
    },
    {
        "id": "jesus-loves-me", "title": "Jesus Loves Me", "subtitle": "Music box", "voice": "musicbox",
        "bpm": 108, "transpose": 12, "gap": 1,
        "melody": seq("G4:1 E4:1 E4:1 D4:1 E4:1 G4:1 G4:2 A4:1 A4:1 C5:1 A4:1 A4:1 G4:1 G4:2 "
                      "G4:1 E4:1 E4:1 D4:1 E4:1 G4:1 G4:2 A4:1 A4:1 G4:1 C4:1 E4:1 D4:1 C4:2"),
        "chords": ch("C:4 C:4 F:4 C:4 C:4 C:4 F:2 C:2 G:2 C:2"),
    },
    {
        "id": "church-bells", "title": "Church Bells", "subtitle": "Westminster chime", "voice": "bell",
        "bpm": 66, "gap": 1, "reverb": 0.38,
        "melody": seq("G#4:1 F#4:1 E4:1 B3:2 R:1 E4:1 G#4:1 F#4:1 B3:2 R:1 E4:1 F#4:1 G#4:1 E4:2 R:1 "
                      "G#4:1 E4:1 F#4:1 B3:2 R:2 E3:2 E3:2 E3:2"),
        "chords": [],
    },
    {
        "id": "morning-prayer", "title": "Morning Prayer", "subtitle": "Harp", "voice": "harp",
        "bpm": 92, "gap": 1,
        "melody": seq("D4:.5 F#4:.5 A4:.5 D5:.5 F#5:1 E5:.5 D5:.5 A4:2 B4:.5 D5:.5 E5:.5 F#5:.5 G5:1 F#5:.5 E5:.5 D5:2 "
                      "G4:.5 B4:.5 D5:.5 G5:.5 F#5:1 E5:.5 D5:.5 E5:2 A4:.5 C#5:.5 E5:.5 A5:.5 F#5:1 E5:.5 C#5:.5 D5:3"),
        "chords": ch("D:4 G:4 G:4 A:4 D:3"),
    },
]


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    meta = []
    for s in SONGS:
        y = render(s)
        path = os.path.join(OUT_DIR, f"{s['id']}.mp3")
        write_mp3(y, path)
        meta.append({"id": s["id"], "title": s["title"], "subtitle": s["subtitle"],
                     "asset": f"assets/ringtones/{s['id']}.mp3", "seconds": round(len(y) / SR)})
        print("rendered", s["id"], round(len(y) / SR, 1), "s")
    with open(DATA, "w") as f:
        json.dump(meta, f, indent=1)


if __name__ == "__main__":
    main()
